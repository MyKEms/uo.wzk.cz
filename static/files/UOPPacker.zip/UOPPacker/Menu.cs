﻿/***************************************************************************
 *
 * $Author: Turley
 * 
 * "THE BEER-WARE LICENSE"
 * As long as you retain this notice you can do whatever you want with 
 * this stuff. If we meet some day, and you think this stuff is worth it,
 * you can buy me a beer in return.
 *
 ***************************************************************************/

using System;
using System.IO;
using System.Windows.Forms;
using Ultima;
using LegacyMUL;

namespace FiddlerPlugin
{
    public partial class Menu : UserControl
    {
        LegacyMULConverter conv;
        public Menu()
        {
            conv = new LegacyMULConverter();
            InitializeComponent();
            multype.DataSource = uoptype.DataSource = Enum.GetValues( typeof( FileType ) );
            mulmaptype.ReadOnly = uopmaptype.ReadOnly = true;
            Dock = DockStyle.Fill;
        }

        public Menu( string Version ) : this()
        {
            versionlabel.Text = Version;
        }

        private void inmulselect( object sender, EventArgs e )
        {
            if ( selectfile.ShowDialog() == DialogResult.OK )
            {
                inmul.Text = selectfile.FileName;
            }
        }

        private void inidxselect( object sender, EventArgs e )
        {
            if ( selectfile.ShowDialog() == DialogResult.OK )
            {
                inidx.Text = selectfile.FileName;
            }
        }

        private void outuopselect( object sender, EventArgs e )
        {
            if ( selectfile.ShowDialog() == DialogResult.OK )
            {
                outuop.Text = selectfile.FileName;
            }
        }

        private void touop( object sender, EventArgs e )
        {
            if ( inmul.Text == string.Empty || inmul.Text == null )
            {
                MessageBox.Show( "You must specify the input mul" );
                return;
            }

            if ( inidx.Text == string.Empty || inidx.Text == null )
            {
                MessageBox.Show( "You must specify the input idx" );
                return;
            }

            if ( outuop.Text == string.Empty || outuop.Text == null )
            {
                MessageBox.Show( "You must specify the output uop" );
                return;
            }

            if ( !File.Exists( inmul.Text ) )
            {
                MessageBox.Show( "The input mul does not exists" );
                return;
            }

            if ( !File.Exists( inidx.Text ) )
            {
                MessageBox.Show( "The input idx does not exists" );
                return;
            }

            if ( File.Exists( outuop.Text ) )
            {
                MessageBox.Show( "output file already exists" );
                return;
            }

            FileType status;

            try
            {
                multouop.Text = "Converting...";
                multouop.Enabled = false;

                Enum.TryParse<FileType>( multype.SelectedValue.ToString(), out status );
                conv.ToUOP( inmul.Text, inidx.Text, outuop.Text, status, (int)mulmaptype.Value );
            }
            catch
            {
                MessageBox.Show( "An error occurred" );
            }
            finally
            {
                multouop.Text = "Convert";
                multouop.Enabled = true;
            }
        }

        private void outmulselect( object sender, EventArgs e )
        {
            if ( selectfile.ShowDialog() == DialogResult.OK )
            {
                outmul.Text = selectfile.FileName;
            }
        }

        private void outidxselect( object sender, EventArgs e )
        {
            if ( selectfile.ShowDialog() == DialogResult.OK )
            {
                outidx.Text = selectfile.FileName;
            }
        }

        private void inuopselect( object sender, EventArgs e )
        {
            if ( selectfile.ShowDialog() == DialogResult.OK )
            {
                inuop.Text = selectfile.FileName;
            }
        }

        private void tomul( object sender, EventArgs e )
        {
            if ( outmul.Text == string.Empty || outmul.Text == null )
            {
                MessageBox.Show( "You must specify the output mul" );
                return;
            }

            if ( outidx.Text == string.Empty || outidx.Text == null )
            {
                MessageBox.Show( "You must specify the output idx" );
                return;
            }

            if ( inuop.Text == string.Empty || inuop.Text == null )
            {
                MessageBox.Show( "You must specify the input uop" );
                return;
            }

            if ( !File.Exists( inuop.Text ) )
            {
                MessageBox.Show( "The input file does not exists" );
                return;
            }

            if ( File.Exists( inmul.Text ) )
            {
                MessageBox.Show( "input mul already exists" );
                return;
            }

            if ( File.Exists( inidx.Text ) )
            {
                MessageBox.Show( "inidx file already exists" );
                return;
            }

            FileType status;

            try
            {
                uoptomul.Text = "Converting...";
                uoptomul.Enabled = false;

                Enum.TryParse<FileType>( uoptype.SelectedValue.ToString(), out status );
                conv.FromUOP( inuop.Text, outmul.Text, outidx.Text, status, (int)uopmaptype.Value );
            }
            catch
            {
                MessageBox.Show( "An error occurred" );
            }
            finally
            {
                uoptomul.Text = "Convert";
                uoptomul.Enabled = true;
            }
        }

        private void selectfolderbtn_Click( object sender, EventArgs e )
        {
            if ( selectfolder.ShowDialog() == DialogResult.OK )
            {
                inputfolder.Text = selectfolder.SelectedPath;
            }
        }

        private int m_Total, m_Success;

        private void Extract( string inFile, string outFile, string outIdx, FileType type, int typeIndex )
        {
            try
            {
                statustext.Text = inFile;
                Refresh();
                inFile = FixPath( inFile );

                if ( !File.Exists( inFile ) )
                    return;

                outFile = FixPath( outFile );

                if ( File.Exists( outFile ) )
                {
                    return;
                }

                outIdx = FixPath( outIdx );
                ++m_Total;

                conv.FromUOP( inFile, outFile, outIdx, type, typeIndex );

                ++m_Success;
            }
            catch ( Exception e )
            {
                MessageBox.Show( "An error occured while performing the action" );
            }
        }

        private void Pack( string inFile, string inIdx, string outFile, FileType type, int typeIndex )
        {
            try
            {
                statustext.Text = inFile;
                Refresh();
                inFile = FixPath( inFile );

                if ( !File.Exists( inFile ) )
                    return;

                outFile = FixPath( outFile );

                if ( File.Exists( outFile ) )
                {
                    return;
                }

                inIdx = FixPath( inIdx );
                ++m_Total;

                conv.ToUOP( inFile, inIdx, outFile, type, typeIndex );

                ++m_Success;
            }
            catch ( Exception e )
            {
                MessageBox.Show( "An error occured while performing the action" );
            }
        }

        private string FixPath( string file )
        {
            return ( file == null ) ? null : Path.Combine(inputfolder.Text , file );
        }

        private void startfolder_Click( object sender, EventArgs e )
        {

            if ( inputfolder.Text == string.Empty || inputfolder.Text == null )
            {
                MessageBox.Show( "You must specify the input folder" );
                return;
            }
            if ( extract.Checked )
            {
                m_Success = m_Total = 0;

                Extract( "artLegacyMUL.uop", "art.mul", "artidx.mul", FileType.ArtLegacyMUL, 0 );
                Extract( "gumpartLegacyMUL.uop", "gumpart.mul", "gumpidx.mul", FileType.GumpartLegacyMUL, 0 );
                Extract( "soundLegacyMUL.uop", "sound.mul", "soundidx.mul", FileType.SoundLegacyMUL, 0 );

                for ( int i = 0; i <= 5; ++i )
                {
                    string map = String.Format( "map{0}", i );

                    Extract( map + "LegacyMUL.uop", map + ".mul", null, FileType.MapLegacyMUL, i );
                    Extract( map + "xLegacyMUL.uop", map + "x.mul", null, FileType.MapLegacyMUL, i );
                }

                statustext.Text = string.Format( "Done ({0}/{1} files extracted)", m_Success, m_Total );
            }
            else if ( pack.Checked )
            {
                m_Success = m_Total = 0;

                Pack( "art.mul", "artidx.mul", "artLegacyMUL.uop", FileType.ArtLegacyMUL, 0 );
                Pack( "gumpart.mul", "gumpidx.mul", "gumpartLegacyMUL.uop", FileType.GumpartLegacyMUL, 0 );
                Pack( "sound.mul", "soundidx.mul", "soundLegacyMUL.uop", FileType.SoundLegacyMUL, 0 );

                for ( int i = 0; i <= 5; ++i )
                {
                    string map = String.Format( "map{0}", i );

                    Pack( map + ".mul", null, map + "LegacyMUL.uop", FileType.MapLegacyMUL, i );
                    Pack( map + "x.mul", null, map + "xLegacyMUL.uop", FileType.MapLegacyMUL, i );
                }

                statustext.Text = string.Format( "Done ({0}/{1} files packed)", m_Success, m_Total );
            }
            else
            {
                MessageBox.Show( "You must select an option" );
            }
        }
    }
}
