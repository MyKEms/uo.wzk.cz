﻿/***************************************************************************
 *
 * $Author: Turley
 * 
 * "THE BEER-WARE LICENSE"
 * As long as you retain this notice you can do whatever you want with 
 * this stuff. If we meet some day, and you think this stuff is worth it,
 * you can buy me a beer in return.
 *
 ***************************************************************************/

using System;
using System.IO;
using System.Windows.Forms;
using PluginInterface;
using Ultima;


namespace FiddlerPlugin
{
    public class TestPlugin : IPlugin
    {
        Version ver;

        public TestPlugin()
        {
            ver = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
        }

        string myName = "UOP Packer";
        string myDescription = "UOP packer/unpacker\r\nUses RunUO UOP packer";
        string myAuthor = "Feeh / Epila";
        IPluginHost myHost = null;

        /// <summary>
        /// Name of the plugin
        /// </summary>
        public override string Name { get { return myName; } }
        /// <summary>
        /// Description of the Plugin's purpose
        /// </summary>
        public override string Description { get { return myDescription; } }
        /// <summary>
        /// Author of the plugin
        /// </summary>
        public override string Author { get { return myAuthor; } }
        /// <summary>
        /// Version of the plugin
        /// </summary>
        public override string Version { get { return ver.ToString(); } }
        /// <summary>
        /// Host of the plugin.
        /// </summary>
        public override IPluginHost Host { get { return myHost; } set { myHost = value; } }


        public override void Initialize()
        {
        }

        public override void Dispose()
        {
        }

        public override void ModifyTabPages(TabControl tabcontrol)
        {
            TabPage page = new TabPage();
            page.Tag = 0; // at end used for undock/dock feature to define the order
            page.Text = "UOP Packer";
            page.Controls.Add(new Menu(Version));
            tabcontrol.TabPages.Add(page);
        }
    }
}
