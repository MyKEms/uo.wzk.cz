﻿namespace Map_Extractor
{
    partial class MapExtractor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MapExtractor));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.sourceMap = new System.Windows.Forms.ComboBox();
            this.destinationMap = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.copyStatics = new System.Windows.Forms.CheckBox();
            this.entireMap = new System.Windows.Forms.RadioButton();
            this.portion = new System.Windows.Forms.RadioButton();
            this.coordBox = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dY = new Map_Extractor.FilteredTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dX = new Map_Extractor.FilteredTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.sH = new Map_Extractor.FilteredTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.sW = new Map_Extractor.FilteredTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.sY = new Map_Extractor.FilteredTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.sX = new Map_Extractor.FilteredTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.destinationFiles = new Map_Extractor.DropDownBox();
            this.sourceFiles = new Map_Extractor.DropDownBox();
            this.progress = new System.Windows.Forms.ProgressBar();
            this.conversionButton = new System.Windows.Forms.Button();
            this.coordBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Source MUL Files:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Source Map:";
            // 
            // sourceMap
            // 
            this.sourceMap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sourceMap.FormattingEnabled = true;
            this.sourceMap.Items.AddRange(new object[] {
            "Map0 (Felucca) 6144x4096",
            "Map0 (Felucca) 7168x4096",
            "Map1 (Trammel) 6144x4096",
            "Map1 (Trammel) 7168x4096",
            "Map2 (Ilshenar) 2304x1600",
            "Map3 (Malas) 2560x2048",
            "Map4 (Tokuno) 1448x1448",
            "Map5 (Ter Mur) 1280x4096"});
            this.sourceMap.Location = new System.Drawing.Point(142, 61);
            this.sourceMap.Name = "sourceMap";
            this.sourceMap.Size = new System.Drawing.Size(330, 21);
            this.sourceMap.TabIndex = 5;
            // 
            // destinationMap
            // 
            this.destinationMap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.destinationMap.FormattingEnabled = true;
            this.destinationMap.Items.AddRange(new object[] {
            "Map0 (Felucca) 6144x4096",
            "Map0 (Felucca) 7168x4096",
            "Map1 (Trammel) 6144x4096",
            "Map1 (Trammel) 7168x4096",
            "Map2 (Ilshenar) 2304x1600",
            "Map3 (Malas) 2560x2048",
            "Map4 (Tokuno) 1448x1448",
            "Map5 (Ter Mur) 1280x4096"});
            this.destinationMap.Location = new System.Drawing.Point(142, 88);
            this.destinationMap.Name = "destinationMap";
            this.destinationMap.Size = new System.Drawing.Size(330, 21);
            this.destinationMap.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Destination Map:";
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnStart.Location = new System.Drawing.Point(203, 245);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 12;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Destination MUL Files:";
            // 
            // copyStatics
            // 
            this.copyStatics.AutoSize = true;
            this.copyStatics.Checked = true;
            this.copyStatics.CheckState = System.Windows.Forms.CheckState.Checked;
            this.copyStatics.Location = new System.Drawing.Point(6, 164);
            this.copyStatics.Name = "copyStatics";
            this.copyStatics.Size = new System.Drawing.Size(85, 17);
            this.copyStatics.TabIndex = 10;
            this.copyStatics.Text = "Copy Statics";
            this.copyStatics.UseVisualStyleBackColor = true;
            // 
            // entireMap
            // 
            this.entireMap.AutoSize = true;
            this.entireMap.Checked = true;
            this.entireMap.Location = new System.Drawing.Point(6, 118);
            this.entireMap.Name = "entireMap";
            this.entireMap.Size = new System.Drawing.Size(103, 17);
            this.entireMap.TabIndex = 8;
            this.entireMap.TabStop = true;
            this.entireMap.Text = "Copy Entire Map";
            this.entireMap.UseVisualStyleBackColor = true;
            // 
            // portion
            // 
            this.portion.AutoSize = true;
            this.portion.Location = new System.Drawing.Point(6, 136);
            this.portion.Name = "portion";
            this.portion.Size = new System.Drawing.Size(121, 17);
            this.portion.TabIndex = 9;
            this.portion.Text = "Copy Portion of Map";
            this.portion.UseVisualStyleBackColor = true;
            this.portion.CheckedChanged += new System.EventHandler(this.portion_CheckedChanged);
            // 
            // coordBox
            // 
            this.coordBox.Controls.Add(this.label10);
            this.coordBox.Controls.Add(this.dY);
            this.coordBox.Controls.Add(this.label11);
            this.coordBox.Controls.Add(this.dX);
            this.coordBox.Controls.Add(this.label12);
            this.coordBox.Controls.Add(this.label9);
            this.coordBox.Controls.Add(this.sH);
            this.coordBox.Controls.Add(this.label8);
            this.coordBox.Controls.Add(this.sW);
            this.coordBox.Controls.Add(this.label7);
            this.coordBox.Controls.Add(this.sY);
            this.coordBox.Controls.Add(this.label6);
            this.coordBox.Controls.Add(this.sX);
            this.coordBox.Controls.Add(this.label5);
            this.coordBox.Location = new System.Drawing.Point(142, 115);
            this.coordBox.Name = "coordBox";
            this.coordBox.Size = new System.Drawing.Size(330, 100);
            this.coordBox.TabIndex = 11;
            this.coordBox.TabStop = false;
            this.coordBox.Text = "Specify Maps Coords to copy (must be divisable by 8)";
            this.coordBox.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(85, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Y :";
            // 
            // dY
            // 
            this.dY.AllowedChars = "1234567890";
            this.dY.Location = new System.Drawing.Point(111, 74);
            this.dY.MaxLength = 4;
            this.dY.Name = "dY";
            this.dY.Size = new System.Drawing.Size(34, 20);
            this.dY.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 77);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "X :";
            // 
            // dX
            // 
            this.dX.AllowedChars = "1234567890";
            this.dX.Location = new System.Drawing.Point(47, 74);
            this.dX.MaxLength = 4;
            this.dX.Name = "dX";
            this.dX.Size = new System.Drawing.Size(34, 20);
            this.dX.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Destination:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(243, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Height :";
            // 
            // sH
            // 
            this.sH.AllowedChars = "1234567890";
            this.sH.Location = new System.Drawing.Point(290, 30);
            this.sH.MaxLength = 4;
            this.sH.Name = "sH";
            this.sH.Size = new System.Drawing.Size(34, 20);
            this.sH.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(151, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Width :";
            // 
            // sW
            // 
            this.sW.AllowedChars = "1234567890";
            this.sW.Location = new System.Drawing.Point(198, 30);
            this.sW.MaxLength = 4;
            this.sW.Name = "sW";
            this.sW.Size = new System.Drawing.Size(34, 20);
            this.sW.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(85, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Y :";
            // 
            // sY
            // 
            this.sY.AllowedChars = "1234567890";
            this.sY.Location = new System.Drawing.Point(111, 30);
            this.sY.MaxLength = 4;
            this.sY.Name = "sY";
            this.sY.Size = new System.Drawing.Size(34, 20);
            this.sY.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "X :";
            // 
            // sX
            // 
            this.sX.AllowedChars = "1234567890";
            this.sX.Location = new System.Drawing.Point(47, 30);
            this.sX.MaxLength = 4;
            this.sX.Name = "sX";
            this.sX.Size = new System.Drawing.Size(34, 20);
            this.sX.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Source:";
            // 
            // destinationFiles
            // 
            this.destinationFiles.BackColor = System.Drawing.SystemColors.Window;
            this.destinationFiles.Location = new System.Drawing.Point(142, 35);
            this.destinationFiles.Name = "destinationFiles";
            this.destinationFiles.Size = new System.Drawing.Size(330, 20);
            this.destinationFiles.TabIndex = 3;
            this.destinationFiles.TabStop = false;
            this.destinationFiles.TextEnabled = false;
            this.destinationFiles.DropDownClicked += new System.EventHandler(this.destinationFiles_DropDownClicked);
            // 
            // sourceFiles
            // 
            this.sourceFiles.BackColor = System.Drawing.SystemColors.Window;
            this.sourceFiles.Location = new System.Drawing.Point(142, 9);
            this.sourceFiles.Name = "sourceFiles";
            this.sourceFiles.Size = new System.Drawing.Size(330, 20);
            this.sourceFiles.TabIndex = 1;
            this.sourceFiles.TabStop = false;
            this.sourceFiles.TextEnabled = false;
            this.sourceFiles.DropDownClicked += new System.EventHandler(this.mulFiles_DropDownClicked);
            // 
            // progress
            // 
            this.progress.Location = new System.Drawing.Point(6, 218);
            this.progress.Name = "progress";
            this.progress.Size = new System.Drawing.Size(466, 23);
            this.progress.TabIndex = 13;
            this.progress.Visible = false;
            // 
            // conversionButton
            // 
            this.conversionButton.Location = new System.Drawing.Point(6, 247);
            this.conversionButton.Name = "conversionButton";
            this.conversionButton.Size = new System.Drawing.Size(145, 23);
            this.conversionButton.TabIndex = 14;
            this.conversionButton.Text = "Define Conversion Tables";
            this.conversionButton.UseVisualStyleBackColor = true;
            this.conversionButton.Click += new System.EventHandler(this.conversionButton_Click);
            // 
            // MapExtractor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 269);
            this.Controls.Add(this.conversionButton);
            this.Controls.Add(this.progress);
            this.Controls.Add(this.coordBox);
            this.Controls.Add(this.portion);
            this.Controls.Add(this.entireMap);
            this.Controls.Add(this.copyStatics);
            this.Controls.Add(this.destinationFiles);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.destinationMap);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.sourceMap);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.sourceFiles);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MapExtractor";
            this.Text = "Map Extractor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MapExtractor_FormClosing);
            this.coordBox.ResumeLayout(false);
            this.coordBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private DropDownBox sourceFiles;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox sourceMap;
        private System.Windows.Forms.ComboBox destinationMap;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnStart;
        private DropDownBox destinationFiles;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox copyStatics;
        private System.Windows.Forms.RadioButton entireMap;
        private System.Windows.Forms.RadioButton portion;
        private System.Windows.Forms.GroupBox coordBox;
        private System.Windows.Forms.Label label10;
        private FilteredTextBox dY;
        private System.Windows.Forms.Label label11;
        private FilteredTextBox dX;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private FilteredTextBox sH;
        private System.Windows.Forms.Label label8;
        private FilteredTextBox sW;
        private System.Windows.Forms.Label label7;
        private FilteredTextBox sY;
        private System.Windows.Forms.Label label6;
        private FilteredTextBox sX;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ProgressBar progress;
        private System.Windows.Forms.Button conversionButton;
    }
}

