﻿using System;
using System.Collections;
using System.Windows.Forms;

namespace Map_Extractor
{
    public partial class ConversionTable : Form
    {
        public ConversionTable()
        {
            InitializeComponent();
        }

        public void Initialize()
        {
            foreach (DictionaryEntry entry in Parameters.ItemConversions)
                staticsGrid.Rows.Add(entry.Key.ToString(), ((UInt16)entry.Value != 65535 ? entry.Value.ToString(): ""));

            staticsGrid.Sort(SourceItemID, System.ComponentModel.ListSortDirection.Ascending);
        }

        private void setButton_Click(object sender, EventArgs e)
        {
            Hashtable ht = new Hashtable();

            foreach (DataGridViewRow row in staticsGrid.Rows)
            {
                try
                {
                    if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() != "")
                    {
                        UInt16 oldItem = Convert.ToUInt16(row.Cells[0].Value);
                        UInt16 newItem = 65535;

                        if (row.Cells[1].Value != null && row.Cells[1].Value.ToString() != "")
                            newItem = Convert.ToUInt16(row.Cells[1].Value);

                        ht[oldItem] = newItem;
                    }
                }
                catch { }
            }

            Parameters.ItemConversions = ht;

            Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void staticsGrid_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                try { staticsGrid.Rows.Remove(staticsGrid.CurrentRow); e.Handled = true; }
                catch { }
            }

            if (e.KeyCode == Keys.Insert)
            {
                try
                {
                    int index = staticsGrid.CurrentRow.Index;

                    staticsGrid.Rows.Insert(index, 1);

                    staticsGrid.CurrentCell = staticsGrid.Rows[index].Cells[0];
                    staticsGrid.Rows[index].Selected = true;

                    e.Handled = true;
                }
                catch { }
            }
        }
    }
}
