﻿using System;
using System.IO;

namespace Map_Extractor
{
    public class Map
    {
        private int _fileIndex;
        public int FileIndex { get { return _fileIndex; } }

        private int _width;
        public int Width { get { return _width; } }

        private int _height;
        public int Height { get { return _height; } }

        private FileStream fs;

        public Map(int fileindex, int width, int height)
        {
            _fileIndex = fileindex;
            _width = width / 8;
            _height = height / 8;
        }

        public bool OpenMap(string path, bool writing)
        {
            if (!writing || !Parameters.EntireMap)
            {
                if (!File.Exists(String.Format("{0}\\map{1}.mul", path, FileIndex)))
                    return false;
            }

            FileMode mode = FileMode.Open;

            if (writing && Parameters.EntireMap)
                mode = FileMode.Create;
            else
                mode = FileMode.OpenOrCreate;

            try
            {
                fs = new FileStream(String.Format("{0}\\map{1}.mul", path, FileIndex), mode);

                return (writing ? fs.CanWrite : fs.CanRead);
            }
            catch { return false; }
        }

        public void Close()
        {
            try
            {
                fs.Close();
            }
            catch { }
        }

        public Block ReadBlock(int x, int y)
        {
            try
            {
                fs.Position = ((x * Height) + y) * 196;
                BinaryReader reader = new BinaryReader(fs);

                Block b = new Block();
                b.Cells = new Cell[8, 8];

                b.Header = reader.ReadInt32();

                for (int xx = 0; xx < 8; xx++)
                    for (int yy = 0; yy < 8; yy++)
                        b.Cells[xx, yy] = new Cell(reader.ReadUInt16(), reader.ReadSByte());

                return b;
            }
            catch { return new Block(); }
        }

        public void WriteBlock(Block b, int x, int y)
        {
            try
            {
                fs.Position = ((x * Height) + y) * 196;
                BinaryWriter writer = new BinaryWriter(fs);

                writer.Write((Int32)b.Header);

                for (int xx = 0; xx < 8; xx++)
                {
                    for (int yy = 0; yy < 8; yy++)
                    {
                        writer.Write((UInt16)b.Cells[xx, yy].Color);
                        writer.Write((SByte)b.Cells[xx, yy].Altitude);
                    }
                }
            }
            catch { }
        }

        public void WriteEmptyBlock(int x, int y)
        {
            Block b = new Block();
            b.Cells = new Cell[8, 8];

            b.Header = 0;

            for (int xx = 0; xx < 8; xx++)
            {
                for (int yy = 0; yy < 8; yy++)
                {
                    b.Cells[xx, yy] = new Cell(580, 0);
                }
            }

            WriteBlock(b, x, y);
        }
    }
}
