﻿using System;

namespace Map_Extractor
{
    public struct Cell
    {
        private UInt16 _Color;
        public UInt16 Color { get { return _Color; } set { _Color = value; } }

        private SByte _Altitude;
        public SByte Altitude { get { return _Altitude; } set { _Altitude = value; } }

        public Cell(UInt16 color, SByte altitude)
        {
            _Color = color;
            _Altitude = altitude;
        }
    }

    public struct Block
    {
        private Int32 _Header;
        public Int32 Header { get { return _Header; } set { _Header = value; } }

        private Cell[,] _Cells;
        public Cell[,] Cells { get { return _Cells; } set { _Cells = value; } }
    }

    public struct IDX
    {
        private UInt32 _Start;
        public UInt32 Start { get { return _Start; } }

        private UInt32 _Length;
        public UInt32 Length { get { return _Length; } }

        private UInt32 _Trailer;
        public UInt32 Trailer { get { return _Trailer; } }

        private StaticDef[] _Statics;
        public StaticDef[] Statics { get { return _Statics; } set { _Statics = value; } }

        public IDX(UInt32 start, UInt32 length, UInt32 trailer)
        {
            _Start = start;
            _Length = length;
            _Trailer = trailer;
            _Statics = new StaticDef[0];
        }
    }

    public struct StaticDef
    {
        private UInt16 _Color;
        public UInt16 Color { get { return _Color; } set { _Color = value; } }

        private Byte _X;
        public Byte X { get { return _X; } }

        private Byte _Y;
        public Byte Y { get { return _Y; } }

        private SByte _Altitude;
        public SByte Altitude { get { return _Altitude; } }

        private Int16 _Trailer;
        public Int16 Trailer { get { return _Trailer; } }

        public StaticDef(UInt16 color, Byte x, Byte y, SByte altitude, Int16 trailer)
        {
            _Color = color;
            _X = x;
            _Y = y;
            _Altitude = altitude;
            _Trailer = trailer;
        }
    }
}
