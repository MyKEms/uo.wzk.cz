Map Extractor
-------------

Original thread can be found at:
	http://www.runuo.com/community/threads/map-extractor.468585/

Please review the thread for usage instructions.