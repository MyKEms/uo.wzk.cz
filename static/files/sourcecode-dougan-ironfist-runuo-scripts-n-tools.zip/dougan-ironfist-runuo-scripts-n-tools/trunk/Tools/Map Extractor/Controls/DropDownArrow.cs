﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Map_Extractor
{
    [DefaultEvent("Click")]
    public partial class DropDownArrow : UserControl
    {
        public DropDownArrow()
        {
            InitializeComponent();

            // Define operating parameters
            SetStyle(ControlStyles.FixedHeight, true);
            SetStyle(ControlStyles.FixedWidth, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.Selectable, false);
            SetStyle(ControlStyles.StandardClick, true);
            SetStyle(ControlStyles.StandardDoubleClick, false);
            SetStyle(ControlStyles.UserMouse, true);
            SetStyle(ControlStyles.UserPaint, true);

            // Prevent tabbing to this control
            this.TabStop = false;
        }

        // Determines if the mouse button is currently being pressed
        private bool _pressed = false;

        protected override void OnMouseDown(MouseEventArgs e)
        {
            // Indicate that the mouse button is currently being pressed
            _pressed = true;

            // Redraw the control
            Invalidate();

            // Perform standard functions
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            // Perform standard functions
            base.OnMouseUp(e);

            // Indicate that the mouse button is no longer being pressed
            _pressed = false;

            // Redraw the control
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            // Perform standard functions
            base.OnPaint(e);

            // Set the state to not clicked
            ButtonState _state = ButtonState.Normal;

            // If the mouse button is currently being pressed, set the state to clicked
            if (_pressed)
                _state = ButtonState.Pushed;

            // Draw a combo button for the specified button state
            ControlPaint.DrawComboButton(e.Graphics, ClientRectangle, _state);
        }

        /// <summary>
        /// Send a click event for this control
        /// </summary>
        internal void OnClick()
        {
            // Send the click event
            InvokeOnClick(this, new EventArgs());
        }
    }
}
