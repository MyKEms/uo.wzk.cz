﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Map_Extractor
{
    public partial class DropDownBox : UserControl
    {
        [Description("Gets or sets the specific characters that will be eliminated from user input if DENY is not set"), Category("Special"), DefaultValue("")]
        public string AllowedChars { get { return result.AllowedChars; } set { result.AllowedChars = value; } }

        [Description("Gets or sets the option to control whether the textbox is enabled"), Category("Behavior"), DefaultValue(true)]
        public bool TextEnabled { get { return result.Enabled; } set { result.Enabled = value; } }

        [Description("Gets or sets the maximum length of the text that can be entered"), Category("Behavior"), DefaultValue(32767)]
        public int MaxLength { get { return result.MaxLength; } set { result.MaxLength = value; } }

        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), Bindable(true)]
        public override string Text { get { return result.Text; } set { result.Text = value; } }

        [Description("Event fired when the DropDown is clicked"), Category("Custom")]
        public event EventHandler DropDownClicked;

        [EditorBrowsable(EditorBrowsableState.Always), Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible), Bindable(true)]
        [Description("Event raised when the value of the Text property is changed on Control"), Category("Property Changed")]
        public new event EventHandler TextChanged;

        public DropDownBox()
        {
            InitializeComponent();
        }

        internal void resultDropDown_Click(object sender, EventArgs e)
        {
            if (DropDownClicked != null)
                DropDownClicked(this, e);
        }

        private void SelectField_Resize(object sender, EventArgs e)
        {
            result.Width = this.Width - 20;
            resultDropDown.Left = result.Width;
        }

        private void SelectField_Enter(object sender, EventArgs e)
        {
            result.Focus();
        }

        public void SelectAll()
        {
            result.SelectAll();
        }

        private void result_TextChanged(object sender, EventArgs e)
        {
            if (TextChanged != null)
                TextChanged(this, e);
        }
    }
}
