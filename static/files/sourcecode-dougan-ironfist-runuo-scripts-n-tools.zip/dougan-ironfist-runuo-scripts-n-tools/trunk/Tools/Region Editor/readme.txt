Region Editor
-------------

Original thread can be found at:
	http://www.runuo.com/community/threads/region-editor-for-runuo-svn-663.468210/

Please review the thread for usage instructions.