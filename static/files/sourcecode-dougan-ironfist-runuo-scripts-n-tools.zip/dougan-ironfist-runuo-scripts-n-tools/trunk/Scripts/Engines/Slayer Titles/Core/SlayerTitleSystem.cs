﻿/*
 * 
 * Slayer Title System
 * Version 1.6
 * Designed for SVN 663 + ML
 * Modified for RunUO 2.2 SVN
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 6/10/2012
 *
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 */

#define SHOW_PERSISTENT_GUMP

using System;
using Server;
using Server.Commands;
using Server.Mobiles;
using Server.Engines.XmlSpawner2;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.SlayerTitles
{
    public class SlayerTitleSystem
    {
        public static void Initialize()
        {
            CommandSystem.Register("Titles", AccessLevel.Player, new CommandEventHandler(Titles_OnCommand));

            EventSink.Login += new LoginEventHandler(EventSink_Login);
            PlayerMobile.PlayerProperties += new PlayerMobile.PlayerPropertiesEventHandler(PlayerMobile_PlayerProperties);
        }

        [Usage("Titles")]
        [Description("Allows a player to set their active slayer titles")]
        private static void Titles_OnCommand(CommandEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                SlayerTitleAttachment attachment = FindAttachment(e.Mobile);
                e.Mobile.SendGump(new SlayerTitleChoiceGump(attachment, (PlayerMobile)e.Mobile));
            }
        }

        static void PlayerMobile_PlayerProperties(PlayerMobile.PlayerPropertiesEventArgs e)
        {
            SlayerTitleAttachment attachment = FindAttachment(e.Player);

            string title = attachment.GetActiveTitle();

            if (title != String.Empty)
                e.PropertyList.Add(title);
        }

        public static void EventSink_Login(LoginEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                SlayerTitleAttachment attachment = FindAttachment(e.Mobile);

                e.Mobile.InvalidateProperties();

#if SHOW_PERSISTENT_GUMP
                e.Mobile.SendGump(new SlayerTitleGump(attachment, (PlayerMobile)e.Mobile, 820,30));
#endif
            }
        }

        public static SlayerTitleAttachment FindAttachment(Mobile m)
        {
            SlayerTitleAttachment attachment = (SlayerTitleAttachment)XmlAttach.FindAttachment(m, typeof(SlayerTitleAttachment));

            if (attachment == null)
            {
                attachment = new SlayerTitleAttachment();
                XmlAttach.AttachTo(m, attachment);
            }

            return attachment;
        }
    }
}
