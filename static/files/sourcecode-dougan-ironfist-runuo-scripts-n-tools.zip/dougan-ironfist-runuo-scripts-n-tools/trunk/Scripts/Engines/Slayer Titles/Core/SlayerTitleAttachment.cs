﻿/*
 * 
 * Slayer Title System
 * Version 1.6
 * Designed for SVN 663 + ML
 * Modified for RunUO 2.2 SVN
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 6/10/2012
 *
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 */

using System;
using System.Collections.Generic;
using Server;
using Server.Mobiles;
using Server.Engines.XmlSpawner2;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.SlayerTitles
{
    public class SlayerTitleAttachment : XmlAttachment
    {
        private List<SlayerSystemTracker> m_SystemEntries = new List<SlayerSystemTracker>();

        [CommandProperty(AccessLevel.GameMaster)]
        public List<SlayerSystemTracker> SystemEntries { get { return m_SystemEntries; } set { m_SystemEntries = value; } }

        // a serial constructor is REQUIRED
        public SlayerTitleAttachment(ASerial serial)
            : base(serial)
        {
        }

        [Attachable]
        public SlayerTitleAttachment()
        {
        }

        public string GetActiveTitle()
        {
            foreach (SlayerSystemTracker tracker in SystemEntries)
                if (tracker.TitleSelected)
                    return tracker.LastTitleAwarded;

            return String.Empty;
        }

        public void SetActiveTitleSystem(int index)
        {
            for (int i = 0; i < SystemEntries.Count; i++)
                SystemEntries[i].TitleSelected = (index == i);
        }

        public SlayerSystemTracker FindSystemName(string name)
        {
            SlayerSystemTracker tracker = null;

            foreach (SlayerSystemTracker iTracker in m_SystemEntries)
                if (iTracker.SystemName == name)
                    tracker = iTracker;

            if (tracker == null)
            {
                tracker = new SlayerSystemTracker(name, 0, String.Empty);
                m_SystemEntries.Add(tracker);
            }

            return tracker;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)1);

            // Version 0 & 1
            writer.Write((int)m_SystemEntries.Count);

            foreach (SlayerSystemTracker entry in SystemEntries)
            {
                writer.Write((string)entry.SystemName);
                writer.Write((int)entry.SlayerCount);
                writer.Write((string)entry.LastTitleAwarded);
                writer.Write((bool)entry.TitleSelected);
            }
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            switch (version)
            {
                case 1:
                case 0:
                    int entryCount = reader.ReadInt();

                    for (int i = 0; i < entryCount; i++)
                    {
                        SlayerSystemTracker tracker = new SlayerSystemTracker(reader.ReadString(), reader.ReadInt(), reader.ReadString());

                        if (tracker.LastTitleAwarded == null)
                            tracker.LastTitleAwarded = String.Empty;

                        if (version > 0)
                            tracker.TitleSelected = reader.ReadBool();

                        SystemEntries.Add(tracker);
                    }
                    break;
            }
        }
    }
}