﻿/*
 * 
 * Slayer Title System
 * Version 1.6
 * Designed for SVN 663 + ML
 * Modified for RunUO 2.2 SVN
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 6/10/2012
 *
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 */

using System;
using System.Collections.Generic;
using Server;
using Server.Items;
using Server.Mobiles;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL SLAYER TITLE GROUPS ///

namespace Server.SlayerTitles
{
    public class SheepSlayerTitles : BaseSlayerTitle
    {
        // The Initialize routine must be present to in order to start the event used to track player kills
        public static void Initialize()
        {
            /* If you want your players to gain slayer counts by killing monsters, then this type of hook must be in place.
             * 
             * Note: In order for this hook to work, you must make a small change to the BaseCreature script.
             * See the details in the readme.txt file for details.
             */
            BaseCreature.CreatureKilledBy += new BaseCreature.CreatureKilledByEventHandler(BaseCreature_CreatureKilledBy);
        }

        static void BaseCreature_CreatureKilledBy(BaseCreature.CreatureKilledByEventArgs e)
        {
            // Test for the creature type(s) that are valid for these titles
            if (e.CreatureKilled is Sheep)
            {
                // First create an instance of your slayer title (since this routine is static)
                SheepSlayerTitles titleSystem = new SheepSlayerTitles();

                // Increment the counter and the core does the rest
                titleSystem.IncrementSlayerCount(e.Player);
            }
        }

        // Set the name of the slayer system so it can be found in the attachment
        public override string SlayerTitleName { get { return "Sheep Slayer"; } }


        // Use the contructor section to define the number of kills needed for each level of title progression
        public SheepSlayerTitles()
        {
            AddSlayerTitleEntry(new SlayerTitleEntry(50, "Hunter of Mutton"));
            AddSlayerTitleEntry(new SlayerTitleEntry(200, "Master of the Feast"));
            AddSlayerTitleEntry(new SlayerTitleEntry(500, "Collector of Wool"));
        }

        public override void OnTitleAwarded(PlayerMobile player, string title, int killCount)
        {
            if (title == "Collector of Wool")
            {
                Static reward = new Static(0x160a);
                reward.Name = String.Format("Leg of Lamb awarded to {0}", player.Name);
                reward.Movable = true;
                reward.Hue = 0x30;

                player.AddToBackpack(reward);
            }
        }
    }
}