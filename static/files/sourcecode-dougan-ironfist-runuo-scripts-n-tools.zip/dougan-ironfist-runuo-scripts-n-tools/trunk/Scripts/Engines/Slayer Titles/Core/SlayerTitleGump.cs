﻿/*
 * 
 * Slayer Title System
 * Version 1.6
 * Designed for SVN 663 + ML
 * Modified for RunUO 2.2 SVN
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 6/10/2012
 *
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 */

using System;
using Server.Gumps;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.SlayerTitles
{
	public class SlayerTitleGump : Gump
	{
        private SlayerTitleAttachment Attachment;
        private PlayerMobile Owner;

        public SlayerTitleGump(SlayerTitleAttachment attachment, PlayerMobile owner, int x, int y)
            : base(x, y)
        {
            Attachment = attachment;
            Owner = owner;

            AddBackground(0, 0, 100, 70, 9270);
            AddImageTiled(10, 10, 80, 50, 2624);
            AddButton(18, 35, 247, 248, 1, GumpButtonType.Reply, 0);
            AddLabelCropped(13, 13, 77, 16, 0x481, "Select Title");

            Closable = false;
            Disposable = false;
            Resizable = false;
        }

        public override void OnResponse(Network.NetState sender, RelayInfo info)
        {
            sender.Mobile.SendGump(this);

            if (!sender.Mobile.HasGump(typeof(SlayerTitleChoiceGump)))
                sender.Mobile.SendGump(new SlayerTitleChoiceGump(Attachment, Owner));
        }
	}

    public class SlayerTitleChoiceGump : Gump
	{
        private SlayerTitleAttachment Attachment;
        private PlayerMobile Owner;

        public SlayerTitleChoiceGump(SlayerTitleAttachment attachment, PlayerMobile owner)
            : base(40,40)
        {
            Attachment = attachment;
            Owner = owner;

            AddPage(1);
            AddBackground(0, 0, 500, 415, 9200);
            AddImageTiled(10, 10, 478, 24, 2624);
            AddImageTiled(10, 40, 478, 330, 2624);
            AddImageTiled(10, 375, 478, 30, 2624);
            AddAlphaRegion(10, 10, 478, 395);

            AddLabel(202, 12, 0x481, "Title Selection");

            string activeTitle = Attachment.GetActiveTitle();

            AddButton(15, 45, 4023, 4025, -1, GumpButtonType.Reply, 0);
            AddLabelCropped(50, 45, 230, 20, 0x481, "None");

            int pageNumber = 1;
            int titleOffset = 1;
            int column = 0;

            for (int i = 0; i < Attachment.SystemEntries.Count; i++)
            {
                string title = Attachment.SystemEntries[i].LastTitleAwarded;

                if (title != String.Empty)
                {
                    if (titleOffset >= 13)
                    {
                        if (column >= 1)
                        {
                            AddButton(452, 380, 4005, 4007, 0, GumpButtonType.Page, pageNumber + 1);

                            AddPage(++pageNumber);
                            AddBackground(0, 0, 500, 415, 9200);
                            AddAlphaRegion(10, 10, 478, 24);
                            AddAlphaRegion(10, 40, 478, 330);
                            AddAlphaRegion(10, 375, 478, 30);

                            AddButton(15, 380, 4014, 4016, 0, GumpButtonType.Page, pageNumber - 1);

                            titleOffset = 0;
                            column = 0;
                        }
                        else
                        {
                            titleOffset = 0;
                            column++;
                        }
                    }

                    AddButton((column == 0 ? 15 : 251), 45 + (titleOffset * 25), 4023, 4025, i + 1, GumpButtonType.Reply, 0);
                    AddLabelCropped((column == 0 ? 50 : 286), 45 + (titleOffset * 25), 230, 20, 0x481, title);

                    titleOffset++;
                }
            }

            Resizable = false;
        }

        public override void OnResponse(Network.NetState sender, RelayInfo info)
        {
            if (info.ButtonID != 0)
            {
                Attachment.SetActiveTitleSystem(info.ButtonID - 1);

                string title = Attachment.GetActiveTitle();

                if (title == String.Empty)
                    Owner.SendMessage("You have choosen to hide your slayer title.");
                else

                    Owner.SendMessage(String.Format("You have changed your slayer title to {0}.", title));

                Owner.InvalidateProperties();
            }
        }
	}
}
