﻿/*
 * 
 * Slayer Title System
 * Version 1.6
 * Designed for SVN 663 + ML
 * Modified for RunUO 2.2 SVN
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 6/10/2012
 *
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 */

using System;
using System.Collections.Generic;
using Server;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.SlayerTitles
{
    public abstract class BaseSlayerTitle
    {
        public abstract string SlayerTitleName { get; }

        private List<SlayerTitleEntry> m_SlayerTitleEntries = new List<SlayerTitleEntry>();

        public BaseSlayerTitle()
        {
        }

        public void AddSlayerTitleEntry(SlayerTitleEntry entry)
        {
            m_SlayerTitleEntries.Add(entry);
            m_SlayerTitleEntries.Sort(ComapreByNumber);
        }

        public void IncrementSlayerCount(PlayerMobile player)
        {
            SlayerTitleAttachment attachment = SlayerTitleSystem.FindAttachment(player);

            if (attachment != null)
            {
                SlayerSystemTracker tracker = attachment.FindSystemName(SlayerTitleName);

                if (tracker != null)
                {
                    tracker.SlayerCount += 1;

                    string newTitle = GetTitleAwarded(tracker.SlayerCount);

                    if (newTitle != String.Empty)
                    {
                        if (tracker.LastTitleAwarded == String.Empty || tracker.LastTitleAwarded != newTitle)
                        {
                            tracker.LastTitleAwarded = newTitle;
                            player.InvalidateProperties();
                            player.SendSound(0x3D);
                            player.SendMessage(0xC8, String.Format("Your have been awarded the title of '{0}' for {1} kills.", newTitle, tracker.SlayerCount));

                            OnTitleAwarded(player, newTitle, tracker.SlayerCount);
                        }
                    }
                }
            }
        }

        private string GetTitleAwarded(int counter)
        {
            string title = String.Empty;

            foreach (SlayerTitleEntry entry in m_SlayerTitleEntries)
            {
                int lastCount = 0;

                if (counter >= entry.SlayerCount && counter >= lastCount)
                {
                    lastCount = entry.SlayerCount;
                    title = entry.SlayerTitle;
                }

            }

            return title;
        }

        public virtual void OnTitleAwarded(PlayerMobile player, string title, int killCount)
        {
        }

        public static int ComapreByNumber(SlayerTitleEntry x, SlayerTitleEntry y)
        {
            return x.SlayerCount.CompareTo(y.SlayerCount);
        }
    }

    public class SlayerTitleEntry
    {
        private int m_SlayerCount = 0;
        public int SlayerCount { get { return m_SlayerCount; } }

        private string m_SlayerTitle = String.Empty;
        public string SlayerTitle { get { return m_SlayerTitle; } }

        public SlayerTitleEntry(int slayerCount, string slayerTitle)
        {
            m_SlayerCount = slayerCount;
            m_SlayerTitle = slayerTitle;
        }
    }
}