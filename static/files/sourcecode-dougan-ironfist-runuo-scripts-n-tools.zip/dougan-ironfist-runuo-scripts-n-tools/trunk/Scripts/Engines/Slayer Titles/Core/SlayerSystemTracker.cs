﻿/*
 * 
 * Slayer Title System
 * Version 1.6
 * Designed for SVN 663 + ML
 * Modified for RunUO 2.2 SVN
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 6/10/2012
 *
 * The purpose of these scripts is to allow shard administrators to create fun kill-based titles that players can earn. 
 * 
 */

using System;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.SlayerTitles
{
    public class SlayerSystemTracker
    {
        private string m_SystemName = String.Empty;
        private int m_SlayerCount = 0;
        private string m_LastTitleAwarded = String.Empty;
        private bool m_TitleSelected = false;

        [CommandProperty(AccessLevel.GameMaster)]
        public string SystemName { get { return m_SystemName; } set { m_SystemName = value; } }

        [CommandProperty(AccessLevel.GameMaster)]
        public int SlayerCount { get { return m_SlayerCount; } set { m_SlayerCount = value; } }

        [CommandProperty(AccessLevel.GameMaster)]
        public string LastTitleAwarded { get { return m_LastTitleAwarded; } set { m_LastTitleAwarded = value; } }

        [CommandProperty(AccessLevel.GameMaster)]
        public bool TitleSelected { get { return m_TitleSelected; } set { m_TitleSelected = value; } }

        public SlayerSystemTracker(string systemName, int slayerCount, string lastTitleAwarded)
        {
            SystemName = systemName;
            SlayerCount = slayerCount;
            LastTitleAwarded = lastTitleAwarded;
        }
    }
}
