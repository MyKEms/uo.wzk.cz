﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using Server;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Phasing
{
    // This is the base phasing interface.  Any item you want to be phasable needs to use this interface.
    public interface IPhasable
    {
        string PhaseSystemName { get; }
        int PhaseStageStart { get; }
        int PhaseStageEnd { get; }

        bool CanBeSeenBy(PlayerMobile player);
        void AssignPhasing(string systemName, int stageStart, int stageEnd);
    }
}