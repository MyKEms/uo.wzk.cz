﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using Server;
using Server.Commands;
using Server.Items;
using Server.Mobiles;
using Server.Targeting;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Phasing
{
    public class DupePhase
    {
        public static void Initialize()
        {
            CommandSystem.Register("DupePhase", AccessLevel.GameMaster, new CommandEventHandler(DupePhase_OnCommand));
            CommandSystem.Register("DP", AccessLevel.GameMaster, new CommandEventHandler(DupePhase_OnCommand));
            CommandSystem.Register("DupePhaseStop", AccessLevel.GameMaster, new CommandEventHandler(DupePhaseStop_OnCommand));
            CommandSystem.Register("DPS", AccessLevel.GameMaster, new CommandEventHandler(DupePhaseStop_OnCommand));
            CommandSystem.Register("ShowAllPhases", AccessLevel.GameMaster, new CommandEventHandler(ShowAllPhases_OnCommand));
            CommandSystem.Register("SAP", AccessLevel.GameMaster, new CommandEventHandler(ShowAllPhases_OnCommand));
        }

        [Usage("DupePhase")]
        [Aliases("DP")]
        [Description("Allows you to see what a player is seeing at their phase progression.")]
        private static void DupePhase_OnCommand(CommandEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                PhasingAttachment attachment = PhaseSystemManager.FindAttachment(e.Mobile);

                if (attachment != null & attachment.DupedPlayer != null)
                {
                    attachment.EndDupingPlayer((PlayerMobile)e.Mobile);

                    e.Mobile.SendMessage("You are no longer duping the phase progression of another player.");
                }
                else
                {
                    e.Mobile.Target = new DupeTarget();
                    e.Mobile.SendMessage("What player do you want to dupe phases?");
                }
            }
        }

        [Usage("DupePhaseStop")]
        [Aliases("DPS")]
        [Description("Stops duping the phase progression of another player.")]
        private static void DupePhaseStop_OnCommand(CommandEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                PhasingAttachment attachment = PhaseSystemManager.FindAttachment(e.Mobile);

                if (attachment != null)
                    attachment.EndDupingPlayer((PlayerMobile)e.Mobile);

                e.Mobile.SendMessage("You are no longer duping the phase progression of another player.");
            }
        }

        [Usage("ShowAllPhases")]
        [Aliases("SAP")]
        [Description("Toogles the ability to view all phases of every system at once.")]
        private static void ShowAllPhases_OnCommand(CommandEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                PhasingAttachment attachment = PhaseSystemManager.FindAttachment(e.Mobile);

                if (attachment != null)
                {
                    if (attachment.ShowAllPhases)
                    {
                        attachment.ShowAllPhases = false;
                        e.Mobile.SendMessage("You can no longer see all phases systems at once.");
                    }
                    else
                    {
                        attachment.ShowAllPhases = true;
                        e.Mobile.SendMessage("You can now see all phases systems at once.");
                    }
                }
            }
        }

        private class DupeTarget : Target
        {
            public DupeTarget() : base(25, true, TargetFlags.None)
            {
            }

            protected override void OnTarget(Mobile from, object targ)
            {
                if (!(from is PlayerMobile))
                    return;

                if (!(targ is PlayerMobile))
                {
                    from.SendMessage("You can only the phases of players.");
                    return;
                }

                PhasingAttachment attachment = PhaseSystemManager.FindAttachment(from);

                if (attachment != null)
                    attachment.StartDupingPlayer((PlayerMobile)from, (PlayerMobile)targ);
            }
        }
    }
}