﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using Server;
using Server.Items;
using Server.Mobiles;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL PHASING SYSTEMS ///

namespace Server.Phasing
{
    public class Admirer : BaseCreature, IPhasable
    {
        // Defines the Phase System Name as it appears in the BasePhaseSystem object
        [CommandProperty(AccessLevel.GameMaster)]
        public string PhaseSystemName { get { return "Example Statue"; } }

        // Defines the phase in which this object is initially visible
        [CommandProperty(AccessLevel.GameMaster)]
        public int PhaseStageStart { get { return 4; } }

        // Defines the phase in which this object is last visible
        [CommandProperty(AccessLevel.GameMaster)]
        public int PhaseStageEnd { get { return 4; } }

        // This is the routine in any IPhaseable object that determines if the player can see the object.
        // In most cases, the routine shown below can be copied exactly as-is into your own scripts
        public bool CanBeSeenBy(PlayerMobile player)
        {
            int stage = PhaseSystemManager.GetCurrentPhase(player, PhaseSystemName);

            if (stage >= 0 && stage >= PhaseStageStart && stage <= PhaseStageEnd)
                return true;
            else
                return false;
        }

        // Function used by the [GenPhases command to initialize a phased item
        // [GenPhases does not spawn mobiles, but this routine is required by the interface.
        public void AssignPhasing(string systemName, int stageStart, int stageEnd)
        {
        }

        [Constructable] 
		public Admirer () : base( AIType.AI_Animal, FightMode.None, 10, 1, 0.2, 0.4 ) 
		{ 
			InitStats( 31, 41, 51 ); 

			SpeechHue = Utility.RandomDyedHue(); 

			Hue = Utility.RandomSkinHue(); 

			if ( this.Female = Utility.RandomBool() ) 
			{ 
				this.Body = 0x191; 
				this.Name = NameList.RandomName( "female" );
				AddItem( new FancyDress( Utility.RandomDyedHue() ) ); 
			} 
			else 
			{ 
				this.Body = 0x190; 
				this.Name = NameList.RandomName( "male" );
				AddItem( new LongPants( Utility.RandomNeutralHue() ) ); 
				AddItem( new FancyShirt( Utility.RandomDyedHue() ) );
			}

            Title = "the Statue Admirer";

			AddItem( new Boots( Utility.RandomNeutralHue() ) );

			Utility.AssignRandomHair( this );

			Container pack = new Backpack(); 

			pack.DropItem( new Gold( 250, 300 ) ); 

			pack.Movable = false; 

			AddItem( pack ); 
		} 


		public override bool ClickTitle{ get{ return false; } }

        public Admirer(Serial serial)
            : base(serial) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 

			writer.Write( (int) 0 ); // version 
		} 

		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 

			int version = reader.ReadInt(); 
		}
    } 
}