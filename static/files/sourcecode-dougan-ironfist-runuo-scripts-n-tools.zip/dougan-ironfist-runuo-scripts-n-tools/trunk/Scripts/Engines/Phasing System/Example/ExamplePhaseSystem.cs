﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using Server;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL PHASING SYSTEMS ///

namespace Server.Phasing
{
    // Every phasing system you create needs to have one of these classes defined.
    public class ExamplePhaseSystem : BasePhaseSystem
    {
        // Defines the Phase System Name
        public override string PhaseSystemName { get { return "Example Statue"; } }

        // Defines the type of the phase system.  If set to Player, then the system progresses independently for each player.
        // If set to Server, then the systems progress simultaneously for all players on a server
        public override SystemType PhaseSystemType { get { return SystemType.Player; } }

        // The Initialize routine is used to register the phase system with the Phase System Manager
        // You can also you it to place any IPhasable mobiles you have created
        public static void Initialize()
        {
            ExamplePhaseSystem eps = new ExamplePhaseSystem();

            PhaseSystemManager.RegisterPhaseSystem(eps);

            eps.PlaceMobiles();
        }

        // This routine is used to create the IPhasable mobiles you have created for your system.
        public override void PlaceMobiles()
        {
            // Creates a spawner in the world
            PlacePhasedMobile("Admirer", 3547, 2549, Map.Trammel, 1, 5);
        }

        // This routine is only used if the Phase System is set to type Server.
        // This routine is launched when the server phase has changed.  This routine could be then used to locate and delete
        // any IPhasable items that are permanently out of phase
        public override void OnServerPhaseChanged(int newPhase)
        {
        }
    }
}
