﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using Server;
using Server.Commands;
using Server.Items;
using Server.Mobiles;
using Server.Targeting;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Phasing
{
    public class ExportPhasedItems
    {
        public static void Initialize()
        {
            CommandSystem.Register("ExportPhasedItems", AccessLevel.Administrator, new CommandEventHandler(EPI_OnCommand));
            CommandSystem.Register("EPI", AccessLevel.Administrator, new CommandEventHandler(EPI_OnCommand));
        }

        [Usage("ExportPhasedItems")]
        [Aliases("EPI")]
        [Description("Exports IPhasable items from the selected area into the Data\\Phasing folder.")]
        private static void EPI_OnCommand(CommandEventArgs e)
        {
            BoundingBoxPicker.Begin(e.Mobile, new BoundingBoxCallback(EPI_Callback), null);
        }

        private static void EPI_Callback(Mobile from, Map map, Point3D start, Point3D end, object state)
        {
            PerformExport(from, map, start, end);
        }

        public static void PerformExport(Mobile from, Map map, Point3D start, Point3D end)
        {
            List<Item> toExport = new List<Item>();

            Rectangle2D rect = new Rectangle2D(start.X, start.Y, end.X - start.X + 1, end.Y - start.Y + 1);

            IPooledEnumerable eable = map.GetItemsInBounds(rect);

            foreach (Item obj in eable)
            {
                if (obj is Item && obj is IPhasable)
                    toExport.Add((Item)obj);
            }

            try { Directory.CreateDirectory(@"Data\Phasing"); }
            catch { }

            string filename = String.Format("Export_{0}_{1}{2}{3}{4}{5}{6}.xml", map.ToString(), DateTime.Now.Month, DateTime.Now.Day,
                DateTime.Now.Year, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

            XmlTextWriter writer = new XmlTextWriter(String.Format(@"Data\Phasing\{0}", filename), Encoding.ASCII);

            writer.Formatting = Formatting.Indented;
            writer.WriteStartDocument();

            writer.WriteStartElement("PHASING");

            foreach (Item item in toExport)
            {
                if (item is IPhasable)
                {
                    writer.WriteStartElement("Item");

                    writer.WriteStartAttribute("Type");
                    writer.WriteValue(item.GetType().Name);
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("ItemID");
                    writer.WriteValue(item.ItemID.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("System");
                    writer.WriteValue(((IPhasable)item).PhaseSystemName);
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("StartPhase");
                    writer.WriteValue(((IPhasable)item).PhaseStageStart.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("EndPhase");
                    writer.WriteValue(((IPhasable)item).PhaseStageEnd.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Map");
                    writer.WriteValue( (item.Map.ToString())  );
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Hue");
                    writer.WriteValue(item.Hue.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("X");
                    writer.WriteValue(item.X.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Y");
                    writer.WriteValue(item.Y.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteStartAttribute("Z");
                    writer.WriteValue(item.Z.ToString());
                    writer.WriteEndAttribute();

                    writer.WriteEndElement();
                }
            }

            writer.WriteEndElement();

            writer.WriteEndDocument();

            writer.Close();

            from.SendMessage("Export complete!");
        }
    }
}