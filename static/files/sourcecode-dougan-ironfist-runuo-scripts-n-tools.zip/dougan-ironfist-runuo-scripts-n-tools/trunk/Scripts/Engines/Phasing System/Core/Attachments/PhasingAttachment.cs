﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using System.Collections;
using System.Collections.Generic;
using Server;
using Server.Mobiles;
using Server.Engines.XmlSpawner2;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Phasing
{
    public class PhasingAttachment : XmlAttachment
    {
        private Hashtable m_SystemEntries = new Hashtable();
        public Hashtable SystemEntries { get { return m_SystemEntries; } }

        private PlayerMobile m_DupedPlayer = null;
        public PlayerMobile DupedPlayer { get { return m_DupedPlayer; } }

        private List<PlayerMobile> m_DupedBy = new List<PlayerMobile>();
        public List<PlayerMobile> DupedBy { get { return m_DupedBy; } }

        private bool m_ShowAllPhases = false;
        public bool ShowAllPhases { get { return m_ShowAllPhases; } set { m_ShowAllPhases = value; } }

        public void StartDupingPlayer(PlayerMobile player, PlayerMobile playerToDupe)
        {
            PhasingAttachment attachment;

            if (m_DupedPlayer != null)
            {
                 attachment = PhaseSystemManager.FindAttachment(m_DupedPlayer);

                 if (attachment != null)
                     attachment.RemoveDupedBy(player);
            }

            m_DupedPlayer = playerToDupe;

            attachment = PhaseSystemManager.FindAttachment(playerToDupe);

            if (attachment != null)
                attachment.AddDupedBy(player);

            PhaseSystemManager.OnPhaseChange(player);
        }

        public bool EndDupingPlayer(PlayerMobile player)
        {
            if (m_DupedPlayer != null)
            {
                PhasingAttachment attachment = PhaseSystemManager.FindAttachment(m_DupedPlayer);

                if (attachment != null)
                    attachment.RemoveDupedBy(player);

                m_DupedPlayer = null;

                PhaseSystemManager.OnPhaseChange(player);

                return true;
            }

            return false;
        }

        public void AddDupedBy(PlayerMobile player)
        {
            if (!m_DupedBy.Contains(player))
                m_DupedBy.Add(player);

        }

        public void RemoveDupedBy(PlayerMobile player)
        {
            if (m_DupedBy.Contains(player))
                m_DupedBy.Remove(player);
        }

        // a serial constructor is REQUIRED
        public PhasingAttachment(ASerial serial)
            : base(serial)
        {
        }

        [Attachable]
        public PhasingAttachment()
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0);

            writer.Write((int)m_SystemEntries.Count);

            foreach (DictionaryEntry entry in m_SystemEntries)
            {
                writer.Write((string)(entry.Key));
                writer.Write((int)(entry.Value));
            }
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            int entryCount = reader.ReadInt();

            m_SystemEntries = new Hashtable();

            for (int i = 0; i < entryCount; i++)
                SystemEntries[reader.ReadString()] = reader.ReadInt();
        }
    }
}
