﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using Server;
using Server.Items;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Phasing
{
    // Basic Phasable Static Item
    public class PhasedStaticItem : Static, IPhasable
    {
        private string m_PhaseSystemName = "";
        [CommandProperty(AccessLevel.GameMaster)]
        public string PhaseSystemName { get { return m_PhaseSystemName; } }

        private int m_PhaseStageStart = 0;
        [CommandProperty(AccessLevel.GameMaster)]
        public int PhaseStageStart { get { return m_PhaseStageStart; } }

        private int m_PhaseStageEnd = 0;
        [CommandProperty(AccessLevel.GameMaster)]
        public int PhaseStageEnd { get { return m_PhaseStageEnd; } }

        public void AssignPhasing(string systemName, int stageStart, int stageEnd)
        {
            m_PhaseSystemName = systemName;
            m_PhaseStageStart = stageStart;
            m_PhaseStageEnd = stageEnd;
        }

        public bool CanBeSeenBy(PlayerMobile player)
        {
            int stage = PhaseSystemManager.GetCurrentPhase(player, m_PhaseSystemName);

            if (stage >= 0 && stage >= PhaseStageStart && stage <= PhaseStageEnd)
                return true;
            else
                return false;
        }

        [Constructable]
        public PhasedStaticItem()
            : base(0x80)
        {
        }

        [Constructable]
        public PhasedStaticItem(int itemID)
            : base(itemID)
        {
        }

        public PhasedStaticItem(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version 

            writer.Write((string)m_PhaseSystemName);
            writer.Write((int)m_PhaseStageStart);
            writer.Write((int)m_PhaseStageEnd);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            m_PhaseSystemName = reader.ReadString();
            m_PhaseStageStart = reader.ReadInt();
            m_PhaseStageEnd = reader.ReadInt();
        }
    }
}
