﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using Server;
using Server.Items;
using Server.Mobiles;
using Server.Network;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL PHASING SYSTEMS ///

namespace Server.Phasing
{
    public class PhaseChanger : Item, IPhasable
    {
        // Defines the Phase System Name as it appears in the BasePhaseSystem object
        private string m_PhaseSystemName = "";
        [CommandProperty(AccessLevel.GameMaster)]
        public string PhaseSystemName { get { return m_PhaseSystemName; } }

        // Defines the phase in which this object is initially visible
        private int m_PhaseStageStart = 0;
        [CommandProperty(AccessLevel.GameMaster)]
        public int PhaseStageStart { get { return m_PhaseStageStart; } }

        // Defines the phase in which this object is last visible
        private int m_PhaseStageEnd = 0;
        [CommandProperty(AccessLevel.GameMaster)]
        public int PhaseStageEnd { get { return m_PhaseStageEnd; } }

        // This is the routine in any IPhaseable object that determines if the player can see the object.
        // In most cases, the routine shown below can be copied exactly as-is into your own scripts
        public bool CanBeSeenBy(PlayerMobile player)
        {
            int stage = PhaseSystemManager.GetCurrentPhase(player, m_PhaseSystemName);

            if (stage >= 0 && stage >= PhaseStageStart && stage <= PhaseStageEnd)
                return true;
            else
                return false;
        }

        // Function used by the [GenPhases command to initialize a phased item
        public void AssignPhasing(string systemName, int stageStart, int stageEnd)
        {
            m_PhaseSystemName = systemName;
            m_PhaseStageStart = stageStart;
            m_PhaseStageEnd = stageEnd;
        }

        [Constructable]
        public PhaseChanger()
            : base(0xFB5)
        {
            Name = "Statue Construction Tool";
        }

        public PhaseChanger(Serial serial)
            : base(serial)
        {
        }

        // This example advances the phase of the player phase system by using this object
        // You could use this method to advance the phase of a system, or you could do it by means of a quest,
        // killing creates, or any other method you can dream of.
        public override void OnDoubleClick(Mobile from)
        {
            if (from is PlayerMobile)
            {
                // Get the get phase from the Phase System Manager
                int stage = PhaseSystemManager.GetCurrentPhase((PlayerMobile)from, m_PhaseSystemName, true);

                if (stage >= 0 && stage < 4)
                {
                    // Increment the phase that the player is currently on
                    PhaseSystemManager.IncrementPlayerPhase((PlayerMobile)from, m_PhaseSystemName);

                    // This is an example of the routine used to advanced a serverwide phasing system.
                    //PhaseSystemManager.IncrementServerPhase(m_PhaseSystemName);

                    switch (stage)
                    {
                        case 0:
                            from.SendMessage("Workers have cleared the area and begun to lay the foundation.");
                            break;
                        case 1:
                            from.SendMessage("The foundation has been completed.");
                            break;
                        case 2:
                            from.SendMessage("Workers haul in a giant rock that will be used to sculpt the statue.");
                            break;
                        case 3:
                            from.SendMessage("Sculptors have come and crafted a fine statue.");
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version 

            writer.Write((string)m_PhaseSystemName);
            writer.Write((int)m_PhaseStageStart);
            writer.Write((int)m_PhaseStageEnd);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            m_PhaseSystemName = reader.ReadString();
            m_PhaseStageStart = reader.ReadInt();
            m_PhaseStageEnd = reader.ReadInt();
        }
    }
}