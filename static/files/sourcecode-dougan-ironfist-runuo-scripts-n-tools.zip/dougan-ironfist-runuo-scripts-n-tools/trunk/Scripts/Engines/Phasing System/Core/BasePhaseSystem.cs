﻿/*
 * 
 * Phasing System
 * Beta Version 2.6
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/7/2011
 *
 * The purpose of these scripts is to allow shard administrators to create phasing abilities for quests.
 * This simulates the phasing abilities of games like World of Warcraft.
 * 
 */

using System;
using Server;
using Server.Mobiles;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Phasing
{
    public abstract class BasePhaseSystem
    {
        public abstract string PhaseSystemName { get; }
        public abstract SystemType PhaseSystemType { get; }

        public abstract void PlaceMobiles();
        public virtual void OnServerPhaseChanged(int newPhase)
        {
        }

        protected void PlacePhasedMobile(string type, int x, int y, Map map, int count, int homeRange)
        {
            int z = UOAMVendorGenerator.GetSpawnerZ(x, y, map);

            if (!IsSpawnerPresent(type, x, y, z, map))
            {
                PremiumSpawner sp = new PremiumSpawner(type);
                sp.Count = count;
                sp.MinDelay = TimeSpan.FromMinutes(2.5);
                sp.MaxDelay = TimeSpan.FromMinutes(10.0);
                sp.Team = 0;
                sp.HomeRange = homeRange;

                sp.MoveToWorld(new Point3D(x, y, z), map);
                sp.Respawn();
                sp.BringToHome();
            }
        }

        protected bool IsSpawnerPresent(string type, int x, int y, int z, Map map)
        {
            IPooledEnumerable eable = map.GetItemsInRange(new Point3D(x, y, z), 0);

            foreach (Item item in eable)
            {
                if (item is PremiumSpawner && item.Z == z)
                    if (((PremiumSpawner)item).CreaturesName.Contains(type))
                        return true;
            }

            return false;
        }
    }
}
