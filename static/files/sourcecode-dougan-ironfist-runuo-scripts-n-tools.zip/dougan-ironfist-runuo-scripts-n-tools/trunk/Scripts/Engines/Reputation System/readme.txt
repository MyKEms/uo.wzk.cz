Reputation System
-----------------

Original thread can be found at:
	http://www.runuo.com/community/threads/runuo-2-1-reputation-system.466601/

Please review the thread for installation and usage instructions.