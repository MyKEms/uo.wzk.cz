﻿/*
 *  THIS SCRIPT IS DEFUNCT AND ONLY AVAILABLE FOR BACKWARD COMPATIBILITY
 * 
 *  DO NOT USE THIS SCRIPT
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;

namespace Server.Reputation.Quest
{
    public class AcceptConversation : QuestConversation
    {
        public override object Message
        {
            get
            {
                if (System is KillQuest)
                    return ((KillQuest)System).AcceptConversationMessage;
                else if (System is CraftQuest)
                    return ((CraftQuest)System).AcceptConversationMessage;
                else
                    return "";
            } 
        }

        public AcceptConversation()
        {
        }

        public override void OnRead()
        {
            if (System is KillQuest)
                System.AddObjective(new Kill_KillObjective());
            else if (System is CraftQuest)
                System.AddObjective(new Craft_ItemDropObjective());
        }
    }

    public class DuringConversation : QuestConversation
    {
        public override object Message
        {
            get
            {
                if (System is KillQuest)
                    return ((KillQuest)System).DuringConversationMessage;
                else if (System is CraftQuest)
                    return ((CraftQuest)System).DuringConversationMessage;
                else
                    return "";
            } 
        }

        public DuringConversation()
        {
        }

        public override bool Logged { get { return false; } }
    }

    public class EndConversation : QuestConversation
    {
        public override object Message
        {
            get
            {
                if (System is KillQuest)
                    return ((KillQuest)System).EndConversationMessage;
                else if (System is CraftQuest)
                    return ((CraftQuest)System).EndConversationMessage;
                else
                    return "";
            }
        }

        public EndConversation()
        {
        }

        public override void OnRead()
        {
            if (System is KillQuest)
                if (((KillQuest)System).AssignRewards(this.System.From))
                    System.Complete();
                else
                    System.AddObjective(new Kill_ReturnObjective());
            else if (System is CraftQuest)
                if (((CraftQuest)System).AssignRewards(this.System.From))
                    System.Complete();
                else
                    System.AddObjective(new Craft_ReturnObjective());
        }
    }
}