﻿/*
 * 
 * Reputation System
 * Beta Version 2.3
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/5/2011
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 */

using System;
using System.Collections.Generic;
using Server;
using Server.Commands;
using Server.Mobiles;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Reputation.Quest
{
    public abstract class BaseReputationQuestGiver : MondainQuester
    {
        public override bool DisallowAllMoves { get { return true; } }
        public override bool ClickTitle { get { return false; } }
        public override bool CanTeach { get { return false; } }
        public override int AutoTalkRange { get { return -1; } }
        public override int AutoSpeakRange { get { return -1; } }

        public abstract BaseReputationGroup RepGroup { get; }
        public abstract string GroupTitle { get; }

        public override void InitBody()
        {
            InitStats(100, 100, 25);
			
            Hue = Utility.RandomSkinHue();
            SpeechHue = 0x3B2;

            if (!Core.AOS)
                NameHue = 0x35;

            if (this.Female = Utility.RandomBool())
            {
                this.Body = 0x191;
                this.Name = NameList.RandomName("female");
            }
            else
            {
                this.Body = 0x190;
                this.Name = NameList.RandomName("male");
            }

            int hairHue = GetHairHue();

            Utility.AssignRandomHair(this, hairHue);
            Utility.AssignRandomFacialHair(this, hairHue);
        }

        protected void EquipItem(Item item, int hue)
        {
            item.Hue = hue;
            EquipItem(item);
        }

        public override void OnTalk(PlayerMobile player)
        {
            if (QuestHelper.DeliveryArrived(player, this))
                return;

            if (QuestHelper.InProgress(player, this))
                return;

            if (QuestHelper.QuestLimitReached(player))
                return;

            // check if this quester can offer any quest chain (already started)
            foreach (KeyValuePair<QuestChain, BaseChain> pair in player.Chains)
            {
                BaseChain chain = pair.Value;

                if (chain != null && chain.Quester != null && chain.Quester == GetType())
                {
                    BaseQuest quest = QuestHelper.RandomQuest(player, new Type[] { chain.CurrentQuest }, this);

                    if (quest != null)
                    {
                        player.CloseGump(typeof(MondainQuestGump));
                        player.SendGump(new MondainQuestGump(quest));
                        return;
                    }
                }
            }

            BaseQuest questt = QuestHelper.RandomQuest(player, Quests, this);

            if (questt is ReputationQuest)
                ((ReputationQuest)questt).InitializeQuest(player, this);

            if (questt != null)
            {
                player.CloseGump(typeof(MondainQuestGump));
                player.SendGump(new MondainQuestGump(questt));
            }
        }

        public BaseReputationQuestGiver()
            : base()
        {
        }

        public BaseReputationQuestGiver(Serial serial)
            : base(serial)
        {
        }

        public override void AddNameProperties(ObjectPropertyList list)
        {
            base.AddNameProperties(list);

            if (GroupTitle != null && GroupTitle.Trim() != "")
                list.Add(GroupTitle);
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.WriteEncodedInt((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadEncodedInt();
        }
    }
}
