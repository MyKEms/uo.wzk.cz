﻿/*
 *  THIS SCRIPT IS DEFUNCT AND ONLY AVAILABLE FOR BACKWARD COMPATIBILITY
 * 
 *  DO NOT USE THIS SCRIPT
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;

namespace Server.Reputation.Quest
{
    public class Craft_ItemDropObjective : QuestObjective
    {
        public override object Message
        {
            get
            {
                if (System is CraftQuest)
                    return ((CraftQuest)System).ItemDropObjectiveMessage;
                else
                    return "";
            } 
        }

        public override int MaxProgress
        {
            get
            {
                if (System is CraftQuest)
                    return ((CraftQuest)System).CraftCount;
                else
                    return 0;
            } 
        }

        public override void RenderProgress(BaseQuestGump gump)
        {
            if (!Completed)
            {
                gump.AddLabel(70, 280, 0x64, CurProgress.ToString());
                gump.AddLabel(100, 280, 0x64, "/");
                gump.AddLabel(130, 280, 0x64, MaxProgress.ToString());
            }
            else
            {
                base.RenderProgress(gump);
            }
        }

        public bool IsProperType(PlayerMobile player, object o)
        {
            if (o is Item && System is CraftQuest)
            {
                CraftQuest cq = (CraftQuest)System;

                if (cq.ItemType != null && cq.ItemType.IsInstanceOfType(o))
                    return true;
            }

            return false;
        }

        public bool WasCraftedByPlayer(PlayerMobile player, object o)
        {
            if (o is Item && System is CraftQuest)
            {
                if (o is BaseWeapon)
                    return ((BaseWeapon)o).PlayerConstructed;
                else if (o is BaseArmor)
                    return ((BaseArmor)o).PlayerConstructed;
            }

            return false;
        }

        public bool IsProperQuality(PlayerMobile player, object o)
        {
            if (o is Item && System is CraftQuest)
            {
                CraftQuest cq = (CraftQuest)System;

                if (!cq.RequireExceptional)
                    return true;

                if (o is BaseWeapon)
                    return ((BaseWeapon)o).Quality == WeaponQuality.Exceptional;
                else if (o is BaseArmor)
                    return ((BaseArmor)o).Quality == ArmorQuality.Exceptional;
            }

            return false;
        }

        public void ItemTurnedIn(PlayerMobile player, object o)
        {
            if (o is Item && System is CraftQuest)
            {
                ((Item)o).Delete();
                CurProgress++;
            }
        }

        public Craft_ItemDropObjective()
        {
        }

        public override void OnComplete()
        {
            System.AddObjective(new Craft_ReturnObjective());
        }
    }

    public class Craft_ReturnObjective : QuestObjective
    {
        public override object Message
        {
            get
            {
                if (System is CraftQuest)
                    return ((CraftQuest)System).ReturnObjectiveMessage;
                else
                    return "";
            }
        }

        public Craft_ReturnObjective()
        {
        }

        public override void OnComplete()
        {
            System.AddConversation(new EndConversation());
        }
    }
}
