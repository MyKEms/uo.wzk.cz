﻿/*
 * 
 * Reputation System
 * Beta Version 2.3
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/5/2011
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Reputation.Quest
{
    public abstract class ReputationQuest : BaseQuest
    {
        public abstract BaseReputationGroup RepGroup { get; }

        private string m_QuestName = null;
        public string QuestName { get { return m_QuestName; } set { m_QuestName = value; } }

        private string m_CustomDescription = null;
        public string CustomDescription { get { return m_CustomDescription; } set { m_CustomDescription = value; } }

        private string m_CustomRefuse = null;
        public string CustomRefuse { get { return m_CustomRefuse; } set { m_CustomRefuse = value; } }

        private string m_CustomUncomplete = null;
        public string CustomUncomplete { get { return m_CustomUncomplete; } set { m_CustomUncomplete = value; } }

        private string m_CustomComplete = null;
        public string CustomComplete { get { return m_CustomComplete; } set { m_CustomComplete = value; } }

        private string m_GoalName = null;
        public string GoalName { get { return m_GoalName; } set { m_GoalName = value; } }

        private Type m_GoalType = null;
        public Type GoalType { get { return m_GoalType; } set { m_GoalType = value; } }

        private int m_GoalAmount = 0;
        public int GoalAmount { get { return m_GoalAmount; } set { m_GoalAmount = value; } }

        private int m_ReputationRewarded = 0;
        public int ReputationRewarded { get { return m_ReputationRewarded; } set { m_ReputationRewarded = value; } }

        private bool m_RequireExceptional = false;
        public bool RequireExceptional { get { return m_RequireExceptional; } set { m_RequireExceptional = value; } }

        public override object Title { get { return m_QuestName; } }
        public override object Description { get { return m_CustomDescription; } }
        public override object Refuse { get { return m_CustomRefuse; } }
        public override object Uncomplete { get { return m_CustomUncomplete; } }
        public override object Complete { get { return m_CustomComplete; } }

        public abstract void InitializeQuest(PlayerMobile player, BaseReputationQuestGiver questGiver);

        public virtual bool CanAssignReputation(PlayerMobile player)
        {
            return true;
        }

        public override void GiveRewards()
        {
            base.GiveRewards();

            if (CanAssignReputation(Owner))
            {
                ReputationEntry entry = ReputationSystem.FindEntry(Owner, RepGroup.GroupName, RepGroup.StartingReputation);

                if (entry != null)
                    entry.AwardReputation(Owner, entry, m_ReputationRewarded);
            }
        }

        public ReputationQuest()
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version

            writer.Write((string)m_QuestName);
            writer.Write((string)m_CustomDescription);
            writer.Write((string)m_CustomRefuse);
            writer.Write((string)m_CustomUncomplete);
            writer.Write((string)m_CustomComplete);
            writer.Write((string)m_GoalName);
            writer.Write((string)m_GoalType.FullName);
            writer.Write((int)m_GoalAmount);
            writer.Write((int)m_ReputationRewarded);
            writer.Write((bool)m_RequireExceptional);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();

            m_QuestName = reader.ReadString();
            m_CustomDescription = reader.ReadString();
            m_CustomRefuse = reader.ReadString();
            m_CustomUncomplete = reader.ReadString();
            m_CustomComplete = reader.ReadString();
            m_GoalName = reader.ReadString();

            string type = reader.ReadString();

            if (type != null)
                m_GoalType = ScriptCompiler.FindTypeByFullName(type);

            m_GoalAmount = reader.ReadInt();
            m_ReputationRewarded = reader.ReadInt();
            m_RequireExceptional = reader.ReadBool();
        }
    }
}