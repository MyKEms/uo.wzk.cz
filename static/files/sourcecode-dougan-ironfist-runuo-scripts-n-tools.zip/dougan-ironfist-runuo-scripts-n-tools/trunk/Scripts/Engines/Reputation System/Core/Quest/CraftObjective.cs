﻿/*
 * 
 * Reputation System
 * Beta Version 2.3
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/5/2011
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 */

using System;
using System.Collections;
using System.Collections.Generic;
using Server;
using Server.Items;
using Server.Mobiles;
using Server.Regions;

/// THIS IS A CORE SCRIPT AND SHOULD NOT BE ALTERED ///

namespace Server.Engines.Quests
{
    public class CraftObjective : ObtainObjective
    {
        private bool m_ReqExceptional;
        public bool ReqExceptional { get { return m_ReqExceptional; } set { m_ReqExceptional = value; } }

        public CraftObjective(Type obtain, string name, int amount, bool requireExceptional)
            : this(obtain, name, amount, requireExceptional, 0, 0)
        {
        }

        public CraftObjective(Type obtain, string name, int amount, bool requireExceptional, int image)
            : this(obtain, name, amount, requireExceptional, image, 0)
        {
        }

        public CraftObjective(Type obtain, string name, int amount, bool requireExceptional, int image, int seconds)
            : base(obtain, name, amount, image, seconds)
        {
            m_ReqExceptional = requireExceptional;
        }

        public override bool IsObjective(Item item)
        {
            if (Obtain == null)
                return false;

            if (!Obtain.IsAssignableFrom(item.GetType()))
                return false;

            if (item is BaseWeapon && ((BaseWeapon)item).PlayerConstructed)
            {
                if (m_ReqExceptional && ((BaseWeapon)item).Quality != WeaponQuality.Exceptional)
                    return false;
                else
                    return true;
            }
            else if (item is BaseArmor && ((BaseArmor)item).PlayerConstructed)
            {
                if (m_ReqExceptional && ((BaseArmor)item).Quality != ArmorQuality.Exceptional)
                    return false;
                else
                    return true;
            }

            return false;
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.WriteEncodedInt((int)0); // version

            writer.Write((bool)m_ReqExceptional);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadEncodedInt();

            m_ReqExceptional = reader.ReadBool();
        }
    }
}
