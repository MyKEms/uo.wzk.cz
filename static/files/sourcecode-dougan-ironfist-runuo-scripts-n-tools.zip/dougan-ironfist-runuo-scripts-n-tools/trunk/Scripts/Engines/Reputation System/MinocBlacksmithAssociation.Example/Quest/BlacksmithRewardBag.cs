﻿/*
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Beta Version 2.3
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/5/2011
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 */

using System;
using Server;
using Server.Items;
using Server.Engines.Quests;
using Reward = Server.Engines.Quests.BaseReward;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION REWARDS ///

namespace Server.Reputation.Quest
{
    public class SmallBlacksmithRewardBag : Bag
    {
		public SmallBlacksmithRewardBag() : base()
		{
			Hue = Reward.RewardBagHue();

            DropItem(new Gold(Utility.RandomMinMax(250, 500)));

            Item rewardItem = GetItemReward();

            if (rewardItem != null)
                DropItem(rewardItem);

            if (Utility.RandomDouble() < 0.1)
                DropItem(BaseReward.SmithRecipe());
		}

        // This is simply a static routine used to generate a random item reward.
        public static Item GetItemReward()
        {
            double rnd = Utility.RandomDouble();

            if (rnd <= 0.02)
                return new PowderOfTemperament();       // 2% Chance
            else if (rnd <= 0.06)
                return new RingmailGlovesOfMining(5);   // 4% Chance
            else if (rnd <= 0.12)
                return new StuddedGlovesOfMining(3);    // 6% Chance
            else if (rnd <= 0.2)
                return new LeatherGlovesOfMining(1);    // 8% Chance
            else if (rnd <= 0.4)
                return new GargoylesPickaxe();          // 20% Chance
            else if (rnd <= 0.7)
                return new SturdyPickaxe();             // 30% Chance
            else
                return new SturdyShovel();              // 30% Chance
        }

        public SmallBlacksmithRewardBag(Serial serial)
            : base(serial)
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
    }

    public class LargeBlacksmithRewardBag : Bag
    {
		public LargeBlacksmithRewardBag() : base()
		{
			Hue = Reward.RewardBagHue();

            DropItem(new Gold(Utility.RandomMinMax(500, 1000)));

            Item rewardItem = SmallBlacksmithRewardBag.GetItemReward();

            if (rewardItem != null)
                DropItem(rewardItem);

            rewardItem = SmallBlacksmithRewardBag.GetItemReward();

            if (rewardItem != null)
                DropItem(rewardItem);

            if (Utility.RandomDouble() < 0.15)
                DropItem(BaseReward.SmithRecipe());
		}

        public LargeBlacksmithRewardBag(Serial serial)
            : base(serial)
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
    }
}