﻿/*
 * 
 * Reputation System    -   Minoc Blacksmithing Association Example
 * Beta Version 2.3
 * Designed for SVN 663 + ML
 * 
 * Authored by Dougan Ironfist
 * Last Updated on 3/5/2011
 * 
 * The purpose of these scripts is to allow shard administrators to create reputation groups that allow players to complete
 * quests, kill specific creatures and purchase items from reputation vendors based on their current reputation level.
 * This system is very similiar to how reputation systems work in other games.
 * 
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;
using Server.Reputation.Quest;

/// THIS IS AN EXAMPLE SCRIPT AND MAY BE USED TO CREATE ADDITIONAL REPUTATION GROUPS ///

namespace Server.Reputation.MinocBlacksmithAssociation.Quest
{
    public class MBA_KillQuestRevised : ReputationQuest
    {
        // This must contain an instance of your reputation group
        public override BaseReputationGroup RepGroup { get { return new MinocBlacksmithAssociation(); } }

        /*
         * This routine is used to determine if reputation can be awarded for this quest.
         * 
         * This routine, in combination with the creature killing hook found the reputation group definition, can be used to
         * create complex conditions on how players can earn reputation.
         * 
         * Consider the following example:
         *      The creature killing hook allows player to gain reputation up to Well Known by killing lizardmen.
         *      
         *      At the same time, the player can complete quests that allows him/her to gain reputation up to Trusted.
         *      
         *      In order to attain Member reputation, a second section of the creature killing hook allows the players
         *      to gain reputation up to Member by killing Dragons.
         */
        public override bool CanAssignReputation(PlayerMobile player)
        {
            return base.CanAssignReputation(player);
        }


        public MBA_KillQuestRevised()
            : base()
        {
        }

        public override void InitializeQuest(PlayerMobile from, BaseReputationQuestGiver questGiver)
        {
            // Use this variable to specify the name of your kill quest
            QuestName = "Favor to Miners";

            // Specify the number of creatures the player needs to kill to complete the quest
            int rnd = Utility.Random(3);
            GoalAmount = 5 + (rnd * 5);

            // Use this variable to specify the text of the quest offer
            CustomDescription = String.Format("The blacksmiths of Minoc get their supplies from many miners across the lands, but our supply lines " +
                "are frequently being interrupted.  One of the main reasons for the delays is because of the increasing number of Earth Elementals " +
                "that are hindering the labors the miners.<BR><BR>The Minoc Blacksmithing Association would like to enlist you, {0}, to " +
                "exterminate {1} of these foul creatures.", from.Name, GoalAmount);

            // Use this variable to specify the text that is displayed when talking to the quest giver during the quest
            CustomUncomplete = "You still have more earth elementals to slay.  Please come back when you are finished.";

            // Use this variable to specify the text that is displayed when the player completes the quest
            CustomComplete = "You have done it!  We will send messengers to our miners at once to inform them.";

            // Use this variable to specify the text that is displayed if the quest is refused
            CustomRefuse = String.Format("Very well. Perhaps you will have time to assist us another time.",
                questGiver.Name);

            GoalName = "Earth Elemental";           // Specify the name of the target creature
            GoalType = typeof(EarthElemental);      // Specify the Type of the target creature
            ReputationRewarded = 250;               // Specify the number of repuation points the player will receive upon completion

            AddObjective(new SlayObjective(GoalType, GoalName, GoalAmount));
            AddReward(new BaseReward(typeof(LargeBlacksmithRewardBag), "Large Blacksmith Reward Bag"));
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            // Add null objectives to allow for proper deserialization
            AddObjective(new SlayObjective(null, null, -1));

            base.Deserialize(reader);

            int version = reader.ReadInt();

            // Initialize quest parameters after deserialization completes
            SlayObjective o = (SlayObjective)Objectives[0];
            o.Creature = GoalType;
            o.Name = GoalName;
            o.MaxProgress = GoalAmount;

            // Reinitialize quest rewards
            AddReward(new BaseReward(typeof(LargeBlacksmithRewardBag), "Large Blacksmith Reward Bag"));
        }
    }
}