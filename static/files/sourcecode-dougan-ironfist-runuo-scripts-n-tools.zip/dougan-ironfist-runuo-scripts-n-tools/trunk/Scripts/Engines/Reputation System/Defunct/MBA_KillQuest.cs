﻿/*
 *  THIS SCRIPT IS DEFUNCT AND ONLY AVAILABLE FOR BACKWARD COMPATIBILITY
 * 
 *  DO NOT USE THIS SCRIPT
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;
using Server.Reputation.Quest;

namespace Server.Reputation.MinocBlacksmithAssociation.Quest
{
    public class MBA_KillQuest : KillQuest
    {
        // This must contain an instance of your reputation group
        public override BaseReputationGroup RepGroup { get { return new MinocBlacksmithAssociation(); } }

        /*
         * This routine is used to determine if reputation can be awarded for this quest.
         * 
         * This routine, in combination with the creature killing hook found the reputation group definition, can be used to
         * create complex conditions on how players can earn reputation.
         * 
         * Consider the following example:
         *      The creature killing hook allows player to gain reputation up to Well Known by killing lizardmen.
         *      
         *      At the same time, the player can complete quests that allows him/her to gain reputation up to Trusted.
         *      
         *      In order to attain Member reputation, a second section of the creature killing hook allows the players
         *      to gain reputation up to Member by killing Dragons.
         */
        public override bool CanAssignReputation(PlayerMobile player)
        {
            return base.CanAssignReputation(player);
        }


        public MBA_KillQuest(PlayerMobile from, BaseReputationQuestGiver questGiver)
            : base(from, questGiver)
        {
            // Use this variable to specify the name of your kill quest
            QuestName = "Favor to Miners";

            // Specify the number of creatures the player needs to kill to complete the quest
            int rnd = Utility.Random(3);
            KillCount = 5 + (rnd * 5);

            // Use this variable to specify the text of the quest offer
            CustomOfferMessage = String.Format("The blacksmiths of Minoc get their supplies from many miners across the lands, but our supply lines " +
                "are frequently being interrupted.  One of the main reasons for the delays is because of the increasing number of Earth Elementals " +
                "that are hindering the labors the miners.<BR><BR>The Minoc Blacksmithing Association would like to enlist you, {0}, to " +
                "exterminate {1} of these foul creatures.", from.Name, KillCount);

            // Use this variable to specify the text the player will see after accepting the quest
            AcceptConversationMessage = String.Format("{0}, please kill {1} earth elementals.", from.Name, KillCount);

            // Use this variable to specify the text that is displayed when talking to the quest giver during the quest
            DuringConversationMessage = "You still have more earth elementals to slay.  Please come back when you are finished.";

            // Use this variable to specify the text that is displayed when the player completes the quest
            EndConversationMessage = "You have done it!  We will send messengers to our miners at once to inform them.";

            // Use this variable to specify the text the player will see when they click the Quest button
            KillObjectiveMessage = String.Format("Slay {0} earth elementals", KillCount);

            // Use this variable to specify the text that is displayed after the final kill has been made
            ReturnObjectiveMessage =  String.Format("Now that you have completed your task, return to {0} in Minoc to claim your reward.",
                questGiver.Name);

            TargetName = "Earth Elemental";         // Specify the name of the target creature
            TargetType = typeof(EarthElemental);    // Specify the Type of the target creature
            MinGold = 500 + (rnd * 500);            // Specify the minimum amount of gold the player will receive upon completion
            MaxGold = 1000 + (rnd * 1000);          // Specify the maximum amount of gold the player will receive upon completion
            ReputationRewarded = 250;               // Specify the number of repuation points the player will receive upon completion
            ItemRewarded = GetItemReward();         // Specify the item the player will receive upon completion.  A value of null will yield no item.
        }

        // This is simply a static routine used to generate a random item reward.
        public static Item GetItemReward()
        {
            double rnd = Utility.RandomDouble();

            if (rnd < 0.02)
                return new PowderOfTemperament();       // 2% Chance
            else if (rnd < 0.06)
                return new RingmailGlovesOfMining(5);   // 4% Chance
            else if (rnd < 0.12)
                return new StuddedGlovesOfMining(3);    // 6% Chance
            else if (rnd < 0.2)
                return new LeatherGlovesOfMining(1);    // 8% Chance
            else if (rnd < 0.35)
                return new GargoylesPickaxe();          // 15% Chance
            else if (rnd < 0.6)
                return new SturdyPickaxe();             // 25% Chance
            else if (rnd < 0.85)
                return new SturdyShovel();              // 25% Chance
            else
                return null;                            // 15% Chance of nothing
        }

        // Serialization
        public MBA_KillQuest()
        {
        }

        public override void ChildDeserialize(GenericReader reader)
        {
            base.ChildDeserialize(reader);

            int version = reader.ReadEncodedInt();
        }

        public override void ChildSerialize(GenericWriter writer)
        {
            base.ChildSerialize(writer);

            writer.WriteEncodedInt((int)0); // version
        }
    }
}
