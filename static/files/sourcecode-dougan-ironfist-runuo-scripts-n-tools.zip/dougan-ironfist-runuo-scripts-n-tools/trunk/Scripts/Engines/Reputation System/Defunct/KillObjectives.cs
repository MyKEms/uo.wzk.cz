﻿/*
 *  THIS SCRIPT IS DEFUNCT AND ONLY AVAILABLE FOR BACKWARD COMPATIBILITY
 * 
 *  DO NOT USE THIS SCRIPT
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;

namespace Server.Reputation.Quest
{
    public class Kill_KillObjective : QuestObjective
    {
        public override object Message
        {
            get
            {
                if (System is KillQuest)
                    return ((KillQuest)System).KillObjectiveMessage;
                else
                    return "";
            } 
        }

        public override int MaxProgress
        {
            get
            {
                if (System is KillQuest)
                    return ((KillQuest)System).KillCount;
                else
                    return 0;
            } 
        }

        public override void RenderProgress(BaseQuestGump gump)
        {
            if (!Completed)
            {
                gump.AddLabel(70, 280, 0x64, CurProgress.ToString());
                gump.AddLabel(100, 280, 0x64, "/");
                gump.AddLabel(130, 280, 0x64, MaxProgress.ToString());
            }
            else
            {
                base.RenderProgress(gump);
            }
        }

        public override void OnKill(BaseCreature creature, Container corpse)
        {
            if (System is KillQuest && ((KillQuest)System).TargetType.IsInstanceOfType(creature))
                CurProgress++;
        }

        public Kill_KillObjective()
        {
        }

        public override void OnComplete()
        {
            System.AddObjective(new Kill_ReturnObjective());
        }
    }

    public class Kill_ReturnObjective : QuestObjective
    {
        public override object Message
        {
            get
            {
                if (System is KillQuest)
                    return ((KillQuest)System).ReturnObjectiveMessage;
                else
                    return "";
            }
        }

        public Kill_ReturnObjective()
        {
        }

        public override void OnComplete()
        {
            System.AddConversation(new EndConversation());
        }
    }
}
