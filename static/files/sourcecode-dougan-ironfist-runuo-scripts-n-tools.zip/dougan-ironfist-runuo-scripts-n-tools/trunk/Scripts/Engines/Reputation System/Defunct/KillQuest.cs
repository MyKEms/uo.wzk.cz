﻿/*
 *  THIS SCRIPT IS DEFUNCT AND ONLY AVAILABLE FOR BACKWARD COMPATIBILITY
 * 
 *  DO NOT USE THIS SCRIPT
 */

using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Engines.Quests;
using Server.Reputation;
using Server.Reputation.Items;

namespace Server.Reputation.Quest
{
    public abstract class KillQuest : QuestSystem
    {
        public static void Initialize()
        {
            EventSink.Login += new LoginEventHandler(EventSink_Login);
        }

        static void EventSink_Login(LoginEventArgs e)
        {
            if (e.Mobile is PlayerMobile)
            {
                PlayerMobile p = (PlayerMobile)e.Mobile;

                if (p.Quest != null && (p.Quest is KillQuest || p.Quest is CraftQuest))
                    p.Quest.Cancel();
            }
        }

        private static Type[] m_TypeReferenceTable = new Type[]
			{
                typeof( AcceptConversation ),
                typeof( DuringConversation ),
                typeof( EndConversation ),
				typeof( Kill_KillObjective ),
				typeof( Kill_ReturnObjective )
			};

        public override Type[] TypeReferenceTable { get { return m_TypeReferenceTable; } }

        public abstract BaseReputationGroup RepGroup { get; }

        private string m_QuestName = "";
        public string QuestName { get { return m_QuestName; } set { m_QuestName = value; } }

        private string m_CustomOfferMessage = "";
        public string CustomOfferMessage { get { return m_CustomOfferMessage; } set { m_CustomOfferMessage = value; } }

        private string m_AcceptConversationMessage = "";
        public string AcceptConversationMessage { get { return m_AcceptConversationMessage; } set { m_AcceptConversationMessage = value; } }

        private string m_DuringConversationMessage = "";
        public string DuringConversationMessage { get { return m_DuringConversationMessage; } set { m_DuringConversationMessage = value; } }

        private string m_EndConversationMessage = "";
        public string EndConversationMessage { get { return m_EndConversationMessage; } set { m_EndConversationMessage = value; } }

        private string m_KillObjectiveMessage = "";
        public string KillObjectiveMessage { get { return m_KillObjectiveMessage; } set { m_KillObjectiveMessage = value; } }

        private string m_ReturnObjectiveMessage = "";
        public string ReturnObjectiveMessage { get { return m_ReturnObjectiveMessage; } set { m_ReturnObjectiveMessage = value; } }

        private string m_TargetName = "";
        public string TargetName { get { return m_TargetName; } set { m_TargetName = value; } }

        private Type m_TargetType = null;
        public Type TargetType { get { return m_TargetType; } set { m_TargetType = value; } }

        private int m_KillCount = 0;
        public int KillCount { get { return m_KillCount; } set { m_KillCount = value; } }

        private int m_MinGold = 0;
        public int MinGold { get { return m_MinGold; } set { m_MinGold = value; } }

        private int m_MaxGold = 0;
        public int MaxGold { get { return m_MaxGold; } set { m_MaxGold = value; } }

        private int m_ReputationRewarded = 0;
        public int ReputationRewarded { get { return m_ReputationRewarded; } set { m_ReputationRewarded = value; } }

        private Item m_ItemRewarded = null;
        public Item ItemRewarded { get { return m_ItemRewarded; } set { m_ItemRewarded = value; } }

        public override object Name { get { return QuestName; } }
        public override object OfferMessage { get { return CustomOfferMessage; } }

        public override TimeSpan RestartDelay { get { return TimeSpan.Zero; } }
        public override bool IsTutorial { get { return false; } }
        public override int Picture { get { return 0x15C9; } }

        public virtual bool CanAssignReputation(PlayerMobile player)
        {
            return true;
        }

        public virtual bool AssignRewards(PlayerMobile player)
        {
            Container cont = BaseQuester.GetNewContainer();

            cont.DropItem(new Gold(Utility.RandomMinMax(m_MinGold, m_MaxGold)));

            if (m_ItemRewarded != null)
                cont.DropItem(m_ItemRewarded);

            if (player.PlaceInBackpack(cont))
            {
                if (CanAssignReputation(player))
                {
                    ReputationEntry entry = ReputationSystem.FindEntry(player, RepGroup.GroupName, RepGroup.StartingReputation);

                    if (entry != null)
                        entry.AwardReputation(player, entry, m_ReputationRewarded);
                }

                return true;
            }
            else
            {
                cont.Delete();
                player.SendLocalizedMessage(1046260); // You need to clear some space in your inventory to continue with the quest.  Come back here when you have more space in your inventory.
            }

            return false;
        }

        public KillQuest(PlayerMobile from, BaseReputationQuestGiver questGiver) : base(from)
        {
        }

        // Serialization
        public KillQuest()
        {
        }

        public override void ChildDeserialize(GenericReader reader)
        {
            int version = reader.ReadEncodedInt();

            m_QuestName = reader.ReadString();
            m_CustomOfferMessage = reader.ReadString();
            m_AcceptConversationMessage = reader.ReadString();
            m_DuringConversationMessage = reader.ReadString();
            m_EndConversationMessage = reader.ReadString();
            m_KillObjectiveMessage = reader.ReadString();
            m_ReturnObjectiveMessage = reader.ReadString();
            m_TargetName = reader.ReadString();

            string type = reader.ReadString();

            if (type != null)
                m_TargetType = ScriptCompiler.FindTypeByFullName(type);

            m_KillCount = reader.ReadInt();
            m_MinGold = reader.ReadInt();
            m_MaxGold = reader.ReadInt();
            m_ReputationRewarded = reader.ReadInt();
            m_ItemRewarded = reader.ReadItem();
        }

        public override void ChildSerialize(GenericWriter writer)
        {
            writer.WriteEncodedInt((int)0); // version

            writer.Write((string)m_QuestName);
            writer.Write((string)m_CustomOfferMessage);
            writer.Write((string)m_AcceptConversationMessage);
            writer.Write((string)m_DuringConversationMessage);
            writer.Write((string)m_EndConversationMessage);
            writer.Write((string)m_KillObjectiveMessage);
            writer.Write((string)m_ReturnObjectiveMessage);
            writer.Write((string)m_TargetName);
            writer.Write((string)m_TargetType.FullName);
            writer.Write((int)m_KillCount);
            writer.Write((int)m_MinGold);
            writer.Write((int)m_MaxGold);
            writer.Write((int)m_ReputationRewarded);
            writer.Write(m_ItemRewarded);
        }

        public override void Accept()
        {
            base.Accept();

            AddConversation(new AcceptConversation());
        }
    }
}