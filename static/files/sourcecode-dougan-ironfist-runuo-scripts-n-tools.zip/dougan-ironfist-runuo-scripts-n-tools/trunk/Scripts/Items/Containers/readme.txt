Fully Functional Bags of Holding and Weight Reduction Containers
----------------------------------------------------------------

Original thread can be found at:
	http://www.runuo.com/community/threads/fully-functional-bags-of-holding-and-weight-reduction-containers.466708/

Please review the thread for installation and usage instructions.