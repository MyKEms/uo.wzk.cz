﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle( "Manawydan Map Converter" )]
[assembly: AssemblyDescription( "Manawydan Map Converter" )]
[assembly: AssemblyConfiguration( "" )]
[assembly: AssemblyCompany( "Manawydan" )]
[assembly: AssemblyProduct( "Map Converter" )]
[assembly: AssemblyCopyright( "Copyright © Manawydan" )]
[assembly: AssemblyTrademark( "" )]
[assembly: AssemblyCulture( "" )]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible( false )]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid( "299ea0f6-5275-4d39-a43b-d4fec2f3848e" )]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion( "1.0.0.0" )]
[assembly: AssemblyFileVersion( "1.0.0.0" )]
