using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using System.Threading;
using Ultima;

namespace MapConverter
{
	class Converter
	{
		delegate void InfoDelegate( string msg );
		delegate void SuccessDelegate();
		enum Delimiter
		{
			None = 0,
			Left = 1,
			Right = 2,
			Top = 4,
			Bottom = 8,
			TopLeft = 3,
			TopRight = 6,
			BottomLeft = 9,
			BottomRight = 10
		}
		public static void Convert( TileMatrix tileMatrix, Form1 form, byte mapIndex, string path )
		{
			try
			{
				form.Invoke( new InfoDelegate( form.DisplayProgress ), "Conversion started!\n" );
				FileStream fs = null;
				try { fs = new FileStream( "TileDictionary.bin", FileMode.Open ); }
				catch { MessageBox.Show( "Database TileDictionary.bin cannot be found!" ); try { form.Invoke( new InfoDelegate( form.DisplayProgress ), "Conversion failed!\n" ); } catch( ObjectDisposedException e ) { } return; }
				BinaryFormatter bf = new BinaryFormatter();
				Dictionary<short, short> tileDictionary = bf.Deserialize( fs ) as Dictionary<short, short>;
				fs.Close();
				for( short blocksX = 0; blocksX < tileMatrix.Width / 64; blocksX++ )
				{
					for( short blocksY = 0; blocksY < tileMatrix.Height / 64; blocksY++ )
					{
						if( blocksX == 0 && blocksY == 0 )
						{
							WriteMapResolution( tileMatrix, path, mapIndex );
						}
						else
						{
							WriteMapBlock( tileDictionary, tileMatrix, blocksX, blocksY, form, mapIndex, path );
							if( blocksX == tileMatrix.Width / 64 && blocksY == tileMatrix.Height / 64 )
							{
								blocksY++;
								WriteMapBlock( tileDictionary, tileMatrix, blocksX, blocksY, form, mapIndex, path );
							}
						}
					}
				}
				try { form.Invoke( new InfoDelegate( form.DisplayProgress ), "Conversion succeeded!\n" ); form.Invoke( new SuccessDelegate( form.Success ) ); }
				catch( ObjectDisposedException e ) { }
			}
			catch( ThreadAbortException e ) { }
		}

		private static void WriteMapBlock( Dictionary<short, short> tileDictionary, TileMatrix tileMatrix, short blocksX, short blocksY, Form1 form, byte mapIndex, string path )
		{
			byte[] endian = new byte[ 2 ];
			double sum = blocksX * 64 + blocksY;
			FileStream mapBlock = new FileStream( path + "\\" + "facet" + mapIndex.ToString() + "-" + Math.Floor( sum / 100 ).ToString("00") + "_" + ( sum - Math.Floor( sum / 100 ) * 100 ).ToString("00") + ".dat", FileMode.Create );
			try { form.Invoke( new InfoDelegate( form.DisplayProgress ), string.Format( "Writing block: {0}\n", mapBlock.Name ) ); }
			catch( ObjectDisposedException e ) { }
			BinaryWriter writer = new BinaryWriter( mapBlock );
			writer.Write( (byte)0 );
			sum--;
			writer.Write( (short)sum );
			WriteLandTile( tileDictionary, writer, tileMatrix, 0, 0 );
			for( int x = 0 + (int)Math.Ceiling( sum / 64 ); x < 64 + (int)Math.Ceiling( sum / 64 ); x++ )
			{
				for( int y = 0 + (short)sum - (int)Math.Ceiling( sum / 64 ) * 64; y < 64 + (short)sum - (int)Math.Ceiling( sum / 64 ) * 64; y++ )
				{
					if( x == 0 && y == 0 )
					{
						// WriteStatics( tileMatrix, writer, x, y );
						continue;
					}
					if( x == 64 && y == 0 ) continue;

					writer.Write( (byte)0 );
					writer.Write( (byte)0 );
					WriteLandTile( tileDictionary, writer, tileMatrix, x, y );
					// WriteStatics( tileMatrix, writer, x, y );
					WriteDelimiters( tileMatrix, (double)x, (double)y, tileDictionary, writer );
				}
			}
			writer.Write( (byte)0 );
			writer.Write( (byte)0 );
			writer.Close();
		}

		private static void WriteLandTile( Dictionary<short, short> tileDictionary, BinaryWriter writer, TileMatrix tileMatrix, int x, int y )
		{
			byte[] endian = new byte[ 2 ];
			Tile tile = tileMatrix.GetLandTile( x, y );
			writer.Write( (sbyte)tile.Z );
			if( !tileDictionary.ContainsKey( (short)tile.ID ) )
				writer.Write( (short)0 );
			else
				writer.Write( (short)tileDictionary[ (short)tile.ID ] );
			endian = BitConverter.GetBytes( (short)tile.ID );
			writer.Write( endian[ 1 ] );
			writer.Write( endian[ 0 ] );
			writer.Write( (byte)0 );
		}

		private static void WriteDelimiters( TileMatrix tileMatrix, double x, double y, Dictionary<short, short> tileDictionary, BinaryWriter writer )
		{
			Delimiter delimiter = Delimiter.None;
			if( y - Math.Floor( y / 64 ) == 0 && y != 0 )
				delimiter = (Delimiter)( (int)delimiter + (int)Delimiter.Top );
			if( y - Math.Floor( y / 64 ) == 63 && y != tileMatrix.Height - 1 )
				delimiter = (Delimiter)( (int)delimiter + (int)Delimiter.Bottom );
			if( x - Math.Floor( x / 64 ) == 0 && x != 0 )
				delimiter = (Delimiter)( (int)delimiter + (int)Delimiter.Left );
			if( x - Math.Floor( x / 64 ) == 63 && x != tileMatrix.Width )
				delimiter = (Delimiter)( (int)delimiter + (int)Delimiter.Right );
			if( delimiter == Delimiter.None )
				return;
			else
			{
				Tile tile = new Tile();
				switch( delimiter )
				{
					case Delimiter.Left:
						writer.Write( (byte)1 );
						tile = tileMatrix.GetLandTile( (int)( x - 1 ), (int)y );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Left ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.Top:
						writer.Write( (byte)1 );
						tile = tileMatrix.GetLandTile( (int)x, (int)( y - 1 ) );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Top ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.Right:
						writer.Write( (byte)1 );
						tile = tileMatrix.GetLandTile( (int)( x + 1 ), (int)y );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Right ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.Bottom:
						writer.Write( (byte)1 );
						tile = tileMatrix.GetLandTile( (int)x, (int)( y + 1 ) );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Bottom ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.BottomLeft:
						writer.Write( (byte)3 );
						tile = tileMatrix.GetLandTile( (int)( x - 1 ), (int)y );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Left ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)x, (int)( y + 1 ) );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Bottom ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)( x - 1 ), (int)( y + 1 ) );
						writer.Write( (byte)6 );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.BottomRight:
						writer.Write( (byte)3 );
						tile = tileMatrix.GetLandTile( (int)( x + 1 ), (int)y );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Right ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)( x + 1 ), (int)( y + 1 ) );
						writer.Write( (byte)4 );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)x, (int)( y + 1 ) );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Bottom ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.TopLeft:
						writer.Write( (byte)3 );
						tile = tileMatrix.GetLandTile( (int)( x - 1 ), (int)y );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Left ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)( x - 1 ), (int)( y - 1 ) );
						writer.Write( ( (byte)1 ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)x, (int)( y - 1 ) );
						writer.Write( (byte)GetRelativeLocation( Delimiter.Top ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
					case Delimiter.TopRight:
						writer.Write( (byte)3 );
						tile = tileMatrix.GetLandTile( (int)x, (int)( y - 1 ) );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Top ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)( x + 1 ), (int)y );
						writer.Write( ( (byte)GetRelativeLocation( Delimiter.Right ) ) );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
						tile = tileMatrix.GetLandTile( (int)( x + 1 ), (int)( y + 1 ) );
						writer.Write( (byte)7 );
						writer.Write( (sbyte)tile.Z );
						if( !tileDictionary.ContainsKey( (short)tile.ID ) )
							writer.Write( (short)0 );
						else
							writer.Write( (short)tileDictionary[ (short)tile.ID ] );
						writer.Write( (byte)0 );
						break;
				}
			}
		}

		private static byte GetRelativeLocation( Delimiter delimiter )
		{
			switch( delimiter )
			{
				case Delimiter.Left:
					return 0;
				case Delimiter.Top:
					return 2;
				case Delimiter.Right:
					return 3;
				case Delimiter.Bottom:
					return 5;
				default:
					return 255;
			}
		}

		private static void WriteStatics( TileMatrix tileMatrix, BinaryWriter writer, int x, int y )
		{
			HuedTile[] statics = tileMatrix.GetStaticTiles( x, y );
			if( statics != null && statics.Length > 0 )
			{
				writer.Write( (byte)0 );
				writer.Write( (byte)statics.Length );
				for( int i = 0; i < statics.Length; i++ )
				{
					HuedTile hued = statics[ i ];
					writer.Write( (short)( hued.ID - 16384 ) );
					writer.Write( (byte)0 );
					writer.Write( (byte)0 );
					writer.Write( (sbyte)hued.Z );
					writer.Write( (short)hued.Hue );
					if( i < statics.Length - 1 )
					{
						writer.Write( (byte)0 );
						writer.Write( (byte)0 );
					}
				}
			}
		}

		private static void WriteMapResolution( TileMatrix tileMatrix, string path, byte mapIndex )
		{
			FileStream mapBlock = new FileStream( path + "\\" + "facet" + mapIndex.ToString() + "-00_00.raw", FileMode.Create );
			BinaryWriter writer = new BinaryWriter( mapBlock );
			writer.Write( tileMatrix.Height );
			writer.Write( tileMatrix.Width );
			writer.Close();
		}
	}
}