using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Ultima;

namespace MapConverter
{
	public partial class Form1 : Form
	{
		byte _map;
		Thread _thread;

		public Form1()
		{
			InitializeComponent();
		}

		public void DisplayProgress( string msg )
		{
			richTextBox1.AppendText( msg );
		}

		private void button2_Click( object sender, EventArgs e )
		{
			if( folderBrowserDialog1.ShowDialog() == DialogResult.OK )
				textBox3.Text = folderBrowserDialog1.SelectedPath.ToString();
		}

		private void button3_Click( object sender, EventArgs e )
		{
			byte map = 255;
			if( radioButton1.Checked )
				map = 0;
			else if( radioButton2.Checked )
				map = 1;
			else if( radioButton3.Checked )
				map = 2;
			else if( radioButton4.Checked )
				map = 3;
			else if( radioButton5.Checked )
				map = 4;
			if( map == 255 )
			{
				MessageBox.Show( "You have to choose map to convert!" );
				return;
			}
			_map = map;
			if( string.IsNullOrEmpty( textBox3.Text ) )
			{
				MessageBox.Show( "You have to specify folder to convert to!" );
				return;
			}
			richTextBox1.Focus();
			_thread = new Thread( new ThreadStart( Convert ) );
			_thread.Start();
		}

		public void Convert()
		{
			Converter.Convert( new TileMatrix( _map, _map, 6144, 4096 ), this, _map, textBox3.Text );
		}

		void Form1_Disposed( object sender, System.EventArgs e )
		{
			if( _thread != null && _thread.IsAlive )
				_thread.Abort();
		}

		public void Success()
		{
			MessageBox.Show( "Conversion succeeded. Thank you for using MW Map Converter :-)" );
			this.Dispose();
		}

	}
}