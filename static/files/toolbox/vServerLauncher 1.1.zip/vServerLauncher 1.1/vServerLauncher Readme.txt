Description:

Install and run the latest build of sphereserver in a few clicks with vServerLauncher. It's pretty quick and simple!

+++ Summary +++

Files to download:

=====windows======
http://nightly.prerelease.sphere.torfo.org/files/spherewin32.zip
http://nightly.prerelease.sphere.torfo.org/files/sphereNightlyScripts.tar.gz
http://scripts.sphere.torfo.org/releases/SCP-NightlyFriday.zip
http://prerelease.sphere.torfo.org/files/libMySQL.dll
http://prerelease.sphere.torfo.org/files/dbghelp.dll
http://valiostools.googlecode.com/files/axis.zip
http://valiostools.googlecode.com/files/vscp.zip
http://valiostools.googlecode.com/files/vcrypter.zip
http://valiostools.googlecode.com/files/sphereservice.zip
http://valiostools.googlecode.com/files/GumpStudio.zip
http://www.runuo.com/razor/Razor_Latest.exe
http://download.microsoft.com/download/5/B/C/5BC5DBB3-652D-4DCE-B14A-475AB85EEF6E/vcredist_x86.exe

=====linux========
http://nightly.prerelease.sphere.torfo.org/files/sphereNightly.tar.gz
http://nightly.prerelease.sphere.torfo.org/files/sphereNightlyDebug.tar.gz
http://nightly.prerelease.sphere.torfo.org/files/sphereNightlyScripts.tar.gz
http://scripts.sphere.torfo.org/releases/SCP-NightlyFriday.zip
http://valiostools.googlecode.com/files/axis.zip
http://valiostools.googlecode.com/files/vscp.zip
http://valiostools.googlecode.com/files/vcrypter.zip
http://valiostools.googlecode.com/files/sphereservice.zip
http://valiostools.googlecode.com/files/GumpStudio.zip
http://www.runuo.com/razor/Razor_Latest.exe
http://download.microsoft.com/download/5/B/C/5BC5DBB3-652D-4DCE-B14A-475AB85EEF6E/vcredist_x86.exe

Files and directories to create:

=====accounts=====
sphereaccu.scp
sphereacct.scp

=====save=========
sphereworld.scp
spherestatics.scp
spheredata.scp
spheremultis.scp
spherechars.scp

=====docs=========

=====tools=========

UO Directory - Login.cfg

Files to extract:

spherewin32.zip
SCP-NightlyFriday.zip
vscp.zip
axis.zip
vcrypter.zip
sphereservice.zip
GumpStudio.zip

Files to edit:

Sphere.ini
sphereacct.scp
spheretables.scp
sphere_serv_triggers.scp