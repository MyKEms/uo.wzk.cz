unit IntSatSelect;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs;

type
  THue = Integer;

  TSelectEvent = procedure(Sender : TObject; X, Y, R, G, B : Integer) of object;

  TIntSatSelect = class(TGraphicControl)
  private
    Bitmap : TBitmap;
    FIntensity: Integer;
    FIntensityMax: Integer;
    FSaturation: Integer;
    FSaturationMax: Integer;
    FHue: THue;
    FOnIntSatChange : TSelectEvent;
    FBitsPerColor: Integer;
    procedure SetHue(const Value: THue);
    procedure SetIntensity(const Value: Integer);
    procedure SetSaturation(const Value: Integer);
    procedure MouseMove(Shift: TShiftState; X, Y: Integer); override;
    procedure MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure SetBitsPerColor(const Value: Integer);
    procedure UpdateValuesPos(X, Y : Integer);
    procedure UpdateValues;
  public
    constructor Create(AOwner : TComponent); override;
    destructor Destroy; override;
    procedure Paint; override;
  published
    property BitsPerColor : Integer read FBitsPerColor write SetBitsPerColor default 8;
    property Hue : THue read FHue write SetHue default 0;
    property Intensity : Integer read FIntensity write SetIntensity default 0;
    property IntensityMax :Integer read FIntensityMax;
    property Saturation : Integer read FSaturation write SetSaturation default 0;
    property SaturationMax : Integer read FSaturationMax;
    property OnIntSatChange : TSelectEvent read FOnIntSatChange write FOnIntSatChange;
  end;

procedure Register;

implementation

uses
  Math, Color15bit;

procedure Register;
begin
  RegisterComponents('In House', [TIntSatSelect]);
end;

function IRGBToColor(R, G, B : Byte) : Integer;
begin
  Result := B + (G shl 8) + (R shl 16);
end;

type
  TIntegerArray = array[0..0] of Integer;
  PIntegerArray = ^TIntegerArray;
const
  CM : Integer = 256;

{ TIntSatSelect }

constructor TIntSatSelect.Create(AOwner : TComponent);
begin
  inherited Create(AOwner);
  Bitmap := TBitmap.Create;
  FBitsPerColor := 8;
end;

destructor TIntSatSelect.Destroy;
begin
  Bitmap.Free;
  inherited Destroy;
end;

procedure TIntSatSelect.Paint;
var
  X, Y : Integer;
  Row : PIntegerArray;
  R, G, B : Byte;
  RVl, GVl, BVl : Integer;
  CSt, REd, GEd, BEd : Extended;
begin
  HueToRGB(FHue, R, G, B);
  Bitmap.Width := Width;
  Bitmap.Height := Height;
  Bitmap.PixelFormat := pf32bit;
  for Y := 0 to Height-1 do
    begin
      Row := Bitmap.ScanLine[Y];
      CSt := Y*CM/Height;
      REd := Y*R*8/Height;
      GEd := Y*G*8/Height;
      BEd := Y*B*8/Height;
      for X := 0 to Width-1 do
        Row[X] := Color;
      for X := 0 to Y do
        begin
          RVl := Round(REd+X*(CSt-REd)/(Y+1));
          GVl := Round(GEd+X*(CSt-GEd)/(Y+1));
          BVl := Round(BEd+X*(CSt-BEd)/(Y+1));
          Row[X] := IRGBToColor(RVl, GVl, BVl);
        end;
    end;
  Canvas.Draw(0,0,Bitmap);
end;

procedure TIntSatSelect.UpdateValuesPos(X, Y : Integer);
var
  IntMult, SatMult : Extended;
begin
  IntMult := (1 shl BitsPerColor)/Height;
  SatMult := (1 shl BitsPerColor)/Width;
  FIntensityMax := (1 shl BitsPerColor)-1;
  FIntensity := Min(Round(Y*IntMult), FIntensityMax);
  FSaturationMax := FIntensity;
  FSaturation := Min(Round(X*SatMult), FSaturationMax);
  UpdateValues;
end;

procedure TIntSatSelect.UpdateValues;
var
  IntMult, SatMult : Extended;
  R, G, B : Byte;
  ER, EG, EB, MaxCol : Extended;
  X, Y : Integer;
begin
  IntMult := (1 shl BitsPerColor)/Height;
  SatMult := (1 shl BitsPerColor)/Width;
  if SatMult <> 0 then X := Round(FSaturation/SatMult) else X := 0;
  if IntMult <> 0 then Y := Round(FIntensity/IntMult) else Y := 0;
  HueToRGB(FHue, R, G, B);
  if (FIntensityMax <> 0) and (FSaturationMax <> 0) then
    begin
      ER := FIntensity*R/FIntensityMax;
      EG := FIntensity*G/FIntensityMax;
      EB := FIntensity*B/FIntensityMax;
      MaxCol := FIntensity*31/FIntensityMax;
      ER := ER+FSaturation*(MaxCol-ER)/FSaturationMax;
      EG := EG+FSaturation*(MaxCol-EG)/FSaturationMax;
      EB := EB+FSaturation*(MaxCol-EB)/FSaturationMax;
    end
  else
    begin
      ER := 0;
      EG := 0;
      EB := 0;
    end;
  if Assigned(FOnIntSatChange) then FOnIntSatChange(Self, X, Y, Round(ER), Round(EG), Round(EB));
end;

procedure TIntSatSelect.SetHue(const Value: THue);
begin
  FHue := Value;
  UpdateValues;
  Paint;
end;

procedure TIntSatSelect.SetIntensity(const Value: Integer);
begin
  FIntensity := Value;
  FIntensityMax := (1 shl BitsPerColor)-1;
  FSaturationMax := FIntensity;
  UpdateValues;
end;

procedure TIntSatSelect.SetSaturation(const Value: Integer);
begin
  FSaturation := Value;
  UpdateValues;
end;

procedure TIntSatSelect.MouseMove(Shift: TShiftState; X, Y: Integer);
begin
  if (Shift = [ssLeft]) and ((FIntensity <> Y) or (FSaturation <> X)) and
     (X <= Y) and (X >= 0) and (Y < Height) then
    UpdateValuesPos(X, Y);
end;

procedure TIntSatSelect.MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y : Integer);
begin
  if (Button = mbLeft) and (X <= Y) and (X >= 0) and (Y < Height) then
    UpdateValuesPos(X, Y);
end;

procedure TIntSatSelect.SetBitsPerColor(const Value: Integer);
begin
  FBitsPerColor := Value;
end;

end.
