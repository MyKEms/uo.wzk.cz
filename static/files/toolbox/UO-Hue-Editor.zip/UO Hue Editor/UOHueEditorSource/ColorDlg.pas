unit ColorDlg;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, IntSatSelect;

type
  TdlgColorSelect = class(TForm)
    imgHue: TImage;
    lblRed: TLabel;
    lblGreen: TLabel;
    lblBlue: TLabel;
    edtRed: TEdit;
    edtGreen: TEdit;
    edtBlue: TEdit;
    imgHueTag: TImage;
    imgIntTag: TImage;
    pnlColor: TPanel;
    btnOK: TButton;
    btnCancel: TButton;
    Bevel2: TBevel;
    lblHex: TLabel;
    edtHex: TEdit;
    IntSatSelect: TIntSatSelect;
    procedure FormShow(Sender: TObject);
    procedure imgHueMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y : Integer);
    procedure imgHueMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure IntSatSelectIntSatChange(Sender: TObject; X, Y, R, G, B : Integer);
  private
    FHue : Integer;
    FIntensity : Integer;
    FSaturation : Integer;
    FValue : Integer;
    WindowActive : Boolean;
    WindowWidth, WindowHeight : Integer;
    WindowHeader : String;
    procedure UpdateHue(Hue : Integer);
    procedure SetValue(Value : Integer);
    procedure SetHue(Value : Integer);

    procedure WMNCActivte(var Msg: TWMNCActivate); message WM_NCACTIVATE;
    procedure WMNCCalcSize(var Msg : TWMNCCalcSize); message WM_NCCALCSIZE;
    procedure WMNCPaint(var Msg: TMessage); message WM_NCPAINT;
  public
    Red, Green, Blue : Byte;
    property Value : Integer read FValue write SetValue;
  end;

function ColorDialog(var Color : Integer) : Boolean;

implementation

{$R *.DFM}

uses
  Math, Color15bit;

const
  SizeRad = 2*Pi / Hues;

function ColorDialog(var Color : Integer) : Boolean;
var
  dlgColorSelect: TdlgColorSelect;
begin
   // Load up this dialog
  Application.CreateForm(TdlgColorSelect, dlgColorSelect);
  dlgColorSelect.Value := Color;
  if dlgColorSelect.ShowModal = mrOK then
    begin
      Color := dlgColorSelect.Value;
      Result := True;
    end
  else
    Result := False;
  dlgColorSelect.Release;
end;

procedure XYtoHue(Radius, X, Y : Integer; var Hue : Integer);
var
  Ang, Op, Ad : Extended;
begin
  Op := Radius - Y;
  Ad := X - Radius;
  if Ad <> 0 then
    begin
      Ang := RadToDeg(ArcTan(Op / Ad));
      if Ad < 0 then Ang := 180.0 + Ang;
      while Ang < 0 do Ang := Ang + 360.0;
    end
  else
    begin
      if Op > 0 then
        Ang := 90.0
      else
        Ang := 270.0;
    end;

  Hue := Hues - Round(Ang * Hues / 360.0) -1;
  while Hue >= Hues do Dec(Hue, Hues);
  while Hue < 0 do Inc(Hue, Hues);
end;

procedure TdlgColorSelect.FormShow(Sender: TObject);
begin
  WindowHeader := Caption;
  DrawColorCircle(imgHue.Canvas, 150, 30, Color);
end;

procedure TdlgColorSelect.UpdateHue(Hue : Integer);
var
  S, C : Extended;
begin
  SinCos((2 * Hue * Pi) / Hues, S, C);
  imgHueTag.Left := imgHue.Left+150+Round(C * 135) - (imgHueTag.Width div 2);
  imgHueTag.Top  := imgHue.Top+150+Round(S * 135) - (imgHueTag.Height div 2);

  IntSatSelect.Hue := Hue;
  imgIntTag.Invalidate;
end;

 //----

procedure TdlgColorSelect.SetHue(Value : Integer);
begin
  if FHue = Value then Exit;
  UpdateHue(Value);
  FHue := Value;
end;

 //----

procedure TdlgColorSelect.imgHueMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y : Integer);
var
  Hue : Integer;
begin
  if ssLeft in Shift then
    begin
      XYtoHue(150, X, Y, Hue);
      SetHue(Hue);
    end;
end;

procedure TdlgColorSelect.imgHueMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  Hue : Integer;
begin
  if Button = mbLeft then
    begin
      btnOK.SetFocus;
      XYtoHue(150, X, Y, Hue);
      SetHue(Hue);
    end;
end;

function ThreeMax(A, B, C : Double) : Double;
begin
  Result := $00;
  if A > Result then Result := A;
  if B > Result then Result := B;
  if C > Result then Result := C;
end;

function ThreeMin(A, B, C : Double) : Double;
begin
  Result := $FF;
  if A < Result then Result := A;
  if B < Result then Result := B;
  if C < Result then Result := C;
end;

procedure TdlgColorSelect.SetValue(Value : Integer);
var
  R, G, B, X, N : Double;
begin
  // Set Hue and Intensity based on value
  R := (Value shr 10) and $1F;
  G := (Value shr 5) and $1F;
  B := Value and $1F;

  X := ThreeMax(R, G, B);
  N := ThreeMin(R, G, B);

   // Calc Int
  FIntensity := Round(X);

   // Calc Sat and undo it
  if X <> N then
    begin
      R := X*(R-N)/(X-N);
      G := X*(G-N)/(X-N);
      B := X*(B-N)/(X-N);
      FSaturation := Round(N);
    end
  else
    FSaturation := Round(X);

   // Undo Int
  if X <> 0 then
    begin
      R := 31 * R / X;
      G := 31 * G / X;
      B := 31 * B / X;
      FHue := RGBToHue(Round(R), Round(G), Round(B));
    end
  else
    FHue := 0;

  UpdateHue(FHue);
  IntSatSelect.BitsPerColor := 5;  
  IntSatSelect.Hue := FHue;
  IntSatSelect.Intensity := FIntensity;
  IntSatSelect.Saturation := FSaturation;
end;

function StrToByte(S : String) : Byte;
var
  I : Integer;
begin
  I := StrToInt(S);
  if I > 255 then I := 255;
  if I < 0 then I := 0;
  Result := I;
end;

function HexStrToInt(S : String) : Integer;
var
  I : Integer;
begin
  Result := 0;
  for I := 1 to Length(S) do
    begin
      Result := Result shl 4;
      if S[I] in ['0'..'9'] then
        Inc(Result, Ord(S[I]) - Ord('0'))
      else if S[I] in ['A'..'F'] then
        Inc(Result, 10 + Ord(S[I]) - Ord('A'))
      else
        raise Exception.Create('Invalid Hex number');
    end;
end;

 //-----------------------------------------------------------------------------

procedure TdlgColorSelect.WMNCActivte(var Msg: TWMNCActivate);
var
  MsgP : TMessage;
begin
  WindowActive := Msg.Active;
  MsgP.Msg := WM_NCPAINT;
  WMNCPaint(MsgP);
  Msg.Result := 1;
end;

procedure TdlgColorSelect.WMNCCalcSize(var Msg : TWMNCCalcSize);
begin
  inherited;
  if Msg.CalcValidRects then with Msg.CalcSize_Params.lppos^ do
    begin
      WindowWidth := CX;
      WindowHeight := CY;
    end;
end;

procedure TdlgColorSelect.WMNCPaint(var Msg: TMessage);
var
  WinCanvas : TCanvas;
  BW, BH, TH,
  WW, WH : Integer;
begin
  WinCanvas := TCanvas.Create;
  try
    WinCanvas.Handle := GetWindowDC(Handle);
    with WinCanvas do
      begin
        BW := GetSystemMetrics(SM_CXSIZEFRAME);
        BH := GetSystemMetrics(SM_CYSIZEFRAME);
        TH := GetSystemMetrics(SM_CYCAPTION);
        WW := WindowWidth;
        WH := WindowHeight;
        Brush.Color := $00000000;
        FillRect(Rect(1,1,BW,WH-1));
        FillRect(Rect(BW,1,WW-BW,BH));
        FillRect(Rect(WW-BW, 1, WW-1, WH-1));
        FillRect(Rect(BW,WH-BH,WW-BW, WH-1));
        FillRect(Rect(BW,BH,WW-BW,BH+TH));
        Brush.Color := clBtnShadow;
        FrameRect(Rect(0,0,WW,WH));

        if WindowActive then
          Brush.Color := clActiveCaption
        else
          Brush.Color := clInactiveCaption;
        FillRect(Rect(BW+3,BH+3,WW-BW-3,BH+TH-2));
        if WindowActive then
          Font.Color := clCaptionText
        else
          Font.Color := clInactiveCaptionText;
        Font.Name := 'MS Sans Serif';
        Font.Size := 8;
        Font.Style := [];
        TextOut(BW+3,BH+3,WindowHeader);
      end;
  finally
    WinCanvas.Free;
  end;
  Msg.Result := 0;
end;

procedure TdlgColorSelect.IntSatSelectIntSatChange(Sender: TObject; X,
  Y, R, G, B : Integer);
begin
  if Visible then btnOK.SetFocus;
  imgIntTag.Left := IntSatSelect.Left + X - (imgIntTag.Width div 2);
  imgIntTag.Top := IntSatSelect.Top + Y - (imgIntTag.Height div 2);
  pnlColor.Color := RGBToColor(R, G, B);
  edtRed.Text := IntToStr(R);
  edtGreen.Text := IntToStr(G);
  edtBlue.Text := IntToStr(B);
  edtHex.Text := Format('%4x', [(R shl 10) + (G shl 5) + B]);
  Red := R;
  Green := G;
  Blue := B;
  FValue := (Red shl 10) + (Green shl 5) + Blue;
end;

end.
