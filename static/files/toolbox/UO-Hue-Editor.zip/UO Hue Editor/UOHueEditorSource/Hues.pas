unit Hues;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  UOHues, ComCtrls, Grids, StdCtrls, ExtCtrls, Menus, ActnList;

type
  TfrmHues = class(TForm)
    HuesGrid: TDrawGrid;
    MainMenu1: TMainMenu;
    File1: TMenuItem;
    Help1: TMenuItem;
    Open1: TMenuItem;
    N1: TMenuItem;
    Exit1: TMenuItem;
    About1: TMenuItem;
    OpenDialog: TOpenDialog;
    SaveDialog: TSaveDialog;
    ActionList: TActionList;
    Open: TAction;
    Save: TAction;
    SaveAs: TAction;
    ExitProg: TAction;
    SaveAs1: TMenuItem;
    SaveAs2: TMenuItem;
    procedure FormShow(Sender: TObject);
    procedure HuesGridDrawCell(Sender: TObject; Col, Row: Integer;
      Rect: TRect; State: TGridDrawState);
    procedure About1Click(Sender: TObject);
    procedure OpenExecute(Sender: TObject);
    procedure SaveExecute(Sender: TObject);
    procedure SaveAsExecute(Sender: TObject);
    procedure ExitProgExecute(Sender: TObject);
    procedure HuesGridDblClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    OldRow : Integer;
    GroupCount : Integer;
    Range : Array of THueGroup;
    DataLoaded : Boolean;
    IncomingRow : Integer;
    FFileName: String;
    FDataChanged: Boolean;
    procedure SetFileName(const Value: String);
    procedure SetDataChanged(const Value: Boolean);
  public
    procedure RefreshCaption;
    property FileName : String read FFileName write SetFileName;
    property DataChanged : Boolean read FDataChanged write SetDataChanged;
  end;

var
  frmHues : TfrmHues;

implementation

{$R *.DFM}

uses
  RangeDlg, Color15bit;

procedure TfrmHues.FormShow(Sender: TObject);
begin
  HuesGrid.ColWidths[0] := 80;
  HuesGrid.ColWidths[1] := 100;
  DataLoaded := False;
end;

procedure TfrmHues.HuesGridDrawCell(Sender: TObject; Col, Row: Integer;
  Rect: TRect; State: TGridDrawState);
var
  S : String;
  Group : Integer;
  Entry : Integer;
begin
   // Draw any requested cell (Unless the data is not loaded)
  if not DataLoaded then Exit;
  with HuesGrid.Canvas do
    begin
      Brush.Style := bsSolid;
      Brush.Color := clBtnFace;
      Group := Row div 8;
      Entry := Row mod 8;
      if Col = 0 then with HuesGrid.Canvas do
        begin
          Pen.Style := psClear;
          if HuesGrid.Row = Row then
            begin
              Brush.Color := clHighlight;
              Font.Color := clHighlightText;
            end
          else
            begin
              Brush.Color := clWindow;
              Font.Color := clWindowText;
            end;
          S := Format('%d (0x%x)', [Row, Row]);
          FillRect(Rect);
          DrawText(Handle, PChar(S), Length(S), Rect, DT_CENTER or DT_VCENTER or DT_SINGLELINE);
        end
      else if Col = 1 then with HuesGrid.Canvas do
        begin
          Pen.Style := psClear;
          if HuesGrid.Row = Row then
            begin
              Brush.Color := clHighlight;
              Font.Color := clHighlightText;
            end
          else
            begin
              Brush.Color := clWindow;
              Font.Color := clWindowText;
            end;
          S := Range[Group].Entries[Entry].Name;
          FillRect(Rect);
          DrawText(Handle, PChar(S), Length(S), Rect, DT_LEFT or DT_VCENTER or DT_SINGLELINE);
        end
      else
        begin
          with Range[Group] do
            begin
              Brush.Color := Color15To32(Entries[Entry].ColorTable[Col-2]);
              FillRect(Rect);
            end;
        end;

      if (HuesGrid.Row = Row) and (OldRow <> Row) then
        begin
          Rect := HuesGrid.CellRect(0, Row);
          InvalidateRect(HuesGrid.Handle, @Rect, True);
          Rect := HuesGrid.CellRect(0, OldRow);
          InvalidateRect(HuesGrid.Handle, @Rect, True);
          OldRow := Row;
        end;
      Pen.Style := psSolid;
    end;
end;

procedure TfrmHues.About1Click(Sender: TObject);
begin
   // Cheezy About... Need to work on this  :-)
  ShowMessage('UOHueEditor' + #13 + 'by Alazane (http://alazane.surf-va.com/)');
end;

procedure TfrmHues.OpenExecute(Sender: TObject);
var
  F : TFileStream;
  I : Integer;
begin
   // Load the file from disk
  if OpenDialog.Execute then
    begin
      FileName := OpenDialog.FileName;
      F := TFileStream.Create(FileName, fmOpenRead or fmShareDenyNone);
      try
        GroupCount := F.Size div SizeOf(THueGroup);
//        GroupCount := 128; // Apparently this file is half full of garbage
        SetLength(Range, GroupCount);
        For I := 0 to GroupCount-1 do
          F.Read(Range[I], SizeOf(THueGroup));
      finally
        F.Free;
      end;
      DataLoaded := True;
      HuesGrid.RowCount := GroupCount * 8;
      HuesGrid.Row := IncomingRow;
      HuesGrid.Refresh;
      Save.Enabled := False;
      SaveAs.Enabled := True;
    end;
end;

procedure TfrmHues.SaveExecute(Sender: TObject);
var
  F : TFileStream;
  I : Integer;
begin
   // Write the file out to disk
  F := TFileStream.Create(FileName, fmCreate or fmShareExclusive);
  try
    F.Seek(0, soFromBeginning);
    for I := 0 to Length(Range)-1 do
      F.Write(Range[I], SizeOf(THueGroup));
    DataChanged := False;
  finally
    F.Free;
  end;
end;

procedure TfrmHues.SaveAsExecute(Sender: TObject);
begin
   // Change the file location, then write it out to disk
  SaveDialog.FileName := FileName;
  if SaveDialog.Execute then
    begin
      FileName := SaveDialog.FileName;
      Save.Execute;
    end;
end;

procedure TfrmHues.ExitProgExecute(Sender: TObject);
begin
  Close;
end;

procedure TfrmHues.HuesGridDblClick(Sender: TObject);
var
  Group, Entry : Integer;
begin
  if not DataLoaded then Exit;
  with HuesGrid do
    begin
      Group := Row div 8;
      Entry := Row mod 8;
      if RangeDialog(Range[Group].Entries[Entry].ColorTable, Range[Group].Entries[Entry].Name) then
        begin
          Refresh;
          DataChanged := True;
        end;
    end;
end;

procedure TfrmHues.RefreshCaption;
begin
  Caption := 'Hues - ' + ExtractFileName(FFileName);
  if FDataChanged then
    Caption := Caption + '*';
end;

procedure TfrmHues.SetFileName(const Value: String);
begin
  FFileName := Value;
  RefreshCaption;
end;

procedure TfrmHues.SetDataChanged(const Value: Boolean);
begin
  if FDataChanged = Value then Exit;
  FDataChanged := Value;
  Save.Enabled := FDataChanged;
  RefreshCaption;
end;

procedure TfrmHues.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  if DataChanged then
    case MessageDlg('Would you like to save your changes?', mtConfirmation, [mbYes, mbNo, mbCancel], 0) of
      mrYes : Save.Execute;
      mrCancel : Action := caNone;
    end;
end;

end.
