unit Color15bit;

interface

uses
  Graphics;

type
  THue = SmallInt;
  TColor15 = Word;

const
  Hues = 186;

function Color15To32(C : TColor15) : TColor;
procedure HueToRGB(Hue : THue; var Red, Green, Blue : Byte);
function RGBToHue(Red, Green, Blue : Byte) : THue;
function RGBToColor(Red, Green, Blue : Byte) : TColor;
function HueToColor(Hue : THue) : TColor;
procedure HueIntToRGB(Hue : THue; Intensity : Integer; var Red, Green, Blue : Byte);
function HueIntToColor(Hue, Intensity : Integer) : TColor;
procedure DrawColorCircle(ACanvas : TCanvas; Radius, Length : Integer; BackColor : TColor);
procedure DrawIntSatBox(Canvas : TCanvas; Length : Integer; Hue : THue; BackColor : TColor);

implementation

uses
  SysUtils, Classes, Math;

function Color15To32(C : TColor15) : TColor;
begin
  Result :=
    (((C and $1F) * 8) shl 16) or
    ((((C shr 5) and $1F) * 8) shl 8) or
    ((((C shr 10) and $1F) * 8));
end;

procedure HueToRGB(Hue : THue; var Red, Green, Blue : Byte);
var
  Base, Variation, Primary, Inclining, Declining : Integer;
begin
  while Hue < -31 do Inc(Hue, Hues);
  while Hue >= Hues-31 do Dec(Hue, Hues);

   // Calc Base
  if (Hue < 31) then
    Base := 0
  else if (Hue >= 31) and (Hue < 93) then
    Base := 1
  else
    Base := 2;

   // Calc the Variation and the Pri, Dec and Inc values
  Variation := Hue - Base * 62;
  Primary := 31;
  if Variation > 0 then
    begin
      Declining := 0;
      Inclining := Variation;
    end
  else
    begin
      Declining := -Variation;
      Inclining := 0;
    end;

   // Assign the values
  case Base of
    0 :
      begin
        Red := Primary;
        Green := Inclining;
        Blue := Declining;
      end;
    1 :
      begin
        Red := Declining;
        Green := Primary;
        Blue := Inclining;
      end;
    2 :
      begin
        Red := Inclining;
        Green := Declining;
        Blue := Primary;
      end;
  end;
end; // HueToRGB

function RGBToHue(Red, Green, Blue : Byte) : THue;
begin
  if Red = 31 then
    if Blue <> 0 then
      Result := 155+(31-Blue)
    else
      Result := 0+Green
  else if Green = 31 then
    if Red <> 0 then
      Result := 31+(31-Red)
    else
      Result := 62+Blue
  else if Blue = 31 then
    if Green <> 0 then
      Result := 93+(31-Green)
    else
      Result := 124+Red
  else
    raise Exception.Create('No maximum specified in RGBToHue');
end; // RGBToHue

function RGBToColor(Red, Green, Blue : Byte) : TColor;
begin
  Result := ((Blue * 8) shl 16) +
            ((Green * 8) shl 8) +
            (Red * 8);
end; // RGBToColor

function HueToColor(Hue : THue) : TColor;
var
  Red, Green, Blue : Byte;
begin
  HueToRGB(Hue, Red, Green, Blue);
  Result := RGBToColor(Red, Green, Blue);
end; // HueToColor

procedure HueIntToRGB(Hue : THue; Intensity : Integer; var Red, Green, Blue : Byte);
begin
  HueToRGB(Hue, Red, Green, Blue);
  if Intensity >= 32 then
    begin
      Red := Red + Round((31 - Red) / 31.0 * (Intensity - 32));
      Green := Green + Round((31 - Green) / 31.0 * (Intensity - 32));
      Blue := Blue + Round((31 - Blue) / 31.0 * (Intensity - 32));
    end
  else
    begin
      Red := Red * Intensity div 31;
      Green := Green * Intensity div 31;
      Blue := Blue * Intensity div 31;
    end;
end; // HueIntToRGB

function HueIntToColor(Hue, Intensity : Integer) : TColor;
var
  Red, Green, Blue : Byte;
begin
  HueIntToRGB(Hue, Intensity, Red, Green, Blue);
  Result := RGBToColor(Red, Green, Blue);
end; // HueIntToColor

procedure DrawColorCircle(ACanvas : TCanvas; Radius, Length : Integer; BackColor : TColor);
var
  Hue, SX, SY, EX, EY : Integer;
  S, C : Extended;
begin
  with ACanvas do
    begin
      Pen.Style := psSolid;
      Brush.Style := bsSolid;
      Brush.Color := BackColor;
      FillRect(Rect(0,0,Radius*2,Radius*2));
      for Hue := 0 to Hues-1 do
        begin
          SinCos((2 * Hue * Pi) / Hues, S, C);
          SX := Radius+Round(C * Radius);
          SY := Radius+Round(S * Radius);
          SinCos((2 * (Hue+2) * Pi) / Hues, S, C);
          EX := Radius+Round(C * Radius);
          EY := Radius+Round(S * Radius);
          if (SX <> EX) or (SY <> EY) then
            begin
              Pen.Color := HueToColor(Hue);
              Brush.Color := Pen.Color;
              Pie(0, 0, Radius*2, Radius*2, EX, EY, SX, SY);
            end;
        end;
      Pen.Color := BackColor;
      Brush.Color := BackColor;
      Ellipse(Length, Length, Radius*2-Length, Radius*2-Length);
    end;
end; // DrawColorCircle

function IRGBToColor(R, G, B : Byte) : Integer;
begin
  Result := B + (G shl 8) + (R shl 16);
end;

type
  TIntegerArray = array[0..0] of Integer;
  PIntegerArray = ^TIntegerArray;
const
  CM : Integer = 256;

procedure DrawIntSatBox(Canvas : TCanvas; Length : Integer; Hue : THue; BackColor : TColor);
var
  Bitmap : TBitmap;
  X, Y : Integer;
  Row : PIntegerArray;
  R, G, B : Byte;
  RVl, GVl, BVl : Integer;
  CSt, REd, GEd, BEd : Extended;
begin
  HueToRGB(Hue, R, G, B);
  Bitmap := TBitmap.Create;
  try
    Bitmap.Width := Length;
    Bitmap.Height := Length;
    Bitmap.PixelFormat := pf32bit;
    for Y := 0 to Length-1 do
      begin
        Row := Bitmap.ScanLine[Y];
        CSt := Y*CM/Length;
        REd := Y*R*8/Length;
        GEd := Y*G*8/Length;
        BEd := Y*B*8/Length;
        for X := 0 to Length-1 do
          Row[X] := BackColor;
        for X := 0 to Y do
          begin
            RVl := Round(REd+X*(CSt-REd)/(Y+1));
            GVl := Round(GEd+X*(CSt-GEd)/(Y+1));
            BVl := Round(BEd+X*(CSt-BEd)/(Y+1));
            Row[X] := IRGBToColor(RVl, GVl, BVl);
          end;
      end;
    Canvas.Draw(0,0,Bitmap);
  finally
    Bitmap.Free;
  end;
end; // DrawIntSatBox

end.
