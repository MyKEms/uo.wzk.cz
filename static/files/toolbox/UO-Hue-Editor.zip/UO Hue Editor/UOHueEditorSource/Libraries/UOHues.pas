unit UOHues;

interface

type
 {$A-}
  THueColorTable = array[0..31] of Word;
  THueName = array[0..19] of Char;

  THueEntry = record
    ColorTable : THueColorTable;
    TableStart, TableEnd : Word;
    Name : THueName;
  end;

  THueGroup = record
    Header : Integer;
    Entries : Array[0..7] of THueEntry;
  end;
 {$A+}

implementation

end.
