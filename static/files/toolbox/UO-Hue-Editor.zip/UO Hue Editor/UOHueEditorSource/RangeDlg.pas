unit RangeDlg;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, ComCtrls, UOHues;

type
  TdlgRange = class(TForm)
    btnOK: TButton;
    btnCancel: TButton;
    imgSpread: TPaintBox;
    btnFill: TButton;
    edtName: TEdit;
    lblName: TLabel;
    Memo1: TMemo;
    procedure imgSpreadDblClick(Sender: TObject);
    procedure imgSpreadMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure imgSpreadMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure imgSpreadPaint(Sender: TObject);
    procedure btnFillClick(Sender: TObject);
    procedure edtNameKeyPress(Sender: TObject; var Key: Char);
  private
    StartEnt, EndEnt : Integer;
    Colors : THueColorTable;
  end;

function RangeDialog(var Range : THueColorTable; var AName : THueName) : Boolean;

implementation

{$R *.DFM}

uses ColorDlg, Color15bit;

function RangeDialog(var Range : THueColorTable; var AName : THueName) : Boolean;
var
  dlgRange: TdlgRange;
begin
   // Load up this dialog
  Application.CreateForm(TdlgRange, dlgRange);
  dlgRange.edtName.Text := AName;
  dlgRange.Colors := Range;
  if dlgRange.ShowModal = mrOK then
    begin
      StrCopy(AName, PChar(Copy(dlgRange.edtName.Text,1,20)));
      Range := dlgRange.Colors;
      Result := True;
    end
  else
    Result := False;
  dlgRange.Release;
end;

procedure TdlgRange.imgSpreadDblClick(Sender: TObject);
var
  Col : Integer;
begin
  Col := Colors[StartEnt];
  if ColorDialog(Col) then
    begin
      Colors[StartEnt] := Col;
      imgSpreadPaint(Self);
    end;
end;

procedure TdlgRange.imgSpreadMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  StartEnt := X div 10;
  EndEnt := StartEnt;
  btnFill.Enabled := False;
  if StartEnt > 31 then StartEnt := 31 else if StartEnt < 0 then StartEnt := 0;
  imgSpreadPaint(Self);
end;

procedure Swap(var X, Y : Integer);
var
  T : Integer;
begin
  T := X;
  X := Y;
  Y := T;
end;

procedure TdlgRange.imgSpreadMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
  if (Shift = [ssLeft]) and (EndEnt <> X div 10) then
    begin
      EndEnt := X div 10;
      if EndEnt > 31 then EndEnt := 31 else if EndEnt < 0 then EndEnt := 0;
      btnFill.Enabled := EndEnt <> StartEnt;
      imgSpreadPaint(Self);
    end;
end;

procedure TdlgRange.imgSpreadPaint(Sender: TObject);
var
  I, SE, EE : Integer;
begin
  with imgSpread.Canvas do
    begin
      if StartEnt < EndEnt then
        begin
          SE := StartEnt;
          EE := EndEnt;
        end
      else
        begin
          SE := EndEnt;
          EE := StartEnt;
        end;

      Brush.Style := bsSolid;
      Brush.Color := clBtnFace;
      FillRect(Rect(0,0,SE*10,10));
      FillRect(Rect((EE+1)*10,0,32*10,10));
      Brush.Color := clHighlight;
      FillRect(Rect(SE*10,0,(EE+1)*10,10));

      Pen.Style := psSolid;
      for I := 0 to 31 do
        begin
          Brush.Color := Color15To32(Colors[I]);
          FillRect(Rect(I*10,12,I*10+10,imgSpread.Height));
          Pen.Color := clBlack;
          MoveTo(I*10, 13);
          LineTo(I*10, 10);
          LineTo(I*10+10,10);
          Pen.Color := clWhite;
          MoveTo(I*10+9, 13);
          LineTo(I*10+9, 11);
          LineTo(I*10+1, 11);
        end;
    end;
end;

procedure TdlgRange.btnFillClick(Sender: TObject);
var
  StartCol, EndCol : TColor;
  SE, EE : Integer;
  SR, SG, SB, ER, EG, EB : Byte;
  RD, GD, BD : Double;
  I : Integer;
begin
  if StartEnt < EndEnt then
    begin
      SE := StartEnt;
      EE := EndEnt;
    end
  else
    begin
      SE := EndEnt;
      EE := StartEnt;
    end;

  StartCol := Colors[SE];
  EndCol := Colors[EE];
   // Start colors
  SR := (StartCol shr 10) and $1F;
  SG := (StartCol shr 5) and $1F;
  SB := StartCol and $1F;
   // End colors
  ER := (EndCol shr 10) and $1F;
  EG := (EndCol shr 5) and $1F;
  EB := EndCol and $1F;
   // Color deltas
  RD := (ER-SR)/(EE-SE);
  GD := (EG-SG)/(EE-SE);
  BD := (EB-SB)/(EE-SE);
   // Load the spread into the array
  for I := 0 to EE-SE do
    Colors[SE+I] := (Round(SR+RD*I) shl 10) +
                    (Round(SG+GD*I) shl 5) +
                    Round(SB+BD*I);
  imgSpreadPaint(Self);
end;

procedure TdlgRange.edtNameKeyPress(Sender: TObject; var Key: Char);
begin
  if (Length(edtName.Text) >= 20) and
     (Key <> #8) and (edtName.SelLength = 0) then
    Key := #0; 
end;

end.
