program UOHueEditor;

uses
  Forms,
  ColorDlg in 'ColorDlg.pas' {dlgColorSelect},
  RangeDlg in 'RangeDlg.pas' {dlgRange},
  Hues in 'Hues.pas' {frmHues};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'UOHueEditor';
  Application.CreateForm(TfrmHues, frmHues);
  Application.Run;
end.
