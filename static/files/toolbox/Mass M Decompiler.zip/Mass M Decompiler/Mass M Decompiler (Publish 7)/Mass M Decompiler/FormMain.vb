﻿Imports JoinUO.UOdemoSDK
Imports JoinUO.UOdemoSDK.Events
Imports JoinUO.UOdemoSDK.Obfuscator
Imports JoinUO.UOdemoSDK.Decompiler
Imports JoinUO.UOdemoSDK.SDB

Public Class FormMain
  Private Shared tmpEncoder As New System.Text.ASCIIEncoding
  Private Shared SDB As New SDB

  Private Shared TargetLanguage As TargetLanguage = TargetLanguage.EnhancedUOSL
  Private ExitState As Integer = 0 ' 0 = running, 1 = exit requested, 2 = exit approved, 3 = exiting

  Public Class DECOMPILED_SCRIPT
    Public Property TechnicalInfo As String
    Public Property TokenList As List(Of UoToken)
  End Class

  Private Class LISTBOXITEM_SCRIPT
    Public ScriptPath As String
    Private ScriptName As String

    Private _UserListing As String
    ReadOnly Property UserListing() As String
      Get
        Return _UserListing
      End Get
    End Property

    Private _TechnicalListing As String
    ReadOnly Property BinaryListing() As String
      Get
        Return _TechnicalListing
      End Get
    End Property

    Private _DecompiledScript As DECOMPILED_SCRIPT
    Property DecompiledScript As DECOMPILED_SCRIPT
      Get
        Return _DecompiledScript
      End Get
      Set(ByVal _DecompiledData As DECOMPILED_SCRIPT)
        Me._DecompiledScript = _DecompiledData
        Call GenerateListings(_TechnicalListing, _UserListing)
      End Set
    End Property

    Public Sub New(ByVal _ScriptPath As String)
      ' Set the path & contents
      Me.ScriptPath = _ScriptPath

      ' Empty ones...
      GenerateListings(_TechnicalListing, _UserListing)

      ' Remove .Q
      If Microsoft.VisualBasic.Right(_ScriptPath, 2).ToLowerInvariant = ".q" Then
        _ScriptPath = _ScriptPath.Substring(0, _ScriptPath.Length - 2)
      End If

      ' Set the name
      ScriptName = IO.Path.GetFileNameWithoutExtension(_ScriptPath)
    End Sub

    Private Sub GenerateListings(ByRef _BinaryListing As String, ByRef _UserListing As String)
      ' Generate the listings
      If _DecompiledScript Is Nothing OrElse _DecompiledScript.TokenList Is Nothing Then
        _BinaryListing = ""
        _UserListing = ""
      Else
        _BinaryListing = _DecompiledScript.TechnicalInfo
        _UserListing = ProduceSourceCode(_DecompiledScript.TokenList, TargetLanguage).Replace(vbTab, "  ")
      End If
    End Sub

    Public Overrides Function ToString() As String
      Return ScriptName
    End Function
  End Class

  Private Sub FormMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    '
    If e.CloseReason <> CloseReason.ApplicationExitCall Then
      If Not Me.Button_ScanAndDecompileAll.Enabled Then
        ' If the interface is not active then we must use the thread to request an exit!
        ' NOTE: the interface is not active when the scan and decompile thread is doing its job
        e.Cancel = True
        Timer_Exit.Enabled = True
      End If
    End If
  End Sub

  Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Listbox
    Me.ComboBox_TargetLanguages.Items.Add("UOSL")
    Me.ComboBox_TargetLanguages.Items.Add("UOSL (native)")
    Me.ComboBox_TargetLanguages.Items.Add("UO-C (old)")
    Me.ComboBox_TargetLanguages.Items.Add("Real C")

    ' Get the last scanned script directory
    Dim ScriptDirectory As String
    Try
      ScriptDirectory = GetSetting("Mass M Decompiler", "Main", "ScriptDirectory").Trim
    Catch
      ScriptDirectory = ""
    End Try

    ' NOTE: if not set try to get the setting from the "normal" M Decompiler
    If ScriptDirectory = "" Then
      Try
        ScriptDirectory = GetSetting("M Decompiler", "Main", "ScriptDirectory").Trim
      Catch
      End Try
    End If

    ' NOTE: if not set try to get the setting from the "normal" M Decompiler
    If ScriptDirectory = "" Then
      Try
        ScriptDirectory = GetSetting("M Compiler", "Main", "ScriptDirectory").Trim
      Catch
      End Try
    End If

    ' Get the pseudo-C generation flag
    Dim sTargetLanguage As String
    Try
      sTargetLanguage = GetSetting("Mass M Decompiler", "Main", "TargetLanguage").Trim.ToLowerInvariant
    Catch
      sTargetLanguage = ""
    End Try
    If sTargetLanguage = "" Then
      Dim sGenerateRealC As String
      Try
        sGenerateRealC = GetSetting("Mass M Decompiler", "Main", "GenerateRealC").Trim.ToLowerInvariant
      Catch
        sGenerateRealC = ""
      End Try
      If sGenerateRealC = "yes" Then
        Me.ComboBox_TargetLanguages.SelectedIndex = 3
      Else
        Me.ComboBox_TargetLanguages.SelectedIndex = 0
      End If
    ElseIf sTargetLanguage = "uo-cv2" OrElse sTargetLanguage = "uosl" Then
      Me.ComboBox_TargetLanguages.SelectedIndex = 0
    ElseIf sTargetLanguage = "uo-c" OrElse sTargetLanguage = "uosln" Then
      Me.ComboBox_TargetLanguages.SelectedIndex = 1
    ElseIf sTargetLanguage = "uo-cv1" Then
      Me.ComboBox_TargetLanguages.SelectedIndex = 2
    ElseIf sTargetLanguage = "real-c" Then
      Me.ComboBox_TargetLanguages.SelectedIndex = 3
    Else
      Me.ComboBox_TargetLanguages.SelectedIndex = 0
    End If

    ' Fix double cases?
    Try
      Dim sFixDoubleCases As String = GetSetting("Mass M Decompiler", "Main", "FixDoubleCases").Trim.ToLowerInvariant
      Me.CheckBox_FixDoubleCases.Checked = sFixDoubleCases = "yes"
    Catch
      Me.CheckBox_FixDoubleCases.Checked = True
    End Try

    If ScriptDirectory <> "" Then
      ' Set the script directory
      Me.TextBox_ScriptDirectory.Text = ScriptDirectory
    End If
  End Sub

  Private Sub Button_ScanAndDecompileAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ScanAndDecompileAll.Click
    ' Disable the interface during the scan
    Me.TextBox_ScriptDirectory.Enabled = False
    Me.ComboBox_TargetLanguages.Enabled = False
    Me.CheckBox_FixDoubleCases.Enabled = False
    Me.Button_ScanAndDecompileAll.Enabled = False

    ' Clear the list with scripts
    Me.ListBox_ScriptList.SelectedItems.Clear()
    Me.ListBox_ScriptList.Items.Clear()

    Try
      ' Get the script directory to scan
      Dim ScriptDirectory As String = Me.TextBox_ScriptDirectory.Text.Trim

      ' Get the target language
      Select Case ComboBox_TargetLanguages.SelectedIndex
        Case 1
          TargetLanguage = Decompiler.TargetLanguage.NativeUOSL
        Case 2
          TargetLanguage = Decompiler.TargetLanguage.EnhancedUOC
        Case 3
          TargetLanguage = Decompiler.TargetLanguage.RealC
        Case Else
          TargetLanguage = Decompiler.TargetLanguage.EnhancedUOSL
      End Select

      ' Determine the SDB file
      Dim SDBPath As String = IO.Path.Combine(ScriptDirectory, "sdb.txt")
      If Not IO.File.Exists(SDBPath) Then
        SDBPath &= ".q"
        If Not IO.File.Exists(SDBPath) Then
          SDBPath = Nothing
        End If
      End If
      If SDBPath Is Nothing Then
        Throw New Exception("Unable to locate SDB.TXT in the script directory!")
      End If

      ' Load the SDB file
      SDB.Load(SDBPath)

      ' The SDB was valid, so save the directory
      Try
        SaveSetting("Mass M Decompiler", "Main", "ScriptDirectory", ScriptDirectory)
      Catch
      End Try

      ' Save the target language
      Try
        Select Case TargetLanguage
          Case Decompiler.TargetLanguage.EnhancedUOC
            SaveSetting("Mass M Decompiler", "Main", "TargetLanguage", "UO-Cv1")
          Case Decompiler.TargetLanguage.RealC
            SaveSetting("Mass M Decompiler", "Main", "TargetLanguage", "Real-C")
          Case Decompiler.TargetLanguage.NativeUOSL
            SaveSetting("Mass M Decompiler", "Main", "TargetLanguage", "UOSLn")
          Case Else
            SaveSetting("Mass M Decompiler", "Main", "TargetLanguage", "UOSL")
        End Select
      Catch
      End Try

      ' Save the Fix Double Case
      SaveSetting("Mass M Decompiler", "Main", "FixDoubleCases", IIf(Me.CheckBox_FixDoubleCases.Checked, "Yes", "No"))

      ' Start the scan thread 
      Dim thread As New Threading.Thread(AddressOf ScanAndDecompileAll)
      thread.Start(ScriptDirectory)
    Catch ex As Exception
      MsgBox(ex.Message)

      ' Enable the interface on error
      Me.TextBox_ScriptDirectory.Enabled = True
      Me.ComboBox_TargetLanguages.Enabled = True
      Me.CheckBox_FixDoubleCases.Enabled = True
      Me.Button_ScanAndDecompileAll.Enabled = True
    End Try
  End Sub

  Private Sub ScanAndDecompileAll(ByVal ScriptDirectory As String)
    '
    Dim RootTitle As String = Me.Text

    Try
      ' Get all *.M files and all *.M.Q files
      For Each FilePath As String In My.Computer.FileSystem.GetFiles(ScriptDirectory, FileIO.SearchOption.SearchTopLevelOnly, New String() {"*.M", "*.M.Q"})
        Dim LBIS As New LISTBOXITEM_SCRIPT(FilePath)

        ' Add to the list
        Call AddScript(LBIS, RootTitle)

        ' Do the actual decompile
        Try
          LBIS.DecompiledScript = DecompileM(LBIS.ToString, LBIS.ScriptPath)
        Catch
        End Try

        ' Abort the loop if the user requested an exit
        If ExitState > 0 Then
          Exit For
        End If
      Next
    Catch
    End Try

    '
    Call AddScript(Nothing, RootTitle)
  End Sub

  Private Delegate Sub Delegate_AddScript(ByRef LBIS As LISTBOXITEM_SCRIPT, ByVal RootTitle As String)
  Private Sub AddScript(ByRef LBIS As LISTBOXITEM_SCRIPT, ByVal RootTitle As String)
    If Me.InvokeRequired Then
      Me.Invoke(New Delegate_AddScript(AddressOf AddScript), LBIS, RootTitle)
    Else
      If LBIS Is Nothing Then
        ' Set the window title!
        Me.Text = RootTitle

        If ExitState = 0 Then
          ' Enable the interface again
          Me.TextBox_ScriptDirectory.Enabled = True
          Me.ComboBox_TargetLanguages.Enabled = True
          Me.CheckBox_FixDoubleCases.Enabled = True
          Me.Button_ScanAndDecompileAll.Enabled = True
        Else
          ' Indicate we are ready to quit
          ExitState = 2
        End If
      Else
        ' Add to the list and update the window title!
        Me.ListBox_ScriptList.Items.Add(LBIS)
        Me.Text = RootTitle & " - " & IO.Path.GetFileName(LBIS.ScriptPath)
      End If
    End If
  End Sub

  Public Function DecompileM(ByVal ScriptName As String, ByVal FilePath As String) As DECOMPILED_SCRIPT
    ' Open the file
    Dim File As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

    ' Return an empty decompiled string if the file length is zero
    If File.Length = 0 Then
      Return Nothing
    End If

    ' Read into a buffer
    Dim TempBuffer(File.Length) As Byte
    File.Read(TempBuffer, 0, File.Length)

    ' Add 0-Byte at the end of the buffer
    TempBuffer(File.Length) = 0

    ' Close the file
    File.Close()

    Return DecompileM(ScriptName, TempBuffer)
  End Function

  Private Shared Function ConvertUoTokenToCode(ByVal Token As UoToken) As String
    If TypeOf (Token) Is UoToken.UoTypeName Then
      Return "VARIABLE-TYPE=" & Token.Value
    End If

    If TypeOf (Token) Is UoToken.UoKeyword Then
      If TypeOf (Token) Is UoToken.UoKeyword_this Then
        Return "this"
      End If
      If TypeOf (Token) Is UoToken.UoKeyword_inherits Then
        Return "INHERITS"
      End If
      If TypeOf (Token) Is UoToken.UoKeyword_member Then
        Return "DEFINE-MEMBER"
      End If
      If TypeOf (Token) Is UoToken.UoKeyword_forward Then
        Return "DECLARE-FUNCTION"
      End If
      If TypeOf (Token) Is UoToken.UoKeyword_function Then
        Return "DEFINE-FUNCTION"
      End If
      If TypeOf (Token) Is UoToken.UoKeyword_trigger Then
        Return "DEFINE-TRIGGER"
      End If
      Return Token.Value.ToUpperInvariant
    End If

    Return Token.Value
  End Function

  Public Function DecompileM(ByVal ScriptName As String, ByVal Contents() As Byte) As DECOMPILED_SCRIPT
    Dim DecompiledData As New System.Text.StringBuilder

    Select Case TargetLanguage
      Case Decompiler.TargetLanguage.NativeUOSL
        DecompiledData.Append("#NativeUOSL§UOSL (native)")
      Case Decompiler.TargetLanguage.RealC
        DecompiledData.Append("#Real-C§Real-C")
      Case Decompiler.TargetLanguage.EnhancedUOC
        DecompiledData.Append("#Enhanced-UOC§UO-C (old)")
      Case Else
        DecompiledData.Append("#EnhancedUOSLC§UOSL (enhanced)")
    End Select
    DecompiledData.Append(vbNewLine)

    ' Process all tokens in this byte-array using the decompiler-tokenizer
    Dim TokenList As New List(Of UoToken)
    Dim Tokenizer As New Tokenizer(Contents)
    Tokenizer.SDB = SDB
    Do
      ' Abort the loop if the user wants us to quit
      If ExitState > 0 Then
        Exit Do
      End If

      '
      DecompiledData.Append("@$")
      DecompiledData.Append(Tokenizer.Address.ToString("X4"))
      DecompiledData.Append(":")

      ' Exit the loop if we reached the end
      If Tokenizer.Source(Tokenizer.Address) = 0 Then
        DecompiledData.Append("$00->DONE")
        Exit Do
      End If
      If Not Tokenizer.IsTokenAvailable() Then
        DecompiledData.Append("NO_TOKEN_ERROR")
        Exit Do
      End If

      ' Get the encrypted script-word and convert it to an unencrypted script-byte
      Dim Encrypted As UInt16 = Tokenizer.Source(Tokenizer.Address + 1) * 256 + Contents(Tokenizer.Address)
      Dim ScriptByte As Byte = Deobfuscate(Encrypted)

      '
      DecompiledData.Append("$")
      DecompiledData.Append(Encrypted.ToString("X4"))
      DecompiledData.Append("=$")
      DecompiledData.Append(ScriptByte.ToString("X2"))
      DecompiledData.Append("->")

      ' Special handling for some
      Dim code As String = ""
      Select Case ScriptByte
        Case &H27
          code = "ENDIF"
        Case &H29
          code = "WEND"
        Case &H2B
          code = "NEXT"
        Case &H2E
          code = "GOTO"
        Case &H30
          code = "END SELECT"
        Case Else
          Dim AddNewLine As Boolean = False
          Select Case ScriptByte
            Case UoToken.UoScriptByte.SingleByteConstant
              ' Binary output
              DecompiledData.Append("BYTE")
              AddNewLine = True
            Case UoToken.UoScriptByte.DoubleByteConstant
              ' Binary output
              DecompiledData.Append("DOUBLEBYTE")
              AddNewLine = True
            Case UoToken.UoScriptByte.QuadByteConstant
              ' Binary output
              DecompiledData.Append("QUADBYTE")
              AddNewLine = True
            Case UoToken.UoScriptByte.StringConstant
              ' Binary output
              DecompiledData.Append("STRING")
              AddNewLine = True
            Case UoToken.UoScriptByte.QuotedStringConstant
              ' Binary output
              DecompiledData.Append("QUOTED-STRING")
              AddNewLine = True
          End Select
          If AddNewLine Then
            DecompiledData.Append(vbNewLine)
            DecompiledData.Append("@$")
            DecompiledData.Append((Tokenizer.Address + 2).ToString("X4"))
            DecompiledData.Append(":")
          End If

          Dim NewToken As UoToken = Tokenizer.GetToken()
          If NewToken IsNot Nothing Then
            ' Process the token
            If AddNewLine Then
              Select Case ScriptByte
                Case UoToken.UoScriptByte.SingleByteConstant
                  ' Binary output
                  Dim h As String = NewToken.Value.Substring(2)
                  Dim c As Int32 = Int32.Parse(h, Globalization.NumberStyles.AllowHexSpecifier)
                  code = ":" & h & "->" & c.ToString
                Case UoToken.UoScriptByte.DoubleByteConstant
                  ' Binary output
                  Dim h As String = NewToken.Value.Substring(2)
                  Dim c As Int32 = Int32.Parse(h, Globalization.NumberStyles.AllowHexSpecifier)
                  code = ":" & h & "->" & c.ToString
                Case UoToken.UoScriptByte.QuadByteConstant
                  ' Binary output
                  Dim h As String = NewToken.Value.Substring(2)
                  Dim c As Int32 = Int32.Parse(h, Globalization.NumberStyles.AllowHexSpecifier)
                  code = ":" & h & "->" & c.ToString
                Case UoToken.UoScriptByte.StringConstant
                  ' Binary output
                  Dim iSDB As Integer = Tokenizer.Source(Tokenizer.Address - 1) * 256 + Tokenizer.Source(Tokenizer.Address - 2)
                  code = "$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->'" & NewToken.Value & "'"
                Case UoToken.UoScriptByte.QuotedStringConstant
                  ' Binary output
                  Dim iSDB As Integer = Tokenizer.Source(Tokenizer.Address - 1) * 256 + Tokenizer.Source(Tokenizer.Address - 2)
                  Dim value As String = NewToken.Value
                  If ScriptName = "tutdragon" AndAlso iSDB = 8850 Then
                    ' NOTE: tutdragon contains a bug (invalid index to the SDB), indicate this
                    value = "TUTDRAGON-SDB-BUG->" & value
                  End If
                  code = "$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->" & value
              End Select
            Else
              code = ConvertUoTokenToCode(NewToken)
            End If
            TokenList.Add(NewToken)
          Else
            DecompiledData.Append("INVALID_TOKEN_ERROR")
            Exit Do
          End If
      End Select

      '
      DecompiledData.Append(code)
      DecompiledData.Append(vbNewLine)
    Loop

    ' Don't forget to do the post-processing!
    If TargetLanguage <> Decompiler.TargetLanguage.NativeUOSL Then
      PostProcessTokenList(TokenList)
    End If

    ' Detect and Fix 'Double Cases'
    If TargetLanguage = Decompiler.TargetLanguage.EnhancedUOSL AndAlso Me.CheckBox_FixDoubleCases.Checked Then
      Dim Doubles As New List(Of Integer)
      For i As Integer = 0 To TokenList.Count - 1
        If TypeOf TokenList(i) Is UoToken.UoKeyword_switch Then
          Call ScanSwitchForDoubles(i, TokenList, Doubles)
        End If
      Next
      If Doubles.Count > 0 Then
        ' NOTE: reverse the list with doubles so we can remove tokens without to much trouble
        Doubles.Reverse()
        For Each i As Integer In Doubles
          If TypeOf TokenList(i - 2) Is UoToken.UoColon Then
            ' Safe to comment out quickly!
            Dim comment As String = TokenList(i - 1).Value & " " & TokenList(i).Value & TokenList(i + 1).Value
            TokenList.RemoveAt(i + 1)
            TokenList.RemoveAt(i)
            TokenList(i - 1) = New UoToken.UoComment("/* " & comment & " */")
          ElseIf TypeOf TokenList(i - 3) Is UoToken.UoKeyword_break AndAlso TypeOf TokenList(i - 2) Is UoToken.UoSemicolon AndAlso TypeOf TokenList(i + 4) Is UoToken.UoColon Then
            ' Safe to comment out quickly!
            Dim comment As String = TokenList(i - 1).Value & " " & TokenList(i).Value & TokenList(i + 1).Value
            TokenList.RemoveAt(i + 1)
            TokenList.RemoveAt(i)
            TokenList(i - 1) = New UoToken.UoComment("/* " & comment & " */")
          ElseIf TypeOf TokenList(i + 2) Is UoToken.UoKeyword_switch Then
            ' Unsafe to comment out quickly! Should normally only occur for the shipplank script
            Dim j As Integer = i + 2
            Dim tempi As Integer = j
            Dim tempDoubles As New List(Of Integer)
            Call ScanSwitchForDoubles(tempi, TokenList, tempDoubles)
            Dim commentA As String = "", commentB As String = ""
            While Not TypeOf TokenList(tempi) Is UoToken.UoKeyword_case
              commentB = commentB & " " & TokenList(tempi).Value
              TokenList.RemoveAt(tempi)
            End While
            For counter As Integer = 1 To tempi - j
              commentA = commentA & " " & TokenList(j).Value
              TokenList.RemoveAt(j)
            Next

            ' Continue
            Dim comment As String = TokenList(i - 1).Value & " " & TokenList(i).Value & TokenList(i + 1).Value
            TokenList.RemoveAt(i + 1)
            TokenList.RemoveAt(i)
            TokenList(i - 1) = New UoToken.UoComment("/* " & comment & " " & commentA & " " & commentB & " */")
          Else
            ' Unhandled!
            MsgBox("WARNING! unhandled double case found: " & TokenList(i - 4).Value & " " & TokenList(i - 3).Value & " " & TokenList(i - 2).Value & " " & TokenList(i - 1).Value & " " & TokenList(i - 0).Value)
          End If
        Next
      End If
    End If

    Dim ret As New DECOMPILED_SCRIPT
    ret.TechnicalInfo = DecompiledData.ToString
    ret.TokenList = TokenList
    Return ret
  End Function

  Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox_ScriptList.SelectedIndexChanged
    If Me.ListBox_ScriptList.SelectedItems.Count = 0 Then
      Me.TextBox1.Text = ""
      Me.TextBox2.Text = ""
    Else
      Dim LBIS As LISTBOXITEM_SCRIPT = Me.ListBox_ScriptList.SelectedItems(0)
      Me.TextBox1.Text = LBIS.BinaryListing
      Me.TextBox2.Text = LBIS.UserListing
    End If
  End Sub

  Private Sub Timer_Exit_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_Exit.Tick
    ' Indicate to the thread we want to exit
    If ExitState = 0 Then
      ExitState = 1
    End If

    ' If the thread told us it has exited then go quit
    If ExitState = 2 Then
      ExitState = 3

      '
      Me.Timer_Exit.Enabled = False
      Application.Exit()
    End If
  End Sub

  Private Sub Button_DumpAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DumpAll.Click
    Dim ScriptDirectory As String
    Try
      ScriptDirectory = GetSetting("Mass M Decompiler", "Main", "ScriptDirectory").Trim
    Catch
      ScriptDirectory = ""
    End Try

    Try
      If IO.Directory.Exists(ScriptDirectory) Then
        ' Determine the target directory
        Dim TargetDirectory As String = "?", Extension As String = "?"
        Select Case TargetLanguage
          Case Decompiler.TargetLanguage.NativeUOSL
            TargetDirectory = "scripts.uosln"
            Extension = ".uosl.q"
          Case Decompiler.TargetLanguage.EnhancedUOSL
            TargetDirectory = "scripts.uosl"
            Extension = ".uosl.q"
          Case Decompiler.TargetLanguage.EnhancedUOC
            TargetDirectory = "scripts.uoc"
            Extension = ".m.uoc"
          Case Decompiler.TargetLanguage.RealC
            TargetDirectory = "scripts.c"
            Extension = ".m.C"
        End Select

        ' Ensure that our directory for the C scripts exists
        Dim OutputDirectory As String = IO.Path.GetFullPath(IO.Path.Combine(ScriptDirectory, "..\" & TargetDirectory))
        If Not IO.Directory.Exists(OutputDirectory) Then
          IO.Directory.CreateDirectory(OutputDirectory)
        End If

        ' For each decompiled script, write the user listing to disk
        For Each LBI As LISTBOXITEM_SCRIPT In ListBox_ScriptList.Items
          Dim name As String = LBI.ToString
          Dim Listing As String = LBI.UserListing
          Dim fs As New IO.FileStream(IO.Path.Combine(OutputDirectory, name & Extension), IO.FileMode.Create)
          Dim sw As New IO.StreamWriter(fs)
          sw.Write(Listing)
          sw.Close()
          fs.Close()
        Next

        '
        MsgBox("Done.")
      Else
        MsgBox("Unable to locate " & ScriptDirectory)
      End If
    Catch ex As Exception
      MsgBox("Error: " & ex.Message)
    End Try
  End Sub

  Private Sub Button_SelectScriptDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SelectScriptDirectory.Click
    Try
      ' Use a Select Directory Dialog to get a new directory
      Dim GetFolder As New FolderBrowserDialog
      GetFolder.ShowNewFolderButton = False
      GetFolder.SelectedPath = Me.TextBox_ScriptDirectory.Text.Trim
      If GetFolder.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Me.TextBox_ScriptDirectory.Text = GetFolder.SelectedPath
      End If
    Catch ex As Exception
      ' Error!
      MsgBox(ex.Message)
    End Try
  End Sub

  Private Sub ComboBox_TargetLanguages_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_TargetLanguages.SelectedIndexChanged
    Me.CheckBox_FixDoubleCases.Visible = Me.ComboBox_TargetLanguages.SelectedIndex = 0
    Me.CheckBox_FixDoubleCases_Never.Visible = Not Me.CheckBox_FixDoubleCases.Visible
  End Sub

  Public Sub ScanSwitchForDoubles(ByRef i As Integer, ByRef TokenList As List(Of UoToken), ByRef Doubles As List(Of Integer))
    Dim BraceCounter As Integer = 0
    Dim Cases As New Specialized.StringDictionary
    Dim NextTokenIsCaseValue As Boolean = False
    For i = i + 1 To TokenList.Count - 1
      Dim token As UoToken = TokenList(i)
      If NextTokenIsCaseValue Then
        If TypeOf token Is UoToken.UoConstantNumber Then
          Dim value As String = token.Value
          If Cases.ContainsKey(value) Then
            ' Double
            Doubles.Add(Cases(value))
            Cases(value) = i
          Else
            ' Unique
            Cases.Add(value, i)
          End If
        End If
        NextTokenIsCaseValue = False
      ElseIf TypeOf token Is UoToken.UoKeyword_switch Then
        Call ScanSwitchForDoubles(i, TokenList, Doubles)
      ElseIf TypeOf token Is UoToken.UoKeyword_case Then
        NextTokenIsCaseValue = True
      ElseIf TypeOf token Is UoToken.UoPunctuator_OpenBrace Then
        BraceCounter += 1
      ElseIf TypeOf token Is UoToken.UoPunctuator_CloseBrace Then
        BraceCounter -= 1
        If BraceCounter < 0 Then
          ' Should not happen!
          Exit For
        ElseIf BraceCounter = 0 Then
          ' Switch statement ended
          Exit For
        End If
      End If
    Next
  End Sub
End Class
