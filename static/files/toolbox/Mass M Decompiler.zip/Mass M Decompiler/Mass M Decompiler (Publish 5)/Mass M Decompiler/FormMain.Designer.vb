﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Button_SelectScriptDirectory = New System.Windows.Forms.Button()
    Me.Button_ScanAndDecompileAll = New System.Windows.Forms.Button()
    Me.TextBox_ScriptDirectory = New System.Windows.Forms.TextBox()
    Me.ListBox_ScriptList = New System.Windows.Forms.ListBox()
    Me.TextBox1 = New System.Windows.Forms.TextBox()
    Me.TextBox2 = New System.Windows.Forms.TextBox()
    Me.Timer_Exit = New System.Windows.Forms.Timer(Me.components)
    Me.Button_DumpAll = New System.Windows.Forms.Button()
    Me.ComboBox_TargetLanguages = New System.Windows.Forms.ComboBox()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(11, 14)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(79, 13)
    Me.Label1.TabIndex = 13
    Me.Label1.Text = "Script Directory"
    '
    'Button_SelectScriptDirectory
    '
    Me.Button_SelectScriptDirectory.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.Button_SelectScriptDirectory.Location = New System.Drawing.Point(766, 14)
    Me.Button_SelectScriptDirectory.Name = "Button_SelectScriptDirectory"
    Me.Button_SelectScriptDirectory.Size = New System.Drawing.Size(42, 19)
    Me.Button_SelectScriptDirectory.TabIndex = 15
    Me.Button_SelectScriptDirectory.Text = "..."
    Me.Button_SelectScriptDirectory.TextAlign = System.Drawing.ContentAlignment.BottomCenter
    Me.Button_SelectScriptDirectory.UseCompatibleTextRendering = True
    Me.Button_SelectScriptDirectory.UseVisualStyleBackColor = True
    '
    'Button_ScanAndDecompileAll
    '
    Me.Button_ScanAndDecompileAll.Location = New System.Drawing.Point(11, 39)
    Me.Button_ScanAndDecompileAll.Name = "Button_ScanAndDecompileAll"
    Me.Button_ScanAndDecompileAll.Size = New System.Drawing.Size(116, 23)
    Me.Button_ScanAndDecompileAll.TabIndex = 14
    Me.Button_ScanAndDecompileAll.Text = "Mass Decompile"
    Me.Button_ScanAndDecompileAll.UseVisualStyleBackColor = True
    '
    'TextBox_ScriptDirectory
    '
    Me.TextBox_ScriptDirectory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TextBox_ScriptDirectory.Location = New System.Drawing.Point(96, 12)
    Me.TextBox_ScriptDirectory.Name = "TextBox_ScriptDirectory"
    Me.TextBox_ScriptDirectory.Size = New System.Drawing.Size(664, 20)
    Me.TextBox_ScriptDirectory.TabIndex = 12
    '
    'ListBox_ScriptList
    '
    Me.ListBox_ScriptList.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.ListBox_ScriptList.FormattingEnabled = True
    Me.ListBox_ScriptList.IntegralHeight = False
    Me.ListBox_ScriptList.Location = New System.Drawing.Point(10, 91)
    Me.ListBox_ScriptList.Name = "ListBox_ScriptList"
    Me.ListBox_ScriptList.Size = New System.Drawing.Size(117, 389)
    Me.ListBox_ScriptList.TabIndex = 11
    '
    'TextBox1
    '
    Me.TextBox1.AcceptsReturn = True
    Me.TextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.TextBox1.Location = New System.Drawing.Point(133, 41)
    Me.TextBox1.Multiline = True
    Me.TextBox1.Name = "TextBox1"
    Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
    Me.TextBox1.Size = New System.Drawing.Size(308, 472)
    Me.TextBox1.TabIndex = 16
    '
    'TextBox2
    '
    Me.TextBox2.AcceptsReturn = True
    Me.TextBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TextBox2.Location = New System.Drawing.Point(447, 41)
    Me.TextBox2.Multiline = True
    Me.TextBox2.Name = "TextBox2"
    Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
    Me.TextBox2.Size = New System.Drawing.Size(361, 472)
    Me.TextBox2.TabIndex = 17
    '
    'Timer_Exit
    '
    '
    'Button_DumpAll
    '
    Me.Button_DumpAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
    Me.Button_DumpAll.Location = New System.Drawing.Point(10, 490)
    Me.Button_DumpAll.Name = "Button_DumpAll"
    Me.Button_DumpAll.Size = New System.Drawing.Size(117, 23)
    Me.Button_DumpAll.TabIndex = 18
    Me.Button_DumpAll.Text = "Dump All"
    Me.Button_DumpAll.UseVisualStyleBackColor = True
    '
    'ComboBox_TargetLanguages
    '
    Me.ComboBox_TargetLanguages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.ComboBox_TargetLanguages.FormattingEnabled = True
    Me.ComboBox_TargetLanguages.Location = New System.Drawing.Point(12, 66)
    Me.ComboBox_TargetLanguages.Name = "ComboBox_TargetLanguages"
    Me.ComboBox_TargetLanguages.Size = New System.Drawing.Size(114, 21)
    Me.ComboBox_TargetLanguages.TabIndex = 19
    '
    'FormMain
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(820, 525)
    Me.Controls.Add(Me.ComboBox_TargetLanguages)
    Me.Controls.Add(Me.Button_DumpAll)
    Me.Controls.Add(Me.TextBox2)
    Me.Controls.Add(Me.TextBox1)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.Button_SelectScriptDirectory)
    Me.Controls.Add(Me.Button_ScanAndDecompileAll)
    Me.Controls.Add(Me.TextBox_ScriptDirectory)
    Me.Controls.Add(Me.ListBox_ScriptList)
    Me.Name = "FormMain"
    Me.Text = "Mass M Decompiler"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents Button_SelectScriptDirectory As System.Windows.Forms.Button
  Friend WithEvents Button_ScanAndDecompileAll As System.Windows.Forms.Button
  Friend WithEvents TextBox_ScriptDirectory As System.Windows.Forms.TextBox
  Friend WithEvents ListBox_ScriptList As System.Windows.Forms.ListBox
  Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
  Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
  Friend WithEvents Timer_Exit As System.Windows.Forms.Timer
  Friend WithEvents Button_DumpAll As System.Windows.Forms.Button
  Friend WithEvents ComboBox_TargetLanguages As System.Windows.Forms.ComboBox

End Class
