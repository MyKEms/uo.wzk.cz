﻿Imports JoinUO.WombatSDK

Public Class Dynamic0
  Inherits MUL.File

  Public Sub New(ByVal MULpath As String, ByVal IDXpath As String)
    MyBase.New(MULpath, IDXpath)
  End Sub

  Public Overrides ReadOnly Property HasHeader As Boolean
    Get
      Return False
    End Get
  End Property

  Public Overrides ReadOnly Property ItemSizeSource As MUL.ItemSizeSource
    Get
      Return MUL.ItemSizeSource.Item
    End Get
  End Property
End Class
