﻿Imports JoinUO.UOdemoSDK.Events
Imports JoinUO.UOdemoSDK.Obfuscator

Public Class FormMain
  Private Shared tmpEncoder As New System.Text.ASCIIEncoding
  Private Shared SDBtxt As New List(Of String)

  Private GenerateRealC As Boolean = False ' used by the M decompiler
  Private ExitState As Integer = 0 ' 0 = running, 1 = exit requested, 2 = exit approved, 3 = exiting

  Private Class LISTBOXITEM_SCRIPT
    Public ScriptPath As String
    Private ScriptName As String

    Private _UserListing As String
    ReadOnly Property UserListing() As String
      Get
        Return _UserListing
      End Get
    End Property

    Private _BinaryListing As String
    ReadOnly Property BinaryListing() As String
      Get
        Return _BinaryListing
      End Get
    End Property

    Private _RawListing As String
    Property RawListing() As String
      Get
        Return _RawListing
      End Get
      Set(ByVal _RawListing As String)
        Me._RawListing = _RawListing
        Call SplitRawListing(_BinaryListing, _UserListing)
      End Set
    End Property

    Public Sub New(ByVal _ScriptPath As String, Optional ByVal _RawListing As String = "")
      ' Set the path & contents
      Me.ScriptPath = _ScriptPath
      Me._RawListing = _RawListing

      '
      SplitRawListing(_BinaryListing, _UserListing)

      ' Remove .Q
      If Microsoft.VisualBasic.Right(_ScriptPath, 2).ToLowerInvariant = ".q" Then
        _ScriptPath = _ScriptPath.Substring(0, _ScriptPath.Length - 2)
      End If

      ' Set the name
      ScriptName = IO.Path.GetFileNameWithoutExtension(_ScriptPath)
    End Sub

    Private Sub SplitRawListing(ByRef _BinaryListing As String, ByRef _UserListing As String)
      ' Variables used to determine how to modify the output depending on the keyword
      Dim generate_realc As Boolean = False, last_wastype As String = ""
      Dim lastline_wasinclude As Boolean = False, lastline_wasfor As Boolean = False, lastline_wascase As Boolean = False, lastline_wason As Boolean = False, lastline_wasquoted As Boolean = False
      Dim depth As Integer = 0, lastline_wasnewline As Boolean = True, stringon As String = Nothing

      Dim line_atleastonelist As Boolean = False, line_islistassignment = False
      Dim listvars As New Specialized.StringCollection

      '
      Const adddefault1000 As Boolean = False

      ' Begin
      _BinaryListing = ""
      _UserListing = ""
      For Each line As String In _RawListing.Split(vbNewLine)
        ' Split the output
        Dim Output() As String = line.Split("§")
        If Output.Count > 1 Then
          ' Ident the text, but don't ident the "}", "case" and "default" keywords
          If lastline_wasnewline AndAlso Output(1) <> "}" AndAlso Output(1) <> "case" AndAlso Output(1) <> "default" Then
            lastline_wasnewline = False
            _UserListing &= Space(depth * 2)
          End If
          Dim newlast_wastype As String = ""

          Select Case Output(1)
            Case "Real-C", "UO-C"
              _UserListing &= "// " & Output("1") & vbNewLine
              If Output(1) = "Real-C" Then
                generate_realc = True
                _UserListing &= "#include ""ENGINE.h""" & vbNewLine & vbNewLine
              End If
              lastline_wasnewline = True
            Case "#include"
              lastline_wasinclude = True
              If generate_realc Then
                _UserListing &= "#include """
              Else
                _UserListing &= "include "
              End If
            Case "#on"
              lastline_wason = True
              If generate_realc Then
                _UserListing &= "ONEVENT( "
              Else
                _UserListing &= "on "
              End If
            Case "#function", "#scriptvar", "#extern"
              If generate_realc Then
                If Output(1) = "#scriptvar" Then
                  _UserListing &= "/* !!! scriptvar !!! */ "
                End If
              Else
                _UserListing &= Output("1").Substring(1) & " "
              End If
            Case "for"
              lastline_wasfor = True
              _UserListing &= Output(1)
            Case ";"
              If line_atleastonelist Then
                line_atleastonelist = False
                If line_islistassignment Then
                  line_islistassignment = False
                  _UserListing &= ")"
                End If
              End If
              If lastline_wasfor Then
                _UserListing &= "; "
              Else
                lastline_wasfor = False
                If lastline_wasinclude Then
                  lastline_wasinclude = False
                  If generate_realc Then
                    _UserListing &= ".h""" & vbNewLine & vbNewLine
                  Else
                    _UserListing &= ";" & vbNewLine & vbNewLine
                  End If
                  lastline_wasnewline = True
                Else
                  lastline_wasnewline = True
                  _UserListing &= ";" & vbNewLine
                End If
              End If
            Case "{"
              If line_atleastonelist Then
                line_atleastonelist = False

                ' NOTE: should not occur
                If line_islistassignment Then
                  line_islistassignment = False
                  _UserListing &= ")"
                End If
              End If
              If lastline_wason Then
                lastline_wason = False

                If generate_realc Then
                  _UserListing &= " )"
                End If

                Dim EventCode As Integer = 0
                Do While EventCode < SupportedEvents.Length
                  If SupportedEvents(EventCode).Name = stringon Then
                    Exit Do
                  End If
                  EventCode += 1
                Loop
                stringon = Nothing

                Select Case EventCode
                  Case 0
                    _UserListing &= "(object speaker, string arg)"
                  Case 1, 2, 40, 42
                    _UserListing &= "(object attacker)"
                  Case 3, 6, 11, 12, 13, 52, 16, 17
                    _UserListing &= "(object target)"
                  Case 4
                    _UserListing &= "(object attacker, object corpse)"
                  Case 5
                    _UserListing &= "(object attacker, object victim, object corpse)"
                  Case 7
                    _UserListing &= "(object attacker, integer damamt)"
                  Case 22
                    _UserListing &= "(object sender, list args)"
                    listvars.Add("args")
                  Case 23, 51
                    _UserListing &= "(object user)"
                  Case 24, 56
                    _UserListing &= "(object user, object usedon)"
                  Case 25
                    _UserListing &= "(object user, location place, integer objtype)"
                  Case 27
                    _UserListing &= "(object dropper)"
                  Case 28
                    _UserListing &= "(object looker)"
                  Case 29
                    _UserListing &= "(object giver, object givenobj)"
                  Case 30
                    _UserListing &= "(object getter)"
                  Case 34
                    _UserListing &= "(object victim, integer damamt)"
                  Case 35
                    _UserListing &= "(object talker, string arg)"
                  Case 36
                    _UserListing &= "(object user, integer listindex, integer objtype, integer objhue)"
                  Case 37
                    _UserListing &= "(object user, integer objhue)"
                  Case 38
                    _UserListing &= "(integer trammelchange, integer feluccachange)"
                  Case 39, 41
                    _UserListing &= "(object defender)"
                  Case 44
                    _UserListing &= "(object equippedon)"
                  Case 45
                    _UserListing &= "(object unequippedfrom)"
                  Case 46, 47
                    _UserListing &= "(object stackon)"
                  Case 48
                    _UserListing &= "(integer oldtype, integer newtype)"
                  Case 49
                    _UserListing &= "(integer oldvalue, integer newvalue)"
                  Case 55
                    _UserListing &= "(object user, integer closeId, list selectList, list entryList)"
                    listvars.Add("selectList")
                    listvars.Add("entryList")
                  Case 57
                    _UserListing &= "(object killer, object killee)"
                  Case 58
                    _UserListing &= "(object sender, integer button, string text)"
                  Case 59
                    _UserListing &= "(integer func)"
                  Case 60
                    _UserListing &= "(object stealer)"
                  Case 61
                    _UserListing &= "(object user, object usedon)"
                  Case 64, 65
                    _UserListing &= "(object target, integer transok)"
                  Case 66
                    _UserListing &= "(object buyer, object seller, integer quantity)"
                  Case 67
                    _UserListing &= "(object victim, integer damage)"
                  Case Else
                    If EventCode < SupportedEvents.Length Then
                      _UserListing &= "()"
                    Else
                      _UserListing &= "?"
                    End If
                End Select
              End If
              lastline_wasfor = False
              lastline_wasnewline = True
              _UserListing &= vbNewLine & Space(depth * 2) & "{" & vbNewLine
              depth += 1
            Case "}"
              lastline_wasnewline = True
              depth -= 1
              _UserListing &= Space(depth * 2) & "}" & vbNewLine
              If depth = 0 Then
                _UserListing &= vbNewLine
              End If
            Case "case"
              lastline_wascase = True
              lastline_wasnewline = False
              _UserListing &= Space(depth * 2 - 2) & "case "
            Case "default"
              lastline_wasnewline = True
              _UserListing &= Space(depth * 2 - 2) & "default:" & vbNewLine
            Case "integer", "string", "ust", "location", "object", "list", "void"
              newlast_wastype = Output(1)
              _UserListing &= Output(1)
            Case ","
              _UserListing &= ", "
            Case "("
              If lastline_wason Then
                If generate_realc Then
                  _UserListing &= " , "
                Else
                  _UserListing &= "<"
                End If
              Else
                _UserListing &= "("
              End If
            Case ")"
              If lastline_wason Then
                If generate_realc Then
                Else
                  _UserListing &= ">"
                End If
              Else
                _UserListing &= ")"
              End If
            Case "++", "--"
              _UserListing &= " " & Output(1)
            Case "+", "-", "*", "/", "&&", "||", "^", "!=", "==", "<", ">", "<=", ">=", "="
              _UserListing &= " " & Output(1) & " "
              If generate_realc Then
                If Output(1) = "=" Then
                  If line_atleastonelist Then
                    ' If line_islistassignment is true something went wrong!
                    If line_islistassignment Then
                      line_islistassignment = False
                    End If

                    '
                    line_islistassignment = True
                    _UserListing &= "MAKELIST("
                  End If
                End If
              End If
            Case Else
              ' Fix the output for #on
              If lastline_wason AndAlso stringon Is Nothing Then
                If Microsoft.VisualBasic.Left(Output(1), 2) = "0x" Then
                  If generate_realc Then
                    Output(1) = Integer.Parse(Output(1).Substring(2), Globalization.NumberStyles.AllowHexSpecifier) & " , "
                  Else
                    Output(1) = "<" & Integer.Parse(Output(1).Substring(2), Globalization.NumberStyles.AllowHexSpecifier) & ">"
                  End If
                Else
                  stringon = Output(1)
                  If adddefault1000 Then
                    If generate_realc Then
                      Output(1) = "1000 , " & Output(1)
                    Else
                      Output(1) = "<1000>" & Output(1)
                    End If
                  End If
                End If
              End If

              ' Add a "+" to indicate the combining of quoted strings
              If lastline_wasquoted AndAlso Output(1)(0) = """" Then
                _UserListing &= " + "
              End If

              ' Add a space after a type identifier and indicate line is list if needed
              If last_wastype <> "" Then
                If last_wastype = "list" Then
                  listvars.Add(Output(1))
                End If
                _UserListing &= " "
              End If

              ' Does the line contain atleast one list variable?
              If listvars.Contains(Output(1)) Then
                line_atleastonelist = True
              End If

              '
              _UserListing &= Output(1)
              If lastline_wascase Then
                lastline_wascase = False
                lastline_wasnewline = True
                _UserListing &= ":" & vbNewLine
              End If
          End Select

          ' Was the last keyword a type identifier?
          last_wastype = newlast_wastype

          ' Indicate wether or not the previous keyword was a quoted string
          lastline_wasquoted = Output(1)(0) = """"
        End If

        ' Add to the the binary output
        If Output.Count > 0 Then
          _BinaryListing &= Output(0) & vbNewLine
        End If
      Next
    End Sub

    Public Overrides Function ToString() As String
      Return ScriptName
    End Function
  End Class

  Private Sub FormMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    '
    If e.CloseReason <> CloseReason.ApplicationExitCall Then
      If Not Me.Button_ScanAndDecompileAll.Enabled Then
        ' If the interface is not active then we must use the thread to request an exit!
        ' NOTE: the interface is not active when the scan and decompile thread is doing its job
        e.Cancel = True
        Timer_Exit.Enabled = True
      End If
    End If
  End Sub

  Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Get the last scanned script directory
    Dim ScriptDirectory As String
    Try
      ScriptDirectory = GetSetting("Mass M Decompiler", "Main", "ScriptDirectory").Trim
    Catch
      ScriptDirectory = ""
    End Try

    ' NOTE: if not set try to get the setting from the "normal" M Decompiler
    If ScriptDirectory = "" Then
      Try
        ScriptDirectory = GetSetting("M Decompiler", "Main", "ScriptDirectory").Trim
      Catch
      End Try
    End If

    ' NOTE: if not set try to get the setting from the "normal" M Decompiler
    If ScriptDirectory = "" Then
      Try
        ScriptDirectory = GetSetting("M Compiler", "Main", "ScriptDirectory").Trim
      Catch
      End Try
    End If

    ' Get the pseudo-C generation flag
    Dim sGenerateRealC As String
    Try
      sGenerateRealC = GetSetting("Mass M Decompiler", "Main", "GenerateRealC").Trim.ToLowerInvariant
    Catch
      sGenerateRealC = ""
    End Try
    If sGenerateRealC = "" Then
      Me.CheckBox_GenerateRealC.Checked = GenerateRealC ' Use the default flag
    ElseIf sGenerateRealC = "yes" Then
      Me.CheckBox_GenerateRealC.Checked = True
    Else
      Me.CheckBox_GenerateRealC.Checked = False
    End If

    If ScriptDirectory <> "" Then
      ' Set the script directory
      Me.TextBox_ScriptDirectory.Text = ScriptDirectory
    End If
  End Sub

  Private Sub Button_ScanAndDecompileAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ScanAndDecompileAll.Click
    ' Disable the interface during the scan
    Me.TextBox_ScriptDirectory.Enabled = False
    Me.CheckBox_GenerateRealC.Enabled = False
    Me.Button_ScanAndDecompileAll.Enabled = False

    ' Clear the list with scripts
    Me.ListBox1.SelectedItems.Clear()
    Me.ListBox1.Items.Clear()

    Try
      ' Get the script directory to scan
      Dim ScriptDirectory As String = Me.TextBox_ScriptDirectory.Text.Trim

      ' Get the real C generation flag
      GenerateRealC = Me.CheckBox_GenerateRealC.Checked

      ' Determine the SDB file
      Dim SDBPath As String = IO.Path.Combine(ScriptDirectory, "sdb.txt")
      If Not IO.File.Exists(SDBPath) Then
        SDBPath &= ".q"
        If Not IO.File.Exists(SDBPath) Then
          SDBPath = Nothing
        End If
      End If
      If SDBPath Is Nothing Then
        Throw New Exception("Unable to locate SDB.TXT in the script directory!")
      End If

      ' Read the SDB file
      SDBtxt.Clear()
      Dim StreamSDB As New IO.FileStream(SDBPath, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

      ' Read
      Dim Reader As New IO.StreamReader(StreamSDB, tmpEncoder, False)
      Do While Not Reader.EndOfStream
        SDBtxt.Add(Reader.ReadLine)
      Loop

      StreamSDB.Close()

      ' The SDB was valid, so save the directory
      Try
        SaveSetting("Mass M Decompiler", "Main", "ScriptDirectory", ScriptDirectory)
      Catch
      End Try

      ' Save the real C generation flag
      Try
        SaveSetting("Mass M Decompiler", "Main", "GenerateRealC", IIf(GenerateRealC, "yes", "no"))
      Catch
      End Try

      ' Start the scan thread 
      Dim thread As New Threading.Thread(AddressOf ScanAndDecompileAll)
      thread.Start(ScriptDirectory)
    Catch ex As Exception
      MsgBox(ex.Message)

      ' Enable the interface on error
      Me.TextBox_ScriptDirectory.Enabled = True
      Me.CheckBox_GenerateRealC.Enabled = True
      Me.Button_ScanAndDecompileAll.Enabled = True
    End Try
  End Sub

  Private Sub ScanAndDecompileAll(ByVal ScriptDirectory As String)
    '
    Dim RootTitle As String = Me.Text

    Try
      ' Get all *.M files and all *.M.Q files
      For Each FilePath As String In My.Computer.FileSystem.GetFiles(ScriptDirectory, FileIO.SearchOption.SearchTopLevelOnly, New String() {"*.M", "*.M.Q"})
        Dim LBIS As New LISTBOXITEM_SCRIPT(FilePath)

        ' Add to the list
        Call AddScript(LBIS, RootTitle)

        ' Do the actual decompile
        Try
          LBIS.RawListing = DecompileM(LBIS.ToString, LBIS.ScriptPath)
        Catch ex As Exception
          LBIS.RawListing = ex.Message
        End Try

        ' Abort the loop if the user requested an exit
        If ExitState > 0 Then
          Exit For
        End If
      Next
    Catch
    End Try

    '
    Call AddScript(Nothing, RootTitle)
  End Sub

  Private Delegate Sub Delegate_AddScript(ByRef LBIS As LISTBOXITEM_SCRIPT, ByVal RootTitle As String)
  Private Sub AddScript(ByRef LBIS As LISTBOXITEM_SCRIPT, ByVal RootTitle As String)
    If Me.InvokeRequired Then
      Me.Invoke(New Delegate_AddScript(AddressOf AddScript), LBIS, RootTitle)
    Else
      If LBIS Is Nothing Then
        ' Set the window title!
        Me.Text = RootTitle

        If ExitState = 0 Then
          ' Enable the interface again
          Me.TextBox_ScriptDirectory.Enabled = True
          Me.CheckBox_GenerateRealC.Enabled = True
          Me.Button_ScanAndDecompileAll.Enabled = True
        Else
          ' Indicate we are ready to quit
          ExitState = 2
        End If
      Else
        ' Add to the list and update the window title!
        Me.ListBox1.Items.Add(LBIS)
        Me.Text = RootTitle & " - " & IO.Path.GetFileName(LBIS.ScriptPath)
      End If
    End If
  End Sub

  Public Function DecompileM(ByVal ScriptName As String, ByVal FilePath As String) As String
    ' Open the file
    Dim File As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

    ' Return an empty decompiled string if the file length is zero
    If File.Length = 0 Then
      Return ""
    End If

    ' Read into a buffer
    Dim TempBuffer(File.Length) As Byte
    File.Read(TempBuffer, 0, File.Length)

    ' Add 0-Byte at the end of the buffer
    TempBuffer(File.Length) = 0

    ' Close the file
    File.Close()

    Return DecompileM(ScriptName, TempBuffer)
  End Function

  Public Function DecompileM(ByVal ScriptName As String, ByVal Contents() As Byte) As String
    Dim DecompiledData As String = ""

    If GenerateRealC Then
      DecompiledData = "#Real-C§Real-C" & vbNewLine
    Else
      DecompiledData = "#UO-C§UO-C" & vbNewLine
    End If

    ' Begin the loop
    Dim i As Integer = 0
    Do While i < Contents.Length
      ' Abort the loop if the user wants us to quit
      If ExitState > 0 Then
        Exit Do
      End If

      ' Exit the loop if we reached the end
      If Contents(i) = 0 Then
        DecompiledData &= "@$" & i.ToString("X4") & ":$00->DONE"
        Exit Do
      End If

      ' Get the encrypted script-word and convert it to an unencrypted script-byte
      Dim Encrypted As UInt16 = Contents(i + 1) * 256 + Contents(i)
      Dim ScriptByte As Byte = Deobfuscate(Encrypted)
      i += 2

      ' Binary output
      DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & Encrypted.ToString("X4") & "=$" & ScriptByte.ToString("X2") & "->"

      ' Convert the script-byte to a keyword/token as we know it from the C language
      Select Case ScriptByte
        Case &H2
          DecompiledData &= "'('§("
        Case &H3
          DecompiledData &= "')'§)"
        Case &H4
          DecompiledData &= "','§,"
        Case &H6
          DecompiledData &= "';'§;"
        Case &H7
          DecompiledData &= "'{'§{"
        Case &H8
          DecompiledData &= "'}'§}"
        Case &H9
          DecompiledData &= "'['§["
        Case &HA
          DecompiledData &= "']'§]"
        Case &HB
          DecompiledData &= "'!'§!"
        Case &HC
          DecompiledData &= "'+'§+"
        Case &HD
          DecompiledData &= "'-'§-"
        Case &HE
          DecompiledData &= "'*'§*"
        Case &HF
          DecompiledData &= "'/'§/"
        Case &H10
          DecompiledData &= "'%'§%"
        Case &H11
          DecompiledData &= "'=='§=="
        Case &H12
          DecompiledData &= "'!='§!="
        Case &H13
          DecompiledData &= "'<'§<"
        Case &H14
          DecompiledData &= "'>'§>"
        Case &H15
          DecompiledData &= "'<='§<="
        Case &H16
          DecompiledData &= "'>='§>="
        Case &H17
          DecompiledData &= "'='§="
        Case &H18
          DecompiledData &= "'&&'§&&"
        Case &H19
          DecompiledData &= "'||'§||"
        Case &H1A
          DecompiledData &= "'^'§^" ' is unused!!!
        Case &H1B
          DecompiledData &= "'++'§++"
        Case &H1C
          DecompiledData &= "'--'§--"
        Case &H1D
          DecompiledData &= "VARIABLE-TYPE=integer§integer"
        Case &H1E
          DecompiledData &= "VARIABLE-TYPE=string§string"
        Case &H1F
          DecompiledData &= "VARIABLE-TYPE=q->ust=?§ust" ' TODO: What is 'q' aka "ust" ? 
        Case &H20
          DecompiledData &= "VARIABLE-TYPE=location§location"
        Case &H21
          DecompiledData &= "VARIABLE-TYPE=object§object"
        Case &H22
          DecompiledData &= "VARIABLE-TYPE=list§list"
        Case &H23
          DecompiledData &= "VARIABLE-TYPE=void§void"
        Case &H25
          DecompiledData &= "IF§if"
        Case &H26
          DecompiledData &= "ELSE§else"
        Case &H27
          DecompiledData &= "ENDIF§" ' is unused!!!!
        Case &H28
          DecompiledData &= "WHILE§while"
        Case &H29
          DecompiledData &= "WEND§" ' is unused!!!!
        Case &H2A
          DecompiledData &= "FOR§for"
        Case &H2B
          DecompiledData &= "NEXT§" ' is unused!!!!
        Case &H2C
          DecompiledData &= "CONTINUE§continue"
        Case &H2D
          DecompiledData &= "BREAK§break"
        Case &H2E
          DecompiledData &= "GOTO§goto" ' is unused!!!!
        Case &H2F
          DecompiledData &= "DO SELECT§switch"
        Case &H30
          DecompiledData &= "END SELECT" ' is unused!!!!
        Case &H31
          DecompiledData &= "CASE§case"
        Case &H32
          DecompiledData &= "CASE ELSE§default"
        Case &H33
          DecompiledData &= "RETURN§return"
        Case &H34
          DecompiledData &= "DEFINE-FUNCTION§#function"
        Case &H35
          DecompiledData &= "DEFINE-HANDLER§#on"
        Case &H36
          DecompiledData &= "DECLARE-VARIABLE§#scriptvar"
        Case &H37
          DecompiledData &= "INCLUDE§#include"
        Case &H38
          DecompiledData &= "DECLARE-FUNCTION§#extern"
        Case &H3A
          Dim KeepLooping As Boolean
          Do
            KeepLooping = False
            DecompiledData &= "QUOTED-STRING" & vbNewLine

            ' Get the index into the SDB
            Dim iSDB As Integer = Contents(i + 1) * 256 + Contents(i)
            i = i + 2

            ' Output
            ' NOTE: tutdragon contains a bug (invalid index to the SDB), try to fix this
            If ScriptName = "tutdragon" AndAlso iSDB = SDBtxt.Count Then
              Dim SDBfix As String = """""" & SDBtxt(iSDB - 1).Substring(1) & """"
              DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->TUTDRAGON-SDB-BUG->'" & SDBfix & "'§" & SDBfix
            Else
              DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->'" & SDBtxt(iSDB) & "'§" & SDBtxt(iSDB)
            End If

            ' Keep extracting quoted-strings?
            If IsObfuscated(Contents, i, &H3A) Then
              ' We must extract another quoted-string
              Encrypted = Contents(i + 1) * 256 + Contents(i)
              i = i + 2
              KeepLooping = True

              ' Output
              DecompiledData &= vbNewLine & "@$" & (i - 2).ToString("X4") & ":$" & Encrypted.ToString("X4") & "=$3A->"
            End If
          Loop While KeepLooping
        Case &H3C
          DecompiledData &= "BYTE" & vbNewLine

          ' Get the constant
          Dim b As Byte = Contents(i)
          i += 1

          ' Output
          DecompiledData &= "@" & (i - 1).ToString("X4") & ":" & b.ToString("X2") & "->" & b.ToString & "§0x" & b.ToString("X2")
        Case &H3D
          DecompiledData &= "DOUBLEBYTE" & vbNewLine

          ' Get the constant
          Dim w As UInt16 = Contents(i + 1) * 256 + Contents(i)
          i += 2

          ' Output
          DecompiledData &= "@" & (i - 2).ToString("X4") & ":" & w.ToString("X4") & "->$" & w.ToString & "§0x" & w.ToString("X4")
        Case &H3E
          DecompiledData &= "QUADBYTE" & vbNewLine

          ' Get the constant
          Dim q As UInt32 = CType(Contents(i + 3), UInt32) * 256 * 256 * 256 + Contents(i + 2) * 256 * 256 + Contents(i + 1) * 256 + Contents(i)
          i += 4

          ' Output
          DecompiledData &= "@" & (i - 4).ToString("X4") & ":" & q.ToString("X8") & "->$" & q.ToString & "§0x" & q.ToString("X8")
        Case &H41
          DecompiledData &= "STRING" & vbNewLine

          ' Get the index into the SDB
          Dim iSDB As Integer = Contents(i + 1) * 256 + Contents(i)
          i += 2

          ' Output
          DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->'" & SDBtxt(iSDB) & "'§" & SDBtxt(iSDB)
        Case Else
          DecompiledData &= "UNKNOWN?"
      End Select

      DecompiledData &= vbNewLine
    Loop

    Return DecompiledData
  End Function

  Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
    If Me.ListBox1.SelectedItems.Count = 0 Then
      Me.TextBox1.Text = ""
      Me.TextBox2.Text = ""
    Else
      Dim LBIS As LISTBOXITEM_SCRIPT = Me.ListBox1.SelectedItems(0)
      Me.TextBox1.Text = LBIS.BinaryListing
      Me.TextBox2.Text = LBIS.UserListing
    End If
  End Sub

  Private Sub Timer_Exit_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_Exit.Tick
    ' Indicate to the thread we want to exit
    If ExitState = 0 Then
      ExitState = 1
    End If

    ' If the thread told us it has exited then go quit
    If ExitState = 2 Then
      ExitState = 3

      '
      Me.Timer_Exit.Enabled = False
      Application.Exit()
    End If
  End Sub

  Private Sub Button_DumpAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DumpAll.Click
    Dim ScriptDirectory As String
    Try
      ScriptDirectory = GetSetting("Mass M Decompiler", "Main", "ScriptDirectory").Trim
    Catch
      ScriptDirectory = ""
    End Try

    If IO.Directory.Exists(ScriptDirectory) Then
      ' Ensure that our directory for the C scripts exists
      Dim OutputDirectory As String = IO.Path.GetFullPath(IO.Path.Combine(ScriptDirectory, "..\scripts.c"))
      If Not IO.Directory.Exists(OutputDirectory) Then
        IO.Directory.CreateDirectory(OutputDirectory)
      End If

      ' For each decompiled script, write the user listing to disk
      For Each LBI As LISTBOXITEM_SCRIPT In ListBox1.Items
        Dim name As String = LBI.ToString
        Dim Listing As String = LBI.UserListing
        Dim fs As New IO.FileStream(IO.Path.Combine(OutputDirectory, name & ".m.C"), IO.FileMode.Create)
        Dim sw As New IO.StreamWriter(fs)
        sw.Write(Listing)
        sw.Close()
        fs.Close()
      Next
    End If
  End Sub

  Private Sub Button_SelectScriptDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SelectScriptDirectory.Click
    Try
      ' Use a Select Directory Dialog to get a new directory
      Dim GetFolder As New FolderBrowserDialog
      GetFolder.ShowNewFolderButton = False
      GetFolder.SelectedPath = Me.TextBox_ScriptDirectory.Text.Trim
      If GetFolder.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Me.TextBox_ScriptDirectory.Text = GetFolder.SelectedPath
      End If
    Catch ex As Exception
      ' Error!
      MsgBox(ex.Message)
    End Try
  End Sub
End Class
