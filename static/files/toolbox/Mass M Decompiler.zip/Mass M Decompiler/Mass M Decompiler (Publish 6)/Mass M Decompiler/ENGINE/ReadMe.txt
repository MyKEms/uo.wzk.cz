NOTE
====
These files are only used when you decompile as Real-C.
Don't expect to be able to compile the script using this header though.
It is only ment to satisfy a C++ IDE so you can cross-reference function usage.