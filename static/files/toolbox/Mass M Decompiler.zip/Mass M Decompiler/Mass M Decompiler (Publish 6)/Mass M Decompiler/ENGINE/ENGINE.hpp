#include "ENGINE-types.hpp"
#include "ENGINE-commands.h"

#error "FAILURE: this is ment to be used by the Ultima Online Gold Demo only!"

#define FORWARD
#define FUNCTION
#define MEMBER
#define TRIGGER(a) int onevent
#define TRIGGER(a, b) int onevent
#define TRIGGER(a, b, c) int onevent
#define list(...) NULL
#define loc(...) NULL
