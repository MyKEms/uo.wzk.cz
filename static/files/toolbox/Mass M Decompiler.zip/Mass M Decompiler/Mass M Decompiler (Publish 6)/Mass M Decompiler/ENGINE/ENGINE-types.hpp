#pragma once

typedef char *string;
typedef unsigned short *ustring;
struct {short x, y, z;} loc;
typedef void *obj;
typedef void *list;