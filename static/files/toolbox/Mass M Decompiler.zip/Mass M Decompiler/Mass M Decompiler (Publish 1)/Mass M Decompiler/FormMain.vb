﻿Public Class FormMain
  Private Shared SillyLookupTable() As UInt16 = {&H129, &H18BE, &H2CD6, &H26E9, &H1EB, &HBB3, &H2EA6, &H12DB, &H153C, &H7E87, &H390C, &HF3E, &H199, &H124, &H305E, &H39B3, &H2D12, &H26A6, &H5D03, &H1238, &H3B25, &H1E1F, &H1AD4, &H7F96, &H7FF5, &H323B, &H260D, &H30A, &H301C, &HBDB, &H732, &H120, &H5CFD, &H3E12, &H3BF6, &H3A9E, &HDDC, &H5E14, &H2E40, &H1CD0, &H7EB7, &H6032, &H2C3B, &H15A1, &H3EF6, &H409D, &H12E1, &H121F, &H26CA, &H3699, &H902, &H7BB9, &H139D, &H187E, &H16C5, &H3CD5, &H13E9, &H4080, &H5DB2, &H33EA, &H23C9, &H60BF, &H3CD6, &HFBF, &H2F14, &H47E, &H368E, &H2FFF, &H288F, &H7DD1, &H261E, &H5E9D, &H1916, &H32E6, &H401D, &H384, &H18D7, &HFC9, &HE12, &H2833, &H249E, &H2B0C, &H11F4, &H5DD5, &H127E, &H135, &H7CF, &H1AF4, &HECC, &H1D3, &HE90, &H3A2D, &H37E6, &H19D9, &H252A, &H37E5, &H1DC0, &H1481, &H4087, &H2B01, &H16D4, &H3A8D, &H7FBE, &HC7B, &HC15, &H3807, &H633, &H251F, &H1D18, &H3492, &H19DA, &H39CE, &H3BB1, &H3004, &H1796, &H1F16, &H182F, &H2CF7, &H5ED0, &H1316, &H5D24, &H588, &H7CFE, &H2725, &HDE5, &H13D3, &H29D8, &HA28, &H9CE, &H3960, &H263D, &H3B97, &H4027, &H138A, &H282D, &H5CCD, &H940, &H293B, &H40A5, &H1D11, &H2528, &HEA9, &H3F0B, &H3087, &H3F97, &H30F1, &H3295, &H1C1, &HCE1, &H3EE9, &H3F9A, &H30A7, &H2DB5, &H169A, &H2FE7, &H10D9, &H390, &H2A38, &H728, &H5C5E, &H1E1, &H1030, &H1BD9, &H159F, &H2BA5, &H28E2, &H2F0C, &H1289, &H3382, &H36C2, &H26B1, &H1CDF, &H27DA, &HE29, &H113E, &H2E39, &H1D3F, &H1D5E, &H1FF1, &H7E0E, &H6E3, &H36A1, &HC1E, &H2120, &H1DCB, &H12C2, &H1003, &H607, &H784, &H2B0F, &H3305, &H32E7, &H212C, &H18E, &H3308, &H1EDC, &H20A8, &H37BE, &H1EB, &H123B, &H3106, &H18C, &H357E, &HA87, &H5D2B, &H3FA, &HAF0, &H786, &H2332, &H1295, &H7DAA, &H2F0B, &H1BFC, &H13F5, &H1ECA, &HD9F, &H388A, &H15FD, &H7CB8, &H1AF6, &H17B, &H6014, &HE99, &H33CD, &H27D3, &H7F0D, &H4F0, &H183A, &H1FB4, &H13A6, &H190B, &H3605, &H20AD, &H32CF, &H2CD5, &H4B0, &H1927, &H8FF, &H31D8, &H914, &H13F4, &H3A27, &H387C, &H32C1, &H198C, &H3223, &H17B8, &H3895, &H248D, &H342D, &H5D3D, &H3260, &H32DE, &H2780, &H31AD, &H5DE9, &H5EA5, &H11D5, &H199F, &H2F15, &HE01, &H19FE, &H3821, &HB93, &HA2F, &H9B3, &H38F, &H328A, &H8AF, &H5CCA, &HC95, &H7CBE, &H7C27, &H5D2A, &H2FA1, &H31BE, &H15B4, &H7C9, &H27C0, &H1B32, &H2934, &H3E09, &H12C, &H2CC6, &H7FA6, &H6D8, &H3181, &H2738, &H3212, &H3F9, &H5D17, &HA1D, &H3B29, &H2BFA, &H2BB8, &H1DB5, &H2F95, &HEF5, &H5CDF, &H7B8B, &H17BD, &H21EB, &H2015, &H5DB8, &H15E1, &H5B60, &H3D8F, &HFF4, &H275B, &H3C8A, &H188F, &H5D27, &H7F5C, &H1F7, &H93B, &H2F84, &H1DC3, &H1DA7, &H1A30, &H2410, &H2EE, &H603, &H12F, &H2C9E, &H2BEF, &H3510, &HB9B, &H6E9, &H3B9E, &HB31, &H2581, &HDC7, &H36BF, &H15BD, &H11C, &H828, &HB7F, &H315D, &H13B9, &H634, &H260, &H7D3C, &H6DE, &H2B2, &H1F0D, &H322B, &H2EC, &H11B8, &H7DE2, &H1B7E, &H267D, &H2BD8, &H3D84, &HD1F, &H7E01, &H60BE, &H5B16, &H7FD6, &H2518, &H252B, &H5B2E, &H1F8B, &H3F0E, &H390E, &H7E94, &H1A31, &H40B5, &H3EA4, &H3990, &H2040, &H19FC, &H5D80, &H3921, &H7DB, &H7F7D, &H161E, &H2A8D, &H348C, &H36B8, &H1C5E, &H3FAF, &H40FA, &H37B0, &H194, &H301D, &H5DDC, &H5DF2, &H5E5B, &H3BA0, &H2E7F, &HE5C, &H3A36, &HDE9, &H502, &H8AC, &H151A, &H1B0B, &HEF7, &HF26, &H5DA3, &H2635, &H7FAD, &H1A2A, &H15D5, &H31B2, &H1732, &H190A, &H30DC, &H195D, &H5EB, &H13A, &H3693, &H3B0D, &H1E87, &HBDF, &H7A2, &H3ED5, &H60C6, &H20BC, &H198D, &H68F, &H314, &H5DA9, &H2718, &H328D, &H3DAE, &H6BB, &H60CA, &H1C20, &H13CF, &H75D, &H42F, &H37D7, &H7DA8, &H25CC, &H3D0D, &HA26, &HCED, &H2784, &H2FD9, &H5F8, &H1EB8, &H20D5, &H1AA0, &H1D5C, &H53C, &H1636, &H1785, &H2D8E, &H3981, &H17B0, &H5D85, &H7FE9, &H7C12, &H12C6, &H2FEC, &H15E2, &H7CA3, &H5EF3, &H5BB9, &H3F4, &H5E32, &H5C04, &H3002, &H41E, &H1F8, &H3590, &H140B, &H4037, &H6092, &H41C, &H1D37, &H7EF2, &H1D26, &H2F7E, &H2EF6, &H32ED, &H2997, &H19CA, &H1002, &H3908, &H363A, &H21C, &H11DF, &H361B, &H5EA6, &H292, &H1E5, &H2ABC, &H3B2B, &H318, &H7C0A, &H400E, &H21BE, &H3AE3, &H2D01, &H1DB, &H3CFF, &H33B2, &H311A, &H389, &H24F8, &H3105, &H7CB3, &H37FD, &H2A9E, &H3FD0, &H4FE, &H1DD4, &H9C9, &H3419, &H2714, &H3FD1, &HA3F, &H26F2, &H1BAD, &H23C0, &H2002, &H2694, &H5D12, &H1D94, &H3930, &H3AF, &H795, &H20E3, &HEDD, &H1DA1, &HA31, &H2B38, &H23CE, &H3ECA, &H34C5, &H3CE5, &H28B6, &H5C01, &H3C87, &H1684, &H1DA, &H1B3C, &H1F0E, &H3FD7, &H2F2, &H9B1, &H2D98, &H5B8F, &H1718, &H113F, &H2DEF, &H10DF, &H3BE, &H1739, &H1FE6, &H31B3, &H39B8, &H2404, &H7DB6, &H5D30, &H10E4, &H2D7B, &H3D3D, &H7DC4, &H1E2F, &H3DFF, &H29C9, &H2B13, &H2C90, &H15A9, &H2524, &H1C11, &H5EAD, &H83F, &H5AE, &H3DFD, &H2A9, &H1439, &H3635, &H2BE, &H381C, &H40CE, &H8BD, &H7DB3, &H40D3, &H917, &H2F0A, &H2B32, &H1EF6, &H250F, &H686, &H7F10, &H1613, &H8D2, &H1C2D, &H2684, &HAB6, &H21A2, &H1BD8, &H16D1, &HDAF, &H3A13, &H2ABA, &H2429, &H7FF4, &H18DD, &H1DA2, &H1E99, &H3412, &H3091, &H5D20, &H6C7, &H2E3D, &H7CEE, &H1CA0, &H19D0, &H2424, &H2D7F, &H253F, &H1C28, &HCC0, &HDA9, &H1BD, &H3EE4, &H2533, &H2706, &H1337, &H3283, &H7F20, &HD0C, &H34AF, &H383, &H2123, &H15A2, &H1831, &H618, &H3DDA, &H730, &H7B09, &HAE1, &H7B34, &H339A, &H34ED, &H243D, &H3602, &H19B6, &H350A, &H2B97, &H19F, &H327C, &H288C, &H27E0, &H3C0A, &H2F2A, &H359A, &H2B30, &H3594, &HAB5, &H1A9D, &HB2E, &H289C, &H2A98, &HA27, &H23EE, &H3833, &HDBD, &H21DE, &H1F1, &HDC3, &H7C0E, &H1C80, &H26BC, &H3D3E, &H27C2, &H350B, &H31CE, &H36B7, &H5CB1, &H5E11, &H2E08, &H3CCD, &H3528, &H181C, &H2BEB, &H27B8, &H13BF, &H2BB7, &H1A5C}
  Private Shared tmpEncoder As New System.Text.ASCIIEncoding
  Private Shared SDBtxt As New List(Of String)

  Private GenerateRealC As Boolean = False ' used by the M decompiler
  Private ExitState As Integer = 0 ' 0 = running, 1 = exit requested, 2 = exit approved, 3 = exiting

  Private Class Structure5EE45C
    Public Name As String
    Public IndexBase1 As Integer

    Public Sub New(ByVal _Name As String, ByVal _IndexBase1 As Integer)
      Name = _Name
      IndexBase1 = _IndexBase1
    End Sub
  End Class

  ' REFERENCE=005EE45C
  Private Shared Table5EE45C() As Structure5EE45C = _
  { _
    New Structure5EE45C("speech", &H1), _
    New Structure5EE45C("gotattacked", &H2), _
    New Structure5EE45C("killedtarget", &H3), _
    New Structure5EE45C("aversion", &H4), _
    New Structure5EE45C("death", &H5), _
    New Structure5EE45C("sawdeath", &H6), _
    New Structure5EE45C("fightpulse", &H7), _
    New Structure5EE45C("washit", &H8), _
    New Structure5EE45C("failfood", &H9), _
    New Structure5EE45C("faildesire", &HA), _
    New Structure5EE45C("failshelter", &HB), _
    New Structure5EE45C("foundfood", &HC), _
    New Structure5EE45C("founddesire", &HD), _
    New Structure5EE45C("foundshelter", &HE), _
    New Structure5EE45C("time", &HF), _
    New Structure5EE45C("creation", &H10), _
    New Structure5EE45C("enterrange", &H11), _
    New Structure5EE45C("leaverange", &H12), _
    New Structure5EE45C("loiter", &H13), _
    New Structure5EE45C("seekfood", &H14), _
    New Structure5EE45C("seekdesire", &H15), _
    New Structure5EE45C("seekshelter", &H16), _
    New Structure5EE45C("message", &H17), _
    New Structure5EE45C("use", &H18), _
    New Structure5EE45C("targetobj", &H19), _
    New Structure5EE45C("targetloc", &H1A), _
    New Structure5EE45C("weather", &H1B), _
    New Structure5EE45C("wasdropped", &H1C), _
    New Structure5EE45C("lookedat", &H1D), _
    New Structure5EE45C("give", &H1E), _
    New Structure5EE45C("wasgotten", &H1F), _
    New Structure5EE45C("pathfound", &H20), _
    New Structure5EE45C("pathnotfound", &H21), _
    New Structure5EE45C("callback", &H22), _
    New Structure5EE45C("ishitting", &H23), _
    New Structure5EE45C("convofunc", &H24), _
    New Structure5EE45C("typeselected", &H25), _
    New Structure5EE45C("hueselected", &H26), _
    New Structure5EE45C("moon", &H27), _
    New Structure5EE45C("minrangeattack", &H28), _
    New Structure5EE45C("minrangedefend", &H29), _
    New Structure5EE45C("maxrangeattack", &H2A), _
    New Structure5EE45C("maxrangedefend", &H2B), _
    New Structure5EE45C("destroyed", &H2C), _
    New Structure5EE45C("equip", &H2D), _
    New Structure5EE45C("unequip", &H2E), _
    New Structure5EE45C("isstackableon", &H2F), _
    New Structure5EE45C("stackonto", &H30), _
    New Structure5EE45C("multirecycle", &H31), _
    New Structure5EE45C("decay", &H32), _
    New Structure5EE45C("serverswitch", &H33), _
    New Structure5EE45C("ooruse", &H34), _
    New Structure5EE45C("acquiredesire", &H35), _
    New Structure5EE45C("logout", &H36), _
    New Structure5EE45C("objectloaded", &H37), _
    New Structure5EE45C("genericgump", &H38), _
    New Structure5EE45C("oortargetobj", &H39), _
    New Structure5EE45C("pkpost", &H3A), _
    New Structure5EE45C("textentry", &H3B), _
    New Structure5EE45C("shop", &H3C), _
    New Structure5EE45C("stolenfrom", &H3D), _
    New Structure5EE45C("objaccess", &H3E), _
    New Structure5EE45C("ishealthy", &H3F), _
    New Structure5EE45C("online", &H40), _
    New Structure5EE45C("transaccountcheck", &H41), _
    New Structure5EE45C("transresponse", &H42), _
    New Structure5EE45C("canbuy", &H43), _
    New Structure5EE45C("mobishitting", &H44), _
    New Structure5EE45C("famechanged", &H45), _
    New Structure5EE45C("karmachanged", &H46), _
    New Structure5EE45C("murdercountchanged", &H432230) _
  }

  Private Class LISTBOXITEM_SCRIPT
    Public ScriptPath As String
    Private ScriptName As String

    Private _UserListing As String
    ReadOnly Property UserListing() As String
      Get
        Return _UserListing
      End Get
    End Property

    Private _BinaryListing As String
    ReadOnly Property BinaryListing() As String
      Get
        Return _BinaryListing
      End Get
    End Property

    Private _RawListing As String
    Property RawListing() As String
      Get
        Return _RawListing
      End Get
      Set(ByVal _RawListing As String)
        Me._RawListing = _RawListing
        Call SplitRawListing(_BinaryListing, _UserListing)
      End Set
    End Property

    Public Sub New(ByVal _ScriptPath As String, Optional ByVal _RawListing As String = "")
      ' Set the path & contents
      Me.ScriptPath = _ScriptPath
      Me._RawListing = _RawListing

      '
      SplitRawListing(_BinaryListing, _UserListing)

      ' Remove .Q
      If Microsoft.VisualBasic.Right(_ScriptPath, 2).ToLowerInvariant = ".q" Then
        _ScriptPath = _ScriptPath.Substring(0, _ScriptPath.Length - 2)
      End If

      ' Set the name
      ScriptName = IO.Path.GetFileNameWithoutExtension(_ScriptPath)
    End Sub

    Private Sub SplitRawListing(ByRef _BinaryListing As String, ByRef _UserListing As String)
      ' Variables used to determine how to modify the output depending on the keyword
      Dim generate_realc As Boolean = False, last_wastype As String = ""
      Dim lastline_wasinclude As Boolean = False, lastline_wasfor As Boolean = False, lastline_wascase As Boolean = False, lastline_wason As Boolean = False, lastline_wasquoted As Boolean = False
      Dim depth As Integer = 0, lastline_wasnewline As Boolean = True, stringon As String = Nothing

      Dim line_atleastonelist As Boolean = False, line_islistassignment = False
      Dim listvars As New Specialized.StringCollection

      '
      Const adddefault1000 As Boolean = False

      ' Begin
      _BinaryListing = ""
      _UserListing = ""
      For Each line As String In _RawListing.Split(vbNewLine)
        ' Split the output
        Dim Output() As String = line.Split("§")
        If Output.Count > 1 Then
          ' Ident the text, but don't ident the "}", "case" and "default" keywords
          If lastline_wasnewline AndAlso Output(1) <> "}" AndAlso Output(1) <> "case" AndAlso Output(1) <> "default" Then
            lastline_wasnewline = False
            _UserListing &= Space(depth * 2)
          End If
          Dim newlast_wastype As String = ""

          Select Case Output(1)
            Case "Real-C", "UO-C"
              _UserListing &= "// " & Output("1") & vbNewLine
              If Output(1) = "Real-C" Then
                generate_realc = True
                _UserListing &= "#include ""ENGINE.h""" & vbNewLine & vbNewLine
              End If
              lastline_wasnewline = True
            Case "#include"
              lastline_wasinclude = True
              If generate_realc Then
                _UserListing &= "#include """
              Else
                _UserListing &= "include("
              End If
            Case "#on"
              lastline_wason = True
              If generate_realc Then
                _UserListing &= "ONEVENT( "
              Else
                _UserListing &= "on "
              End If
            Case "#function", "#scriptvar", "#extern"
              If generate_realc Then
                If Output(1) = "#scriptvar" Then
                  _UserListing &= "/* !!! scriptvar !!! */ "
                End If
              Else
                _UserListing &= Output("1").Substring(1) & " "
              End If
            Case "for"
              lastline_wasfor = True
              _UserListing &= Output(1)
            Case ";"
              If line_atleastonelist Then
                line_atleastonelist = False
                If line_islistassignment Then
                  line_islistassignment = False
                  _UserListing &= ")"
                End If
              End If
              If lastline_wasfor Then
                _UserListing &= "; "
              Else
                lastline_wasfor = False
                If lastline_wasinclude Then
                  lastline_wasinclude = False
                  If generate_realc Then
                    _UserListing &= ".h""" & vbNewLine & vbNewLine
                  Else
                    _UserListing &= ");" & vbNewLine & vbNewLine
                  End If
                  lastline_wasnewline = True
                Else
                  lastline_wasnewline = True
                  _UserListing &= ";" & vbNewLine
                End If
              End If
            Case "{"
              If line_atleastonelist Then
                line_atleastonelist = False

                ' NOTE: should not occur
                If line_islistassignment Then
                  line_islistassignment = False
                  _UserListing &= ")"
                End If
              End If
              If lastline_wason Then
                lastline_wason = False

                If generate_realc Then
                  _UserListing &= " )"
                End If

                Dim Index5EE45C As Integer = 0
                Do While Index5EE45C < Table5EE45C.Length
                  If Table5EE45C(Index5EE45C).Name = stringon Then
                    Exit Do
                  End If
                  Index5EE45C += 1
                Loop
                stringon = Nothing

                Select Case Index5EE45C
                  Case 0
                    _UserListing &= "(object speaker, string arg)"
                  Case 1, 2, 40, 42
                    _UserListing &= "(object attacker)"
                  Case 3, 6, 11, 12, 13, 52, 16, 17
                    _UserListing &= "(object target)"
                  Case 4
                    _UserListing &= "(object attacker, object corpse)"
                  Case 5
                    _UserListing &= "(object attacker, object victim, object corpse)"
                  Case 7
                    _UserListing &= "(object attacker, integer damamt)"
                  Case 22
                    _UserListing &= "(object sender, list args)"
                    listvars.Add("args")
                  Case 23, 51
                    _UserListing &= "(object user)"
                  Case 24, 56
                    _UserListing &= "(object user, object usedon)"
                  Case 25
                    _UserListing &= "(object user, location usedon, integer objtype)"
                  Case 27
                    _UserListing &= "(object dropper)"
                  Case 28
                    _UserListing &= "(object looker)"
                  Case 29
                    _UserListing &= "(object giver, object givenobj)"
                  Case 30
                    _UserListing &= "(object getter)"
                  Case 34
                    _UserListing &= "(object victim, integer damamt)"
                  Case 35
                    _UserListing &= "(object talker, string arg)"
                  Case 36
                    _UserListing &= "(object user, integer listindex, integer objtype, integer objhue)"
                  Case 37
                    _UserListing &= "(object user, integer objhue)"
                  Case 38
                    _UserListing &= "(integer trammelchange, integer feluccachange)"
                  Case 39, 41
                    _UserListing &= "(object defender)"
                  Case 44
                    _UserListing &= "(object equippedon)"
                  Case 45
                    _UserListing &= "(object unequippedfrom)"
                  Case 46, 47
                    _UserListing &= "(object stackon)"
                  Case 48
                    _UserListing &= "(integer oldtype, integer newtype)"
                  Case 49
                    _UserListing &= "(integer oldvalue, integer newvalue)"
                  Case 55
                    _UserListing &= "(object user, integer closeId, list selectList, list entryList)"
                    listvars.Add("selectList")
                    listvars.Add("entryList")
                  Case 57
                    _UserListing &= "(object killer, object killee)"
                  Case 58
                    _UserListing &= "(object sender, integer button, string text)"
                  Case 59
                    _UserListing &= "(integer func)"
                  Case 60
                    _UserListing &= "(object stealer)"
                  Case 61
                    _UserListing &= "(object user, object usedon)"
                  Case 64, 65
                    _UserListing &= "(object target, integer transok)"
                  Case 66
                    _UserListing &= "(object buyer, object seller, integer quantity)"
                  Case 67
                    _UserListing &= "(object victim, integer damage)"
                  Case Else
                    If Index5EE45C < Table5EE45C.Length Then
                      _UserListing &= "()"
                    Else
                      _UserListing &= "?"
                    End If
                End Select
              End If
              lastline_wasfor = False
              lastline_wasnewline = True
              _UserListing &= vbNewLine & Space(depth * 2) & "{" & vbNewLine
              depth += 1
            Case "}"
              lastline_wasnewline = True
              depth -= 1
              _UserListing &= Space(depth * 2) & "}" & vbNewLine
              If depth = 0 Then
                _UserListing &= vbNewLine
              End If
            Case "case"
              lastline_wascase = True
              lastline_wasnewline = False
              _UserListing &= Space(depth * 2 - 2) & "case "
            Case "default"
              lastline_wasnewline = True
              _UserListing &= Space(depth * 2 - 2) & "default:" & vbNewLine
            Case "integer", "string", "ust", "location", "object", "list", "void"
              newlast_wastype = Output(1)
              _UserListing &= Output(1)
            Case ","
              _UserListing &= ", "
            Case "("
              If lastline_wason Then
                If generate_realc Then
                  _UserListing &= " , "
                Else
                  _UserListing &= "<"
                End If
              Else
                _UserListing &= "("
              End If
            Case ")"
              If lastline_wason Then
                If generate_realc Then
                Else
                  _UserListing &= ">"
                End If
              Else
                _UserListing &= ")"
              End If
            Case "++", "--"
              _UserListing &= " " & Output(1)
            Case "+", "-", "*", "/", "&&", "||", "^", "!=", "==", "<", ">", "<=", ">=", "="
              _UserListing &= " " & Output(1) & " "
              If generate_realc Then
                If Output(1) = "=" Then
                  If line_atleastonelist Then
                    ' If line_islistassignment is true something went wrong!
                    If line_islistassignment Then
                      line_islistassignment = False
                    End If

                    '
                    line_islistassignment = True
                    _UserListing &= "MAKELIST("
                  End If
                End If
              End If
            Case Else
              ' Fix the output for #on
              If lastline_wason AndAlso stringon Is Nothing Then
                If Microsoft.VisualBasic.Left(Output(1), 2) = "0x" Then
                  If generate_realc Then
                    Output(1) = Integer.Parse(Output(1).Substring(2), Globalization.NumberStyles.AllowHexSpecifier) & " , "
                  Else
                    Output(1) = "<" & Integer.Parse(Output(1).Substring(2), Globalization.NumberStyles.AllowHexSpecifier) & ">"
                  End If
                Else
                  stringon = Output(1)
                  If adddefault1000 Then
                    If generate_realc Then
                      Output(1) = "1000 , " & Output(1)
                    Else
                      Output(1) = "<1000>" & Output(1)
                    End If
                  End If
                End If
              End If

              ' Add a "+" to indicate the combining of quoted strings
              If lastline_wasquoted AndAlso Output(1)(0) = """" Then
                _UserListing &= " + "
              End If

              ' Add a space after a type identifier and indicate line is list if needed
              If last_wastype <> "" Then
                If last_wastype = "list" Then
                  listvars.Add(Output(1))
                End If
                _UserListing &= " "
              End If

              ' Does the line contain atleast one list variable?
              If listvars.Contains(Output(1)) Then
                line_atleastonelist = True
              End If

              '
              _UserListing &= Output(1)
              If lastline_wascase Then
                lastline_wascase = False
                lastline_wasnewline = True
                _UserListing &= ":" & vbNewLine
              End If
          End Select

          ' Was the last keyword a type identifier?
          last_wastype = newlast_wastype

          ' Indicate wether or not the previous keyword was a quoted string
          lastline_wasquoted = Output(1)(0) = """"
        End If

        ' Add to the the binary output
        If Output.Count > 0 Then
          _BinaryListing &= Output(0) & vbNewLine
        End If
      Next
    End Sub

    Public Overrides Function ToString() As String
      Return ScriptName
    End Function
  End Class

  Private Sub FormMain_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    '
    If e.CloseReason <> CloseReason.ApplicationExitCall Then
      If Not Me.Button_ScanAndDecompileAll.Enabled Then
        ' If the interface is not active then we must use the thread to request an exit!
        ' NOTE: the interface is not active when the scan and decompile thread is doing its job
        e.Cancel = True
        Timer_Exit.Enabled = True
      End If
    End If
  End Sub

  Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Get the last scanned script directory
    Dim ScriptDirectory As String
    Try
      ScriptDirectory = GetSetting("Mass M Decompiler", "Main", "ScriptDirectory").Trim
    Catch
      ScriptDirectory = ""
    End Try

    ' NOTE: if not set try to get the setting from the "normal" M Decompiler
    If ScriptDirectory = "" Then
      Try
        ScriptDirectory = GetSetting("M Decompiler", "Main", "ScriptDirectory").Trim
      Catch
      End Try
    End If

    ' Get the pseudo-C generation flag
    Dim sGenerateRealC As String
    Try
      sGenerateRealC = GetSetting("Mass M Decompiler", "Main", "GenerateRealC").Trim.ToLowerInvariant
    Catch
      sGenerateRealC = ""
    End Try
    If sGenerateRealC = "" Then
      Me.CheckBox_GenerateRealC.Checked = GenerateRealC ' Use the default flag
    ElseIf sGenerateRealC = "yes" Then
      Me.CheckBox_GenerateRealC.Checked = True
    Else
      Me.CheckBox_GenerateRealC.Checked = False
    End If

    If ScriptDirectory <> "" Then
      ' Set the script directory and scan
      Me.TextBox_ScriptDirectory.Text = ScriptDirectory
    End If
  End Sub

  Private Sub Button_ScanAndDecompileAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ScanAndDecompileAll.Click
    ' Disable the interface during the scan
    Me.TextBox_ScriptDirectory.Enabled = False
    Me.CheckBox_GenerateRealC.Enabled = False
    Me.Button_ScanAndDecompileAll.Enabled = False

    ' Clear the list with scripts
    Me.ListBox1.SelectedItems.Clear()
    Me.ListBox1.Items.Clear()

    Try
      ' Get the script directory to scan
      Dim ScriptDirectory As String = Me.TextBox_ScriptDirectory.Text.Trim

      ' Get the real C generation flag
      GenerateRealC = Me.CheckBox_GenerateRealC.Checked

      ' Determine the SDB file
      Dim SDBPath As String = IO.Path.Combine(ScriptDirectory, "sdb.txt")
      If Not IO.File.Exists(SDBPath) Then
        SDBPath &= ".q"
        If Not IO.File.Exists(SDBPath) Then
          SDBPath = Nothing
        End If
      End If
      If SDBPath Is Nothing Then
        Throw New Exception("Unable to locate SDB.TXT in the script directory!")
      End If

      ' Read the SDB file
      SDBtxt.Clear()
      Dim StreamSDB As New IO.FileStream(SDBPath, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

      ' Read
      Dim Reader As New IO.StreamReader(StreamSDB, tmpEncoder, False)
      Do While Not Reader.EndOfStream
        SDBtxt.Add(Reader.ReadLine)
      Loop

      StreamSDB.Close()

      ' The SDB was valid, so save the directory
      Try
        SaveSetting("Mass M Decompiler", "Main", "ScriptDirectory", ScriptDirectory)
      Catch
      End Try

      ' Save the real C generation flag
      Try
        SaveSetting("Mass M Decompiler", "Main", "GenerateRealC", IIf(GenerateRealC, "yes", "no"))
      Catch
      End Try

      ' Start the scan thread 
      Dim thread As New Threading.Thread(AddressOf ScanAndDecompileAll)
      thread.Start(ScriptDirectory)
    Catch ex As Exception
      MsgBox(ex.Message)

      ' Enable the interface on error
      Me.TextBox_ScriptDirectory.Enabled = True
      Me.CheckBox_GenerateRealC.Enabled = True
      Me.Button_ScanAndDecompileAll.Enabled = True
    End Try
  End Sub

  Private Sub ScanAndDecompileAll(ByVal ScriptDirectory As String)
    '
    Dim RootTitle As String = Me.Text

    Try
      ' Get all *.M files and all *.M.Q files
      For Each FilePath As String In My.Computer.FileSystem.GetFiles(ScriptDirectory, FileIO.SearchOption.SearchTopLevelOnly, New String() {"*.M", "*.M.Q"})
        Dim LBIS As New LISTBOXITEM_SCRIPT(FilePath)

        ' Add to the list
        Call AddScript(LBIS, RootTitle)

        ' Do the actual decompile
        Try
          LBIS.RawListing = DecompileM(LBIS.ToString, LBIS.ScriptPath)
        Catch ex As Exception
          LBIS.RawListing = ex.Message
        End Try

        ' Abort the loop if the user requested an exit
        If ExitState > 0 Then
          Exit For
        End If
      Next
    Catch
    End Try

    '
    Call AddScript(Nothing, RootTitle)
  End Sub

  Private Delegate Sub Delegate_AddScript(ByRef LBIS As LISTBOXITEM_SCRIPT, ByVal RootTitle As String)
  Private Sub AddScript(ByRef LBIS As LISTBOXITEM_SCRIPT, ByVal RootTitle As String)
    If Me.InvokeRequired Then
      Me.Invoke(New Delegate_AddScript(AddressOf AddScript), LBIS, RootTitle)
    Else
      If LBIS Is Nothing Then
        ' Set the window title!
        Me.Text = RootTitle

        If ExitState = 0 Then
          ' Enable the interface again
          Me.TextBox_ScriptDirectory.Enabled = True
          Me.CheckBox_GenerateRealC.Enabled = True
          Me.Button_ScanAndDecompileAll.Enabled = True
        Else
          ' Indicate we are ready to quit
          ExitState = 2
        End If
      Else
        ' Add to the list and update the window title!
        Me.ListBox1.Items.Add(LBIS)
        Me.Text = RootTitle & " - " & IO.Path.GetFileName(LBIS.ScriptPath)
      End If
    End If
  End Sub

  Public Function DecompileM(ByVal ScriptName As String, ByVal FilePath As String)
    ' Open the file
    Dim File As New IO.FileStream(FilePath, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

    ' Return an empty decompiled string if the file length is zero
    If File.Length = 0 Then
      Return ""
    End If

    ' Read into a buffer
    Dim TempBuffer(File.Length) As Byte
    File.Read(TempBuffer, 0, File.Length)

    ' Add 0-Byte at the end of the buffer
    TempBuffer(File.Length) = 0

    Return DecompileM(ScriptName, TempBuffer)
  End Function

  Public Function DecompileM(ByVal ScriptName As String, ByVal Contents() As Byte) As String
    Dim DecompiledData As String = ""

    If GenerateRealC Then
      DecompiledData = "#Real-C§Real-C" & vbNewLine
    Else
      DecompiledData = "#UO-C§UO-C" & vbNewLine
    End If

    ' Begin the loop
    Dim i As Integer = 0
    Do While i < Contents.Length
      ' Abort the loop if the user wants us to quit
      If ExitState > 0 Then
        Exit Do
      End If

      ' Exit the loop if we reached the end
      If Contents(i) = 0 Then
        DecompiledData &= "@$" & i.ToString("X4") & ":$00->DONE"
        Exit Do
      End If

      ' Get the encrypted script-word and convert it to an unencrypted script-byte
      Dim Encrypted As UInt16 = Contents(i + 1) * 256 + Contents(i)
      Dim ScriptByte As Byte = ConvertScriptWordToByte(Encrypted)
      i += 2

      ' Binary output
      DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & Encrypted.ToString("X4") & "=$" & ScriptByte.ToString("X2") & "->"

      ' Convert the script-byte to a keyword/token as we know it from the C language
      Select Case ScriptByte
        Case &H2
          DecompiledData &= "'('§("
        Case &H3
          DecompiledData &= "')'§)"
        Case &H4
          DecompiledData &= "','§,"
        Case &H6
          DecompiledData &= "';'§;"
        Case &H7
          DecompiledData &= "'{'§{"
        Case &H8
          DecompiledData &= "'}'§}"
        Case &H9
          DecompiledData &= "'['§["
        Case &HA
          DecompiledData &= "']'§]"
        Case &HB
          DecompiledData &= "'!'§!"
        Case &HC
          DecompiledData &= "'+'§+"
        Case &HD
          DecompiledData &= "'-'§-"
        Case &HE
          DecompiledData &= "'*'§*"
        Case &HF
          DecompiledData &= "'/'§/"
        Case &H10
          DecompiledData &= "'%'§%"
        Case &H11
          DecompiledData &= "'=='§=="
        Case &H12
          DecompiledData &= "'!='§!="
        Case &H13
          DecompiledData &= "'<'§<"
        Case &H14
          DecompiledData &= "'>'§>"
        Case &H15
          DecompiledData &= "'<='§<="
        Case &H16
          DecompiledData &= "'>='§>="
        Case &H17
          DecompiledData &= "'='§="
        Case &H18
          DecompiledData &= "'&&'§&&"
        Case &H19
          DecompiledData &= "'||'§||"
        Case &H1A
          DecompiledData &= "'^'§^" ' is unused!!!
        Case &H1B
          DecompiledData &= "'++'§++"
        Case &H1C
          DecompiledData &= "'--'§--"
        Case &H1D
          DecompiledData &= "VARIABLE-TYPE=integer§integer"
        Case &H1E
          DecompiledData &= "VARIABLE-TYPE=string§string"
        Case &H1F
          DecompiledData &= "VARIABLE-TYPE=q->ust=?§ust" ' TODO: What is 'q' aka "ust" ? 
        Case &H20
          DecompiledData &= "VARIABLE-TYPE=location§location"
        Case &H21
          DecompiledData &= "VARIABLE-TYPE=object§object"
        Case &H22
          DecompiledData &= "VARIABLE-TYPE=list§list"
        Case &H23
          DecompiledData &= "VARIABLE-TYPE=void§void"
        Case &H25
          DecompiledData &= "IF§if"
        Case &H26
          DecompiledData &= "ELSE§else"
        Case &H27
          DecompiledData &= "ENDIF§" ' is unused!!!!
        Case &H28
          DecompiledData &= "WHILE§while"
        Case &H29
          DecompiledData &= "WEND§" ' is unused!!!!
        Case &H2A
          DecompiledData &= "FOR§for"
        Case &H2B
          DecompiledData &= "NEXT§" ' is unused!!!!
        Case &H2C
          DecompiledData &= "CONTINUE§continue"
        Case &H2D
          DecompiledData &= "BREAK§break"
        Case &H2E
          DecompiledData &= "GOTO§goto" ' is unused!!!!
        Case &H2F
          DecompiledData &= "DO SELECT§switch"
        Case &H30
          DecompiledData &= "END SELECT" ' is unused!!!!
        Case &H31
          DecompiledData &= "CASE§case"
        Case &H32
          DecompiledData &= "CASE ELSE§default"
        Case &H33
          DecompiledData &= "RETURN§return"
        Case &H34
          DecompiledData &= "DEFINE-FUNCTION§#function"
        Case &H35
          DecompiledData &= "DEFINE-HANDLER§#on"
        Case &H36
          DecompiledData &= "DECLARE-VARIABLE§#scriptvar"
        Case &H37
          DecompiledData &= "INCLUDE§#include"
        Case &H38
          DecompiledData &= "DECLARE-FUNCTION§#extern"
        Case &H3A
          Dim KeepLooping As Boolean
          Do
            KeepLooping = False
            DecompiledData &= "QUOTED-STRING" & vbNewLine

            ' Get the index into the SDB
            Dim iSDB As Integer = Contents(i + 1) * 256 + Contents(i)
            i = i + 2

            ' Output
            If ScriptName = "tutdragon" AndAlso iSDB = SDBtxt.Count Then
              Dim SDBfix As String = """""" & SDBtxt(iSDB - 1).Substring(1) & """"
              DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->TUTDRAGON-SDB-BUG->'" & SDBfix & "'§" & SDBfix
            Else
              DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->'" & SDBtxt(iSDB) & "'§" & SDBtxt(iSDB)
            End If

            ' Keep extracting quoted-strings?
            If IsScriptWordEqualToByte(Contents, i, &H3A) Then
              ' We must extract another quoted-string
              Encrypted = Contents(i + 1) * 256 + Contents(i)
              i = i + 2
              KeepLooping = True

              ' Output
              DecompiledData &= vbNewLine & "@$" & (i - 2).ToString("X4") & ":$" & Encrypted.ToString("X4") & "=$3A->"
            End If
          Loop While KeepLooping
        Case &H3C
          DecompiledData &= "BYTE" & vbNewLine

          ' Get the constant
          Dim b As Byte = Contents(i)
          i += 1

          ' Output
          DecompiledData &= "@" & (i - 1).ToString("X4") & ":" & b.ToString("X2") & "->" & b.ToString & "§0x" & b.ToString("X2")
        Case &H3D
          DecompiledData &= "DOUBLEBYTE" & vbNewLine

          ' Get the constant
          Dim w As UInt16 = Contents(i + 1) * 256 + Contents(i)
          i += 2

          ' Output
          DecompiledData &= "@" & (i - 2).ToString("X4") & ":" & w.ToString("X4") & "->$" & w.ToString & "§0x" & w.ToString("X4")
        Case &H3E
          DecompiledData &= "QUADBYTE" & vbNewLine

          ' Get the constant
          Dim q As UInt32 = CType(Contents(i + 3), UInt32) * 256 * 256 * 256 + Contents(i + 2) * 256 * 256 + Contents(i + 1) * 256 + Contents(i)
          i += 4

          ' Output
          DecompiledData &= "@" & (i - 4).ToString("X4") & ":" & q.ToString("X8") & "->$" & q.ToString & "§0x" & q.ToString("X8")
        Case &H41
          DecompiledData &= "STRING" & vbNewLine

          ' Get the index into the SDB
          Dim iSDB As Integer = Contents(i + 1) * 256 + Contents(i)
          i += 2

          ' Output
          DecompiledData &= "@$" & (i - 2).ToString("X4") & ":$" & iSDB.ToString("X4") & "->SDB(" & iSDB.ToString & ")->'" & SDBtxt(iSDB) & "'§" & SDBtxt(iSDB)
        Case Else
          DecompiledData &= "UNKNOWN?"
      End Select

      DecompiledData &= vbNewLine
    Loop

    Return DecompiledData
  End Function

  Public Shared Function ConvertScriptWordToByte(ByRef Contents() As Byte, ByVal Index As Integer) As Byte
    Return ConvertScriptWordToByte(Contents(Index + 1) * 256 + Contents(Index))
  End Function

  Public Shared Function ConvertScriptWordToByte(ByVal w As UInt16) As Byte
    ' Look up
    For i As Integer = SillyLookupTable.GetLowerBound(0) To SillyLookupTable.GetUpperBound(0)
      If SillyLookupTable(i) = w Then
        Return i \ 5
      End If
    Next

    ' Not found
    Return &HFF
  End Function

  Public Shared Function IsScriptWordEqualToByte(ByRef Contents() As Byte, ByVal Index As Integer, ByVal b As Byte) As Boolean
    Return IsScriptWordEqualToByte(Contents(Index + 1) * 256 + Contents(Index), b)
  End Function

  Public Shared Function IsScriptWordEqualToByte(ByVal w As UInt16, ByVal b As Byte) As Boolean
    ' Convert to byte to an index and verify the index
    Dim baseindex = b * 5
    If baseindex >= SillyLookupTable.Length Then
      Return False
    End If

    ' Look up (only 5 indexes)
    For i As Integer = baseindex To baseindex + 5 - 1
      If SillyLookupTable(i) = w Then
        Return True
      End If
    Next

    ' Not found
    Return False
  End Function

  Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
    If Me.ListBox1.SelectedItems.Count = 0 Then
      Me.TextBox1.Text = ""
      Me.TextBox2.Text = ""
    Else
      Dim LBIS As LISTBOXITEM_SCRIPT = Me.ListBox1.SelectedItems(0)
      Me.TextBox1.Text = LBIS.BinaryListing
      Me.TextBox2.Text = LBIS.UserListing
    End If
  End Sub

  Private Sub Timer_Exit_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer_Exit.Tick
    ' Indicate to the thread we want to exit
    If ExitState = 0 Then
      ExitState = 1
    End If

    ' If the thread told us it has exited then go quit
    If ExitState = 2 Then
      ExitState = 3

      '
      Me.Timer_Exit.Enabled = False
      Application.Exit()
    End If
  End Sub

  Private Sub Button_DumpAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DumpAll.Click
    Dim ScriptDirectory As String
    Try
      ScriptDirectory = GetSetting("Mass M Decompiler", "Main", "ScriptDirectory").Trim
    Catch
      ScriptDirectory = ""
    End Try

    If (IO.Directory.Exists(ScriptDirectory)) Then
      ' Ensure that our directory for the C scripts exists
      Dim OutputDirectory As String = IO.Path.GetFullPath(IO.Path.Combine(ScriptDirectory, "..\scripts.c"))
      If (Not IO.Directory.Exists(OutputDirectory)) Then
        IO.Directory.CreateDirectory(OutputDirectory)
      End If

      ' For each decompiled script, write the user listing to disk
      For Each LBI As LISTBOXITEM_SCRIPT In ListBox1.Items
        Dim name As String = LBI.ToString
        Dim Listing As String = LBI.UserListing
        Dim fs As New IO.FileStream(IO.Path.Combine(OutputDirectory, name & ".m.C"), IO.FileMode.Create)
        Dim sw As New IO.StreamWriter(fs)
        sw.Write(Listing)
        sw.Close()
        fs.Close()
      Next
    End If
  End Sub

  Private Sub Button_SelectDirectory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SelectDirectory.Click
    Try
      ' Use a Select Directory Dialog to get a new directory
      Dim GetFolder As New FolderBrowserDialog
      GetFolder.ShowNewFolderButton = False
      GetFolder.SelectedPath = Me.TextBox_ScriptDirectory.Text.Trim
      If GetFolder.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Me.TextBox_ScriptDirectory.Text = GetFolder.SelectedPath
      End If
    Catch ex As Exception
      ' Error!
      MsgBox(ex.Message)
    End Try
  End Sub
End Class
