Welcome to Version 2.5 of UO Helper.

I plan on adding many new features over time. It will not be limited to Moongate. Far from it.

Check back to me from time to time for the latest versions.

My Email is rhawk@alt.net

Version info:
1.0.0   01/26/98
� First build

1.1.0   01/27/98
� Redesigned interface to allow for future expantion.
� Made time display boxes yellow rather than grayed out.
� Corrected 2 town spelling errors (thanks Thern).
� Added time input for exact schedules.

1.2.0   01/28/98
� Fixed caculation bug on manual time input.

2.0.0   01/29/98
� Added the translation section & engine. Chat through the program in the game and have a blast.
� Build up a Valley Girl dictionary for the Engine.
� I thank all the players in the Catskills shard for putting up with Glumpman (my interface test character). Those of you who have seen him know I am working on a macro section also!

2.1.0   01/31/98
� Changed the look for the translation screen and added the output display.
� Fixed several major bugs in the engine.
� Built a Jive dictionary
� Working on a Middle/Olde English dictionary now for the next release!
    
2.2.0   02/01/98
� Found a bug in the Translation engine again. Some words and phrases were not translating right. Fixed it.
� Changed the translations look-ups a bit. Not too much.
� Translation now tried to uppercase all Words starting a new sentance.
    
2.3.0   02/02/98
� Found a bug in the Translation engine again! Some words and phrases were not translating right. Fixed it.
� Added Renaissance translation to the mix.
� Modified ALL the translater lookups.
� Program can now be minimized.
    
2.4.0   02/03/98
� Again I rewrote the translation engine to fix speed issues and parsing errors.

2.4.1   02/03/98
� Added Renaissance translation to the mix.
� Fixed some of the Valleygirl and Renaissance modifiers.
� Fix form display bug on systems set to large fonts.
� Added scroll bars to translation inputs and display. This allows a more exact copy to be pasted in the box.
� *Enough translater work. Time to start the weapon/monster/armour tables!!!

2.4.2   02/03/98
� Grammer fix on the dictionary. :(

2.5.0   02/04/98
� And here I thought I was done with the translater. HA! Thanks to the following people for ideas and bug spotting:
� Leeese, Paul, Kevin Gowen, myself :), Morgue, Paul from the UK, Tom from Germany.
� Fixed 2 bugs with the new parser. Should be perfect how (please god)
� Removed the "CLEAR" button in the translater page and added clear to the new popup menu.
� Removed the lower scroll bar and made the memso fields text wrap again. Sadly this causes formatted text to drop the format. So I added the option to turn off word wrap in the popup menu.
� Added a popup menu to the text boxes! Options include "Clear text boxes" "load/save/save as" (so you can translate your doc files and write them back to a file and Cut/Copy/Paste to the popup menu! Also an option to make the enter key translate the text.
� If anyone knows where I can get a freeware or cheap program to make .HLP file let me know. Email me at rhawk@alt.net.
� A lot of people have complained about the time that text stays on the UO screen. It is not my program that make short lines erase faster than the long ones. You need to change your UO.CFG settings.  Here is a quote from the OSI web site on the settings to adjust or add:
!!!!!Two new UO.CFG options have been added that adjust the duration of player and NPC speech. BarkTimeModifier sets how long all speech remains on screen (default is 4 seconds) as a percentage. The default is 300% as long for speech (12 seconds). ScaleBarkTimes is a toggle to adjust whether or not the duration scales based on the length of the text displayed. The below are the defaults:     
             BarkTimeModifier=300
             ScaleBarkTimes=no

2.5.1   02/05/98
� Fixed a punctuation bug in the translator engine. Some phrases were droping the period when displayed.
� Fixed Save File option on popup menu of translation page. It would not activate before.
� Fixed Save AS File option on popup menu of translation page. It would not activate before.
� Corrected a spelling error on the translate page.
� Corrected a spelling error on the tabs.
� Made a new icon for the program. (Actually Robert made it and I did a wee bit of tweaking. Robert did 87% of the work)
� Fixed bug in the Renaissance dictionary. It no longer replaced "and" in ANY word with "also". IE: Wand / Walso.
� Fixed bug in the Renaissance dictionary. When it replaces a word with "bemoan" it adds the space. Also fixed the spelling of "bemoan".
� Fixed bug in the Renaissance dictionary. It no longer replaced "true" in ANY word with "real". IE: Realize / Trueize.
� Fixed bug in the Valley Girl dictionary. It no longer throws out a garbage string for "very".
� Added several more "colourful" phrases to the Renaissance dictionary. For a good laugh try translating some bad language.

2.6.0   02/08/98
� Resorted the translation lookups.
� Translator setting or Translate on Enter now also clears the text and keeps you in the input box.
� Translator setting or Translate on Enter now also clears the text and keeps you in the input box.
� Made a Renaissance dictionary rule changed for the usage of "you"/"thee" and "thou". *Thanks King Cobra*

3.0.0   02/12/98
� Added weapons tab. You can how get an image and stats on most weapons.
� Added 6 new translations to the Renaissance dictionary.

3.1.0   02/12/98
� Weapons tabs now each default to first weapon in the list rather than start blank.
� If you double click on the Weapon image, the size will rotate between 1x and 2.6x. Try it to see.

3.2.0   02/12/98
� Redesigned how the weapon section is build and functions. Will speed up the code and shrink the exe size while removing the slight flicker whn tabs were changed.
� Added a scroll bar to resize the weapon image. This makes it easier to play with the sizing.
� Added weight display for the weapons. The problem with this is that I do not have any of the weapon weights yet. I will add them as I find them out.
    If you feel helpful, please email me with any weights you know about. To find a weight out, just check your current weight, drop the weapon and recheck the weight.
� The weapon tabs are no longer multi-rowed. There are scroll arrows to move the tabs over. This had to be done since the addition of the weight display left room for only 1 row of tabs.
� Fixed display problem when you TRIED to resize the program. The pointer can no longer ever grab the form sides to try to resize.
� When maximize button is clicked, the program will drop to the lower right corner of the screen. This is because when UO is played in a window it functions best in upper left. This give maximum spaceing between the two applications.
� Several spelling errors were pointed out to me by Giovanni. Thanks. I sort of fixed them. The 1st new item on this version fixed it for me.
� Added over 10 new lookups to the Renaissance dictionary.
� Only one UOHelper can be run at a time. If you try to start a 2nd, the first will maxamize.
� Thanks to Strogar for the weights of the weapons he was carrying.

3.3.0   02/13/98
� Thanks go to DragonWarrior for 6 weapon weights.
� The magic weapon properties page is up. You can now lookup the special properties of the magic weapons you find.

4.0.0   02/17/98
� Corrected a calulation error on weapon damage for magic weapons.
� Added more weapon weights.
� Added the armour tab, to gain the stats of common armour.
� Added magic armour properties page is up. You can now lookup the special properties of the magic armour you find.
� Added more weapon weights.

** I am still missing some weapon weights and a lot of armour weights! If you have them email them to me please.

4.1.0   02/18/98
� Fixed flaw that made Bone show on weapon tab.
� Corrected display info colors. On some systems data could not be seen.
� Added more to about box.

4.2.0   02/19/98
� Fixed media player error that some people complained about when the about box was closed.
� Added the download sites to the about box scrolling text.

4.3.0   02/20/98
� Fixed the about box. It is now scaled to your font size and not resizeable.

5.0.0	03/08/98 -- LONG OVER DUE
� Added the Animals tab.
� Thanks to Keith Lewis added lots of new weights.
� Added all the creature tab logic (though not the images yet, so you cannot access it. =-) )
� Fixed a few annoyig errors in the code, to stupid to even tell ya what I did.


** New section.. random notes on my play:
� The other night I was killed two times by Dread Lord Chou Fong. Pker that he is I followed him as ghost through his gate when he left Buc's Den.
	Seems he may be part of a guild called Chaos. They have an evil village in Catskills about 22E 90N. I pay all good characters shall go there and kill
	the bad guys! I will try from time to time.
� If you see White Rabbit in Catskills, he is looter. He looted me, and I was res'ed and attacked him. Lost noto doing so, but it was worth killing the bastard!
	Taunt him on sight!