
=============================
| (c) 2000 Sebastian Hartte
| Skill Creator
===========================

* Legal Stuff:
This application will create a new skills.mul and skills.idx in the Ultima Online
Skill Format. The files are created from scratch and therefore free from any 
copyrighted material created by Origin or EA.

* How to use:
Open the skills.mul in an editor and modify the entries however you whish.
If you want a small blue button to appear left to the skillname on your
skill-list then set "useable" to "1". Please note that the order in skills.xml
DOES matter, so the first skill in skills.xml is the skill-id 0 and so on.

Have fun...
This .exe has been created using Borland Delphi
