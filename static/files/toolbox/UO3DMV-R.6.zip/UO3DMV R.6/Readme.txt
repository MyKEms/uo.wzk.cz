UO3DMV R.6.    FREEWARE  (C)1999 by LXD 
---------------------------------------

The uses of this program is at you own risk!

Copy the program simply into the UO directory and launch it.


Key assignment for the Editor: 

  F1           - normal mode
  F2           - terrain mode
  F3           - static mode

  F5/F6/F7/F8  - changes the perspective 
  
  + / -        - changes the map size
 
  7 / 1        - zoom 
  4, 6, 8, 2   - move
  9 , 3        - first person position raise/lower

  g, h, j      - saves the map position
  b, n, m      - go to the map position

  #edit mode
 
  F11           - saves changes in "data.omp"
  F12           - load the "data.omp"

  #terrain mode 
  u              - draw tile / right mouse = paint / left mouse = choose tile
  i              - adjust square / right mouse = raise / left mouse = lower
  o              - adjust point / right mouse = raise / left mouse = lower
  p              - draw plain / right mouse = paint / left mouse = choose height 
  q              - set rise/lower level to 1
  w              - set rise/lower level to 10

  #static mode
  left mouse  = set static object
  right mouse = choose static object from map
  d              - uses origninal z value from the object
  f              - uses ground height


These files must be in the same directory:

   Art.mul 
   Artidx.mul 
   Map0.mul 
   Staidx0.mul 
   Statics0.mul 


Hardware & software requests: 

   Direct3D Version ( Hardware ):
   *****************************
   Direct3D compatible accelator card which support the windowed mode 
   DirectX6.0 or higher
   Win95/98/NT

   Direct3D Version ( Software ):
   *****************************
   DirectX6.0 or higher
   Win95/98/NT
   A very fast processor 
    


I hope you enjoy this program!


LXD    UIN: 23152372

UO3DMV Homepage : http://prinz.hannover.sgh-net.de/~schiller/tools