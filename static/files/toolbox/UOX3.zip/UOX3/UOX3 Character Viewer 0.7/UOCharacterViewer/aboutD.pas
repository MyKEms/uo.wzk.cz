unit aboutD;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, shellApi;

type
  TAboutDlg = class(TForm)
    Label1: TLabel;
    Panel1: TPanel;
    Image1: TImage;
    Label2: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label4: TLabel;
    Label3: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Button1: TButton;
    Label10: TLabel;
    procedure Label5Click(Sender: TObject);
    procedure Label6Click(Sender: TObject);
    procedure Label9Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  AboutDlg: TAboutDlg;

implementation

{$R *.DFM}

procedure TAboutDlg.Label5Click(Sender: TObject);
begin
  shellexecute (0, 'open', 'mailto:wverkley@xtra.co.nz', '', '', SW_SHOW);
end;

procedure TAboutDlg.Label6Click(Sender: TObject);
begin
  //shellexecute (0, 'open', 'http://homepages.ihug.co.nz/~wverkley/uocview', '', '', SW_SHOW);
end;

procedure TAboutDlg.Label9Click(Sender: TObject);
begin
  shellexecute (0, 'open', 'http://alazane.surf-va.com/', '', '', SW_SHOW);
end;

end.
