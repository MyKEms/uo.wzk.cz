program uocview;

uses
  Forms,
  mainF in 'mainF.pas' {MainForm},
  data in 'data.pas',
  aboutD in 'aboutD.pas' {AboutDlg};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'UO Character Viewer';
  Application.CreateForm(TMainForm, MainForm);
  Application.CreateForm(TAboutDlg, AboutDlg);
  Application.Run;
end.
